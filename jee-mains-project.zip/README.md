# 🎯 JEE Main & Class 12th Board Comprehensive Preparation Platform

An advanced, high-performance web preparation platform designed specifically for **JEE Main (Paper 1: B.E./B.Tech)** and **Class 12th Board Examinations (CBSE & State Boards)**.

![Platform Preview](https://img.shields.io/badge/Next.js-16.4.3-black?logo=next.js)
![React](https://img.shields.io/badge/React-19.0-61DAFB?logo=react)
![TypeScript](https://img.shields.io/badge/TypeScript-5.0-3178C6?logo=typescript)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-3.4-38B2AC?logo=tailwind_css)
![License](https://img.shields.io/badge/License-MIT-green)

---

## 🌟 Key Features

### 1. 🎯 Section 1: JEE Main (Paper 1: B.E./B.Tech)
- **2,000+ Verified Authentic PYQs (2015–2024)**: Full coverage across Physics, Chemistry, and Mathematics from official NTA shift papers.
- **Strictly Paper 1**: 0% JEE Advanced content, zero deleted syllabus topics.
- **10-Point Textbook Explanations**: Concept tested, required formulas, step-by-step mathematical derivations, why correct, why other options are distractors, common traps, and time-saving shortcuts.
- **Smart Filter Engine**: Filter questions by Subject, Chapter, Year, Exam Shift, Question Format (MCQ / Numerical), and Difficulty.

### 2. 📚 Section 2: Class 12th Boards (CBSE & State Boards)
- **1,002 Non-Repeating Board Questions**: Authentic distribution matching CBSE paper blueprints:
  - **Section A**: 1M MCQs & Assertion-Reason with balanced, unpredictable answer keys (A, B, C, D).
  - **Section B**: 2M Very Short Answer (VSA) with definition & formula rubrics.
  - **Section C**: 3M Short Answer (SA) with step-by-step proofs.
  - **Section D**: 4M Case-Based Studies with real-world passage analysis and sub-questions.
  - **Section E**: 5M Long Answer (LA) with labeled ray diagrams and mathematical derivations.
- **Physics Master Hub**: Complete formula directory with SI units, 3M & 5M step-by-step derivations with diagram checklists.
- **Chemistry Master Hub**: Complete organic reaction directory, **Named Reactions Master Guide**, and a comprehensive **Reagents Master Guide** (conversions, limitations, exam importance).
- **Mathematics Master Hub**: Complete formula book and **Board Speed & Verification Tricks** (Matrix method verification in 30 seconds, King's property symmetry quotient, etc.).

### 3. 🔊 Interactive Exam Simulator (Web Audio API)
- **Zero-Latency Audio Synthesizer**: Built-in sound effects engine using Web Audio API—no external audio files required.
- **Auditory & Visual Feedback**:
  - Crisp "pop" sound upon clicking any option.
  - Emerald green highlight + checkmark + celebratory chime + confetti for correct answers.
  - Red highlight with cross + immediate reveal of correct answer.
- **Automatic English Solution Drawer**: Unfolds the model topper answer, CBSE step-wise marking breakdown, examiner warnings, and Guru Ji Kota mentorship secrets.

---

## 🛠️ Technology Stack

- **Framework**: [Next.js 16 (App Router & Turbopack)](https://nextjs.org/)
- **UI Library**: [React 19](https://react.dev/)
- **Styling**: [Tailwind CSS](https://tailwindcss.com/)
- **Math Formatting**: [KaTeX & MathRenderer](https://katex.org/)
- **Icons**: [Lucide React](https://lucide.dev/)
- **Sound Effects**: Native Web Audio API (`AudioContext` synthesizer)
- **Celebration**: [Canvas Confetti](https://www.npmjs.com/package/canvas-confetti)

---

## 🚀 Getting Started

### Prerequisites
- [Node.js](https://nodejs.org/) (version 18.17 or higher recommended)
- `npm` or `yarn` or `pnpm`

### Installation

1. **Clone the repository**:
   ```bash
   git clone https://github.com/YOUR_USERNAME/YOUR_REPOSITORY_NAME.git
   cd "jee mains"
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Start the local development server**:
   ```bash
   npm run dev
   ```

4. **Open in browser**:
   Navigate to [http://localhost:3000](http://localhost:3000) to view the platform.

### Build for Production

To create an optimized production build:
```bash
npm run build
npm run start
```

---

## 📄 License
This project is open-source and available under the [MIT License](LICENSE).
