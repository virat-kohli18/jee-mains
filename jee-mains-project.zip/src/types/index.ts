export type PlatformMode = 'jee_main' | 'board_12th';
export type SubjectType = 'physics' | 'chemistry' | 'mathematics';
export type QuestionType = 'MCQ' | 'NUMERICAL';
export type DifficultyLevel = 'Easy' | 'Medium' | 'Hard';
export type PriorityLevel = 'HIGH' | 'MEDIUM' | 'LOWER';
export type ErrorTag = 'conceptual' | 'calculation' | 'formula' | 'misreading' | 'time_management';

export type BoardQuestionFormat = 'MCQ' | 'ASSERTION_REASON' | 'VSA' | 'SA' | 'CASE_BASED' | 'LA';

export interface BoardStepMarking {
  stepDescription: string;
  marks: string;
}

export interface BoardQuestion {
  id: string;
  subject: SubjectType;
  chapterId: string;
  chapterName: string;
  year: number;
  board: string;
  marks: number;
  section: 'A' | 'B' | 'C' | 'D' | 'E';
  format: BoardQuestionFormat;
  questionText: string;
  options?: { A: string; B: string; C: string; D: string };
  correctOption?: 'A' | 'B' | 'C' | 'D';
  assertionText?: string;
  reasonText?: string;
  casePassage?: string;
  subQuestions?: { qNumber: string; question: string; marks: number; answer: string }[];
  modelAnswer: string;
  stepWiseMarking: BoardStepMarking[];
  examinerTips: string[];
  guruJiHinglishAdvice: string;
}

export interface BoardDerivationItem {
  id: string;
  subject: SubjectType;
  chapterName: string;
  title: string;
  expectedMarks: number;
  recurrenceFrequency: string;
  statement: string;
  diagramDescription?: string;
  stepByStepProof: string[];
  finalFormula: string;
  boardPresentationTips: string;
  guruMantraHinglish: string;
}

export type BoardNavTab = 
  | 'board_dashboard'
  | 'board_physics'
  | 'board_chemistry'
  | 'board_maths'
  | 'board_questions'
  | 'board_reactions'
  | 'board_reagents'
  | 'board_derivations'
  | 'board_tricks'
  | 'board_papers'
  | 'board_notes';

export interface BoardNamedReaction {
  id: string;
  name: string;
  chapterName: string;
  reagents: string[];
  substrate: string;
  product: string;
  reactionEquation: string;
  stepByStepMechanism: string[];
  importance: 'Guaranteed' | 'High Importance' | 'Medium Importance';
  boardExamYears: string;
  examinerTrapAlert: string;
  guruJiHinglishTip: string;
}

export interface BoardReagent {
  id: string;
  name: string;
  formula: string;
  category: 'Oxidizing Agent' | 'Reducing Agent' | 'Halogenation / Substitution' | 'Dehydrating / Acid-Base' | 'Distinction Test Reagent';
  primaryFunction: string;
  conversions: { from: string; to: string; equation: string }[];
  limitationsOrTraps: string;
  importance: 'Guaranteed' | 'High Importance' | 'Frequently Asked';
  guruMantraHinglish: string;
}

export interface BoardMathTrick {
  id: string;
  chapterName: string;
  trickTitle: string;
  standardMethodTime: string;
  shortcutTime: string;
  concept: string;
  howItWorks: string;
  formulaOrRule: string;
  exampleProblem: {
    problem: string;
    standardMethod: string;
    shortcutVerification: string;
  };
  boardExamCaution: string;
  guruMantraHinglish: string;
}

export interface BoardFormulaItem {
  id: string;
  subject: SubjectType;
  chapterName: string;
  title: string;
  formulaLatex: string;
  symbolMeanings: { symbol: string; meaning: string }[];
  siUnit: string;
  conditions: string;
  boardRelevance: string;
}

export interface BoardRevisionNote {
  chapterId: string;
  chapterName: string;
  subject: SubjectType;
  marksWeightage: number;
  ncertKeyDefinitions: { term: string; definition: string; formulaOrLaw?: string }[];
  guaranteedQuestions: string[];
  stepMarkingChecklist: string[];
  examinerTrapAlerts: string[];
  guruJiBoardSecretHinglish: string;
}

export interface BoardSamplePaper {
  id: string;
  paperNumber: number;
  subject: SubjectType;
  title: string;
  totalMarks: number;
  timeAllowedHours: number;
  generalInstructions: string[];
  questions: BoardQuestion[];
}

export interface Subtopic {
  id: string;
  name: string;
}

export interface Topic {
  id: string;
  name: string;
  subtopics: Subtopic[];
  weightageRank?: number;
}

export interface Chapter {
  id: string;
  subject: SubjectType;
  name: string;
  code: string;
  priority: PriorityLevel;
  topics: Topic[];
  historicalWeightage: number; // percentage
  avgQuestionsPerPaper: number;
  totalHistoricalQuestions: number;
  recentTrend: 'increasing' | 'stable' | 'decreasing';
  isRationalizedDeleted?: boolean; // strictly tracked
}

export interface PYQSolution {
  correctAnswerText: string;
  conceptTested: string;
  formulaRequired: string;
  stepByStep: string[];
  whyCorrect: string;
  whyOptionsIncorrect?: {
    A?: string;
    B?: string;
    C?: string;
    D?: string;
  };
  shortApproach: string;
  commonMistakes: string;
  examTricks: string;
  relatedConcepts: string[];
}

export interface PYQQuestion {
  id: string;
  subject: SubjectType;
  chapterId: string;
  chapterName: string;
  topicId: string;
  topicName: string;
  year: number; // 2015 to 2024/2025
  session: 'January' | 'April' | 'February' | 'March' | 'July' | 'September';
  shift: 'Shift 1' | 'Shift 2';
  examDate: string;
  questionType: QuestionType;
  difficulty: DifficultyLevel;
  questionText: string;
  options?: {
    A: string;
    B: string;
    C: string;
    D: string;
  };
  correctAnswer: string; // 'A' | 'B' | 'C' | 'D' or numeric string
  numericalAnswer?: number;
  verified: boolean;
  officialSource: string;
  solution: PYQSolution;
}

export interface FormulaItem {
  id: string;
  subject: SubjectType;
  chapterId: string;
  chapterName: string;
  topicName: string;
  title: string;
  formulaLatex: string;
  symbolMeanings: { symbol: string; meaning: string }[];
  siUnits: string;
  application: string;
  conditions: string;
  relatedConcepts: string[];
  exampleProblem: {
    question: string;
    answer: string;
    quickSolution: string;
  };
  pyqRefId?: string;
}

export interface RevisionNotes {
  chapterId: string;
  chapterName: string;
  subject: SubjectType;
  fifteenMinSummary: string[];
  thirtyMinHighYield: {
    coreConcept: string;
    keyFormulas: string[];
    criticalPitfalls: string[];
  }[];
  masterConcepts: {
    heading: string;
    content: string;
    formulas?: string[];
    diagramNote?: string;
  }[];
  shortcutsAndTricks: string[];
  frequentMistakes: string[];
}

export interface ExpectedQuestionPattern {
  id: string;
  subject: SubjectType;
  chapterName: string;
  patternTitle: string;
  historicalHitRate: string;
  whyExpected: string;
  sampleQuestion: string;
  options?: { A: string; B: string; C: string; D: string };
  answer: string;
  solvingInsight: string;
}

export type PaletteStatus = 
  | 'NOT_VISITED'
  | 'NOT_ANSWERED'
  | 'ANSWERED'
  | 'MARKED_FOR_REVIEW'
  | 'ANSWERED_AND_MARKED_FOR_REVIEW';

export interface MockTestQuestionAttempt {
  questionId: string;
  userAnswer?: string;
  status: PaletteStatus;
  timeSpentSeconds: number;
}

export interface MockTestSession {
  id: string;
  title: string;
  type: 'FULL_SYLLABUS' | 'SUBJECT_WISE' | 'CHAPTER_WISE' | 'OFFICIAL_PAPER';
  totalDurationSeconds: number; // 180 * 60 = 10800
  questions: PYQQuestion[];
  subjectDistribution: {
    physics: number;
    chemistry: number;
    mathematics: number;
  };
}

export interface MockTestResult {
  id: string;
  testTitle: string;
  completedAt: string;
  timeSpentSeconds: number;
  totalMarks: number;
  maxMarks: number;
  percentileEstimate: number;
  subjectScores: {
    subject: SubjectType;
    score: number;
    maxScore: number;
    correctCount: number;
    incorrectCount: number;
    unattemptedCount: number;
    accuracyPercent: number;
    timeSpentSeconds: number;
  }[];
  attempts: Record<string, MockTestQuestionAttempt>;
}

export interface ErrorLogItem {
  id: string;
  questionId: string;
  question: PYQQuestion;
  wrongUserAnswer: string;
  correctAnswer: string;
  category: ErrorTag;
  notes: string;
  timestamp: string;
  retried: boolean;
  retriedCorrectly?: boolean;
}

export interface DailyPlanner {
  dailyTargetQuestions: number;
  targetSubjectDistribution: {
    physics: number;
    chemistry: number;
    mathematics: number;
  };
  streakDays: number;
  todayQuestionsSolved: number;
  weakChapterRecommendations: string[];
}
