'use client';

import React, { useState, useEffect } from 'react';
import Sidebar, { NavTab } from '@/components/Sidebar';
import DashboardView from '@/components/views/DashboardView';
import SyllabusView from '@/components/views/SyllabusView';
import PYQBankView from '@/components/views/PYQBankView';
import WeightageView from '@/components/views/WeightageView';
import ExpectedQuestionsView from '@/components/views/ExpectedQuestionsView';
import RevisionCentreView from '@/components/views/RevisionCentreView';
import FormulaBookView from '@/components/views/FormulaBookView';
import ErrorNotebookView from '@/components/views/ErrorNotebookView';
import PlannerView from '@/components/views/PlannerView';
import MockTestCenterView from '@/components/views/MockTestCenterView';
import MockTestSimulator from '@/components/MockTestSimulator';

// Class 12th Board Views
import BoardDashboardView from '@/components/views/BoardDashboardView';
import BoardPhysicsHubView from '@/components/views/BoardPhysicsHubView';
import BoardChemistryHubView from '@/components/views/BoardChemistryHubView';
import BoardMathsHubView from '@/components/views/BoardMathsHubView';
import BoardSyllabusView from '@/components/views/BoardSyllabusView';
import BoardQuestionBankView from '@/components/views/BoardQuestionBankView';
import BoardDerivationsView from '@/components/views/BoardDerivationsView';
import BoardSamplePapersView from '@/components/views/BoardSamplePapersView';
import BoardRevisionNotesView from '@/components/views/BoardRevisionNotesView';

import { loadStudentProfile, StudentProfile, getDefaultProfile } from '@/utils/studentStore';
import { 
  generateNTAFullMockTest, 
  generateSubjectMockTest, 
  getAllPYQQuestions,
  MOCK_TEST_CATALOG
} from '@/data/pyqRepository';
import { 
  Menu, 
  Sparkles, 
  Clock, 
  Target, 
  BookOpen, 
  Award, 
  GraduationCap,
  FileText,
  Zap,
  Layers
} from 'lucide-react';
import { PlatformMode, BoardNavTab, SubjectType } from '@/types';

export default function HomePage() {
  const [mode, setMode] = useState<PlatformMode>('jee_main');
  const [jeeTab, setJeeTab] = useState<NavTab>('dashboard');
  const [boardTab, setBoardTab] = useState<BoardNavTab>('board_dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const [profile, setProfile] = useState<StudentProfile>(getDefaultProfile());
  const [isMockRunning, setIsMockRunning] = useState<boolean>(false);
  const [mockTestData, setMockTestData] = useState<any>(null);

  // Load student profile on mount
  useEffect(() => {
    setProfile(loadStudentProfile());
  }, []);

  const refreshProfile = () => {
    setProfile(loadStudentProfile());
  };

  const allQuestions = getAllPYQQuestions();
  const totalPYQCount = allQuestions.length;

  // Countdown calculations
  const jeeTargetDate = new Date('2027-01-24T09:00:00+05:30');
  const boardTargetDate = new Date('2027-02-15T10:30:00+05:30');
  const today = new Date();
  
  const jeeDays = Math.max(0, Math.ceil((jeeTargetDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)));
  const boardDays = Math.max(0, Math.ceil((boardTargetDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)));

  const handleLaunchSpecificMockTest = (mockId: string) => {
    const test = generateNTAFullMockTest(mockId);
    setMockTestData(test);
    setIsMockRunning(true);
  };

  const handleLaunchSubjectTest = (subject: SubjectType) => {
    const test = generateSubjectMockTest(subject);
    setMockTestData(test);
    setIsMockRunning(true);
  };

  const handleLaunchDefaultMock = () => {
    const attemptedTitles = profile.mockTestResults.map((r) => r.testTitle);
    const nextMock = MOCK_TEST_CATALOG.find((m) => !attemptedTitles.some((t) => t.includes(m.title))) || MOCK_TEST_CATALOG[0];
    handleLaunchSpecificMockTest(nextMock.id);
  };

  const handleExitMockTest = () => {
    setIsMockRunning(false);
    refreshProfile();
    setJeeTab('mocktest');
  };

  // If mock test is active, render full-screen NTA test interface
  if (isMockRunning && mockTestData) {
    return (
      <MockTestSimulator
        testTitle={mockTestData.title}
        durationSeconds={mockTestData.durationSeconds}
        questions={mockTestData.questions}
        onExitTest={handleExitMockTest}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#0b0f19] text-slate-100 flex">
      {/* Sidebar Navigation */}
      <Sidebar
        currentMode={mode}
        onSelectMode={(newMode) => {
          setMode(newMode);
        }}
        activeJeeTab={jeeTab}
        onSelectJeeTab={(tab) => {
          setJeeTab(tab);
        }}
        activeBoardTab={boardTab}
        onSelectBoardTab={(tab) => {
          setBoardTab(tab);
        }}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        totalPYQCount={totalPYQCount}
      />

      {/* Main Content Area */}
      <div className="flex-1 lg:pl-72 flex flex-col min-w-0">
        {/* Top Navbar with Mode Selector */}
        <header className="sticky top-0 z-30 bg-[#0b0f19]/90 backdrop-blur-md border-b border-slate-800/80 px-4 md:px-8 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsSidebarOpen(true)}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 lg:hidden cursor-pointer"
            >
              <Menu className="w-5 h-5" />
            </button>

            {/* Mode Switcher Pill in Top Navbar */}
            <div className="bg-slate-900 border border-slate-800 p-1 rounded-2xl flex items-center gap-1 shadow-inner">
              <button
                onClick={() => setMode('jee_main')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                  mode === 'jee_main'
                    ? 'bg-gradient-to-r from-indigo-600 to-sky-600 text-white shadow-md shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Target className="w-3.5 h-3.5" />
                <span>JEE Main</span>
              </button>
              <button
                onClick={() => setMode('board_12th')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                  mode === 'board_12th'
                    ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-600/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <GraduationCap className="w-3.5 h-3.5" />
                <span>12th Boards</span>
              </button>
            </div>

            {/* Current Active Subtitle */}
            <div className="hidden xl:flex items-center gap-2 pl-2">
              <span className="text-slate-500 font-bold">&bull;</span>
              <span className="text-xs font-bold text-slate-300">
                {mode === 'jee_main' ? (
                  jeeTab === 'dashboard' ? 'JEE Preparation Dashboard' :
                  jeeTab === 'syllabus' ? 'NTA Rationalized Syllabus' :
                  jeeTab === 'pyqs' ? '2,000+ Verified Authentic PYQs' :
                  jeeTab === 'weightage' ? '10-Year Weightage & Trends' :
                  jeeTab === 'expected' ? 'Most Expected Questions' :
                  jeeTab === 'revision' ? 'Chapter Revision Centre' :
                  jeeTab === 'formulas' ? 'Formula Books' :
                  jeeTab === 'mocktest' ? '10 Full NTA Mock Tests' :
                  jeeTab === 'errors' ? 'Automated Error Notebook' : 'Smart Study Planner'
                ) : (
                  boardTab === 'board_dashboard' ? '12th Board Examination Dashboard' :
                  boardTab === 'board_physics' ? 'Class 12 Physics (Derivations, Formulas & 334 Qs)' :
                  boardTab === 'board_chemistry' ? 'Class 12 Chemistry (Named Reactions, Reagents & 334 Qs)' :
                  boardTab === 'board_maths' ? 'Class 12 Mathematics (Formulas, Speed Tricks & 334 Qs)' :
                  boardTab === 'board_questions' ? '1,000+ Verified Authentic Board Questions' :
                  boardTab === 'board_reactions' ? 'Organic Chemistry Named Reactions Directory' :
                  boardTab === 'board_reagents' ? 'Organic Chemistry Reagents Master Guide' :
                  boardTab === 'board_derivations' ? 'Must-Do 3M & 5M Derivations Directory' :
                  boardTab === 'board_tricks' ? 'Maths Exam Verification & Speed Tricks' :
                  boardTab === 'board_papers' ? 'Official 3-Hour Board Sample Papers' : 'NCERT Quick Revision Notes'
                )}
              </span>
            </div>
          </div>

          {/* Quick Header Indicators */}
          <div className="flex items-center gap-3">
            {/* Guru Ji Mentorship Indicator */}
            <div className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs font-bold text-amber-300">
              <GraduationCap className="w-4 h-4 text-amber-400" />
              <span>Kota Teacher Hinglish Active</span>
            </div>

            {/* Target Days Countdown */}
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-slate-400">
                {mode === 'jee_main' ? 'JEE 2027:' : 'Boards 2027:'}
              </span>
              <strong className="text-amber-400 font-mono">
                {mode === 'jee_main' ? jeeDays : boardDays} Days
              </strong>
            </div>

            {/* Quick Action Button */}
            {mode === 'jee_main' ? (
              <button
                onClick={handleLaunchDefaultMock}
                className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl text-xs transition-all shadow-md shadow-indigo-600/20 flex items-center gap-1.5 cursor-pointer"
              >
                <Award className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">NTA Full Mock</span>
                <span className="sm:hidden">Mock</span>
              </button>
            ) : (
              <button
                onClick={() => setBoardTab('board_papers')}
                className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-xl text-xs transition-all shadow-md shadow-emerald-600/20 flex items-center gap-1.5 cursor-pointer"
              >
                <FileText className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Sample Papers</span>
                <span className="sm:hidden">Papers</span>
              </button>
            )}
          </div>
        </header>

        {/* View Container */}
        <main className="flex-1 p-4 md:p-8 max-w-7xl w-full mx-auto">
          {/* ===================== SECTION 1: JEE MAIN ===================== */}
          {mode === 'jee_main' && (
            <>
              {jeeTab === 'dashboard' && (
                <DashboardView
                  profile={profile}
                  totalPYQCount={totalPYQCount}
                  onNavigate={(tab) => {
                    setJeeTab(tab);
                    if (tab === 'mocktest') handleLaunchDefaultMock();
                  }}
                  onLaunchMockTest={handleLaunchDefaultMock}
                />
              )}

              {jeeTab === 'syllabus' && <SyllabusView />}

              {jeeTab === 'pyqs' && <PYQBankView />}

              {jeeTab === 'weightage' && <WeightageView />}

              {jeeTab === 'expected' && <ExpectedQuestionsView />}

              {jeeTab === 'revision' && <RevisionCentreView />}

              {jeeTab === 'formulas' && <FormulaBookView />}

              {jeeTab === 'mocktest' && (
                <MockTestCenterView
                  profile={profile}
                  onSelectMockTest={handleLaunchSpecificMockTest}
                  onSelectSubjectTest={handleLaunchSubjectTest}
                />
              )}

              {jeeTab === 'errors' && (
                <ErrorNotebookView profile={profile} onProfileUpdated={refreshProfile} />
              )}

              {jeeTab === 'planner' && (
                <PlannerView
                  profile={profile}
                  onProfileUpdated={refreshProfile}
                  onNavigate={setJeeTab}
                  onLaunchMockTest={handleLaunchDefaultMock}
                />
              )}
            </>
          )}

          {/* ===================== SECTION 2: CLASS 12TH BOARDS ===================== */}
          {mode === 'board_12th' && (
            <>
              {boardTab === 'board_dashboard' && (
                <BoardDashboardView
                  onNavigate={(tab) => {
                    setBoardTab(tab);
                  }}
                />
              )}

              {boardTab === 'board_physics' && <BoardPhysicsHubView />}

              {boardTab === 'board_chemistry' && <BoardChemistryHubView />}

              {boardTab === 'board_maths' && <BoardMathsHubView />}

              {boardTab === 'board_questions' && <BoardQuestionBankView />}

              {boardTab === 'board_reactions' && <BoardChemistryHubView />}

              {boardTab === 'board_reagents' && <BoardChemistryHubView />}

              {boardTab === 'board_derivations' && <BoardDerivationsView />}

              {boardTab === 'board_tricks' && <BoardMathsHubView />}

              {boardTab === 'board_papers' && <BoardSamplePapersView />}

              {boardTab === 'board_notes' && <BoardRevisionNotesView />}
            </>
          )}
        </main>
      </div>
    </div>
  );
}
