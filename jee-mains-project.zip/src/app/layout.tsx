import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'JEE Main Preparation Platform 2027 | Paper 1 (Physics, Chemistry, Maths)',
  description:
    'Complete JEE Main Paper 1 preparation platform with 2,000+ authentic PYQs, official NTA rationalized syllabus, 10-point textbook solutions, 3-hour mock exam simulator, chapter weightage, and error notebook.',
  keywords: [
    'JEE Main 2027',
    'JEE Main PYQ',
    'NTA Mock Test',
    'JEE Main Syllabus',
    'Physics PYQ',
    'Chemistry PYQ',
    'Maths PYQ',
    'JEE Main Formula Book',
  ],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body className="bg-[#0b0f19] text-slate-100 antialiased min-h-screen selection:bg-indigo-500 selection:text-white">
        {children}
      </body>
    </html>
  );
}
