import { PYQQuestion, ErrorTag } from '@/types';

export interface GuruAdvice {
  headline: string;
  salutation: string;
  explanationHinglish: string;
  guruMantraTrick: string;
  commonTrapWarning: string;
  motivationalQuote: string;
}

export const getGuruAdvice = (
  question: PYQQuestion,
  isCorrect: boolean,
  userAnswer?: string,
  errorTag: ErrorTag = 'conceptual'
): GuruAdvice => {
  const { subject, chapterName, topicName, questionType, correctAnswer, solution } = question;

  if (isCorrect) {
    return {
      salutation: 'Shabash mere sher/sherni! 👏',
      headline: `Zabardast! Correct Answer (+4 Marks) pakke!`,
      explanationHinglish: `Beta, tumne bilkul sahi solve kiya! Yahan concept tested tha: "${solution.conceptTested}". Tumne jo approach lagayi wo perfectly sound hai. Examiner ne option A/B/C/D mein traps dale the, lekin tum distract nahi hue.`,
      guruMantraTrick: `💡 Guru Mantra (Speed Trick): Beta, exam mein agar time bachana ho toh: ${solution.shortApproach || 'Pehle options ka order of magnitude check karo, 50% options bina lambi calculation ke eliminate ho jaate hain!'}`,
      commonTrapWarning: `⚠️ Pro Alert: Is question mein lagbhag 40% bacche jaldi-baazi mein negative marking khaa jaate hain. Tumne cool mind se solve kiya, yahi temperament JEE Main ke day-1 par chahiye!`,
      motivationalQuote: 'Consistency hi topper banati hai beta! Agla question bhi aise hi focus ke sath uda do! 🚀',
    };
  }

  // If Incorrect:
  let specificAdvice = '';
  if (errorTag === 'calculation') {
    specificAdvice = `Beta, calculation mein jaldi-baazi ho gayi! Dekho, formula tumhe pata tha, lekin numbers put karte waqt unit conversion (jaise cm to m, ya mA to A) ya decimal point slip ho gaya. JEE Main mein 5-10 marks sirf silly calculation mistakes ki wajah se cut jaate hain.`;
  } else if (errorTag === 'formula') {
    specificAdvice = `Beta, formula thoda mix-up ho gaya! Yahan required formula tha: ${solution.formulaRequired}. Isko formula book mein abhi star-mark kar lo. Exam room mein pressure mein formula tabhi yaad rehta hai jab use 3-4 baar likh ke revise kiya ho.`;
  } else if (errorTag === 'misreading') {
    specificAdvice = `Beta, question dhyan se padha tha kya? Examiner aksar "NOT correct", "increasing order", ya "ratio of solid to shell" puchta hai aur bacche ulta tick kar aate hain! Question ki last line ko hamesha underline karne ki aadat dalo.`;
  } else {
    // Conceptual
    specificAdvice = `Dekho beta, yahan concept samajhna zaroori hai. "${solution.conceptTested}" par question based tha. Tumne jo answer diya (${userAnswer || 'attempt'}), examiner ne wo option purposefully distract karne ke liye rakha tha. Sahi answer "${correctAnswer}" isliye hai kyunki ${solution.whyCorrect}`;
  }

  return {
    salutation: 'Arre beta, ghabrao mat! Main hu na! 🤝',
    headline: `Yahan mistake ho gayi (-1 Mark), lekin sikho kaise theek karein:`,
    explanationHinglish: `${specificAdvice} 

Step-by-Step samjho beta:
1. Sabse pehle identify karo: ${solution.stepByStep[0] || 'Given quantities likho aur units check karo.'}
2. Agla step: ${solution.stepByStep[1] || 'Proper formula apply karo bina shortcuts ke.'}
3. Final evaluation: ${solution.stepByStep[2] || 'Substitute karke answer match karo.'}`,
    guruMantraTrick: `⚡ Kota Teacher Secret Trick: "${solution.shortApproach || solution.examTricks || 'Hamesha dimensional check ya extreme value substitution laga ke cross-verify kar liya karo!'}"`,
    commonTrapWarning: `🚨 Examiner ka Favourite Trap: ${solution.commonMistakes || 'Bacche aksar boundary conditions bhool jaate hain aur galat option tick kar dete hain.'}`,
    motivationalQuote: 'Beta, mock test mein galti hona blessing hai! Yahan galti kar li toh main exam mein 100% sahi hoga. Ye question tumhare Error Notebook mein save ho chuka hai, shaam ko ek baar retry zaroor karna! 💪',
  };
};
