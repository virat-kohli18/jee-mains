'use client';

import { ErrorLogItem, ErrorTag, MockTestResult, PYQQuestion, SubjectType } from '@/types';
import { getQuestionById } from '@/data/pyqRepository';

export interface StudentProfile {
  name: string;
  targetYear: number;
  dailyGoal: number;
  streakDays: number;
  lastActiveDate: string;
  solvedQuestionIds: Record<string, { isCorrect: boolean; timestamp: string }>;
  bookmarkedQuestionIds: string[];
  errorNotebook: ErrorLogItem[];
  mockTestResults: MockTestResult[];
}

const STORAGE_KEY = 'jee_main_student_profile_v1';

export const getDefaultProfile = (): StudentProfile => ({
  name: 'JEE Aspirant',
  targetYear: 2027,
  dailyGoal: 25,
  streakDays: 4,
  lastActiveDate: new Date().toISOString().split('T')[0],
  solvedQuestionIds: {},
  bookmarkedQuestionIds: [],
  errorNotebook: [],
  mockTestResults: [],
});

export const loadStudentProfile = (): StudentProfile => {
  if (typeof window === 'undefined') return getDefaultProfile();
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const def = getDefaultProfile();
      localStorage.setItem(STORAGE_KEY, JSON.stringify(def));
      return def;
    }
    return JSON.parse(raw);
  } catch {
    return getDefaultProfile();
  }
};

export const saveStudentProfile = (profile: StudentProfile): void => {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
  } catch (err) {
    console.error('Failed to save profile', err);
  }
};

export const recordQuestionAttempt = (
  question: PYQQuestion,
  userAnswer: string,
  isCorrect: boolean,
  errorTag: ErrorTag = 'conceptual'
): StudentProfile => {
  const profile = loadStudentProfile();

  profile.solvedQuestionIds[question.id] = {
    isCorrect,
    timestamp: new Date().toISOString(),
  };

  // If wrong, automatically record in Error Notebook
  if (!isCorrect) {
    const existingIndex = profile.errorNotebook.findIndex((e) => e.questionId === question.id);
    const newEntry: ErrorLogItem = {
      id: `err-${Date.now()}-${question.id}`,
      questionId: question.id,
      question,
      wrongUserAnswer: userAnswer,
      correctAnswer: question.correctAnswer,
      category: errorTag,
      notes: `Recorded on ${new Date().toLocaleDateString()}`,
      timestamp: new Date().toISOString(),
      retried: false,
    };

    if (existingIndex >= 0) {
      profile.errorNotebook[existingIndex] = newEntry;
    } else {
      profile.errorNotebook.unshift(newEntry);
    }
  }

  saveStudentProfile(profile);
  return profile;
};

export const markErrorRetried = (errorId: string, correctlySolved: boolean): StudentProfile => {
  const profile = loadStudentProfile();
  const item = profile.errorNotebook.find((e) => e.id === errorId);
  if (item) {
    item.retried = true;
    item.retriedCorrectly = correctlySolved;
    saveStudentProfile(profile);
  }
  return profile;
};

export const toggleBookmark = (questionId: string): boolean => {
  const profile = loadStudentProfile();
  const index = profile.bookmarkedQuestionIds.indexOf(questionId);
  let isBookmarked = false;
  if (index >= 0) {
    profile.bookmarkedQuestionIds.splice(index, 1);
    isBookmarked = false;
  } else {
    profile.bookmarkedQuestionIds.push(questionId);
    isBookmarked = true;
  }
  saveStudentProfile(profile);
  return isBookmarked;
};

export const saveMockResult = (result: MockTestResult): StudentProfile => {
  const profile = loadStudentProfile();
  profile.mockTestResults.unshift(result);
  saveStudentProfile(profile);
  return profile;
};
