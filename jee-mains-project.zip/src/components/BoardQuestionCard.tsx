'use client';

import React, { useState } from 'react';
import { BoardQuestion, ErrorTag } from '@/types';
import MathRenderer from './MathRenderer';
import { soundEffects, triggerConfetti } from '@/utils/soundEffects';
import { 
  CheckCircle, 
  XCircle, 
  Bookmark, 
  ChevronDown, 
  ChevronUp, 
  Sparkles, 
  AlertTriangle, 
  Zap, 
  BookOpen, 
  GraduationCap, 
  CheckSquare2,
  Award,
  FileText,
  RotateCcw
} from 'lucide-react';

interface BoardQuestionCardProps {
  question: BoardQuestion;
  questionNumber?: number;
}

export const BoardQuestionCard: React.FC<BoardQuestionCardProps> = ({
  question,
  questionNumber,
}) => {
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [showExplanation, setShowExplanation] = useState<boolean>(false);
  const [isBookmarked, setIsBookmarked] = useState<boolean>(false);

  // Extract correct option letter from question.correctOption or modelAnswer (e.g., "Correct Option: (A)" or "(B)")
  const getCorrectOption = (): string => {
    if (question.correctOption) return question.correctOption.toUpperCase();
    const match = question.modelAnswer.match(/Correct Option:\s*\(([A-D])\)/i);
    if (match && match[1]) return match[1].toUpperCase();
    const fallbackMatch = question.modelAnswer.match(/\(([A-D])\)/i);
    if (fallbackMatch && fallbackMatch[1]) return fallbackMatch[1].toUpperCase();
    return 'A'; // standard fallback
  };

  const correctOption = getCorrectOption();
  const isInteractiveChoice = (question.format === 'MCQ' || question.format === 'ASSERTION_REASON') && !!question.options;

  // Handle clicking an MCQ / Assertion-Reason option
  const handleOptionClick = (optKey: string) => {
    if (submitted) return;

    // Play pop sound immediately
    soundEffects.playPop();

    const correct = optKey.toUpperCase() === correctOption.toUpperCase();
    setSelectedOption(optKey);
    setSubmitted(true);
    setIsCorrect(correct);

    if (correct) {
      setTimeout(() => {
        soundEffects.playSuccess();
        triggerConfetti();
      }, 50);
    } else {
      setTimeout(() => {
        soundEffects.playIncorrect();
      }, 50);
    }

    // Automatically expand the full explanation in English
    setShowExplanation(true);
  };

  // Handle toggle for descriptive / 2M-5M questions
  const handleToggleExplanation = () => {
    soundEffects.playPop();
    setShowExplanation(!showExplanation);
  };

  const handleReset = () => {
    soundEffects.playPop();
    setSelectedOption(null);
    setSubmitted(false);
    setIsCorrect(null);
    setShowExplanation(false);
  };

  const handleToggleBookmark = () => {
    soundEffects.playPop();
    setIsBookmarked(!isBookmarked);
  };

  // Color theme by subject
  const subjectBadge =
    question.subject === 'physics'
      ? 'border-sky-500/30 text-sky-400 bg-sky-500/10'
      : question.subject === 'chemistry'
      ? 'border-emerald-500/30 text-emerald-400 bg-emerald-500/10'
      : 'border-rose-500/30 text-rose-400 bg-rose-500/10';

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 md:p-6 mb-5 shadow-xl transition-all duration-200 hover:border-slate-700">
      {/* Top Meta Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-4 pb-3 border-b border-slate-800/80">
        <div className="flex flex-wrap items-center gap-2">
          {questionNumber !== undefined && (
            <span className="w-7 h-7 rounded-lg bg-slate-800 text-slate-200 flex items-center justify-center font-bold text-xs font-mono">
              Q{questionNumber}
            </span>
          )}

          {/* Question ID */}
          <span className="font-mono text-xs px-2.5 py-1 rounded-md bg-slate-800/90 text-slate-300 font-semibold">
            {question.id}
          </span>

          {/* Subject Badge */}
          <span className={`text-xs px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider border ${subjectBadge}`}>
            {question.subject}
          </span>

          {/* Board & Year */}
          <span className="text-[11px] text-slate-400 px-2 py-0.5 rounded bg-slate-800/50 border border-slate-700/50">
            {question.board} &bull; {question.year}
          </span>

          {/* Format Badge */}
          <span className="text-[11px] text-slate-300 px-2 py-0.5 rounded bg-slate-800/80 border border-slate-700">
            Section {question.section} &bull; {question.format}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Marks Badge */}
          <span className="text-xs px-2.5 py-1 rounded-lg font-black font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            {question.marks} {question.marks === 1 ? 'Mark' : 'Marks'}
          </span>

          {/* Bookmark Button */}
          <button
            onClick={handleToggleBookmark}
            title={isBookmarked ? 'Bookmarked' : 'Bookmark this question'}
            className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
              isBookmarked
                ? 'bg-amber-500/20 border-amber-500/40 text-amber-400'
                : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:text-white'
            }`}
          >
            <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-amber-400' : ''}`} />
          </button>
        </div>
      </div>

      {/* Chapter Breadcrumb */}
      <div className="text-xs text-slate-400 mb-3 flex items-center gap-2 flex-wrap">
        <span className="text-slate-300 font-bold">{question.chapterName}</span>
        <span className="text-slate-600">&bull;</span>
        <span className="text-emerald-400 font-medium">CBSE Class 12 Syllabus</span>
      </div>

      {/* Case Study Passage (if present) */}
      {question.format === 'CASE_BASED' && question.casePassage && (
        <div className="p-4 rounded-2xl bg-indigo-950/20 border border-indigo-500/30 mb-4 space-y-1.5">
          <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
            <FileText className="w-4 h-4" />
            Case Study Passage:
          </span>
          <p className="text-xs md:text-sm text-slate-200 italic leading-relaxed">
            &quot;{question.casePassage}&quot;
          </p>
        </div>
      )}

      {/* Question Text */}
      <div className="text-slate-100 text-base md:text-lg leading-relaxed mb-4 font-normal">
        <MathRenderer content={question.questionText} />
      </div>

      {/* Assertion-Reason Distinct Box (if present) */}
      {question.format === 'ASSERTION_REASON' && (
        <div className="space-y-2 p-4 rounded-2xl bg-slate-950 border border-slate-800 mb-4">
          {question.assertionText && (
            <div className="text-xs md:text-sm text-amber-300 font-semibold leading-relaxed">
              <MathRenderer content={question.assertionText} />
            </div>
          )}
          {question.reasonText && (
            <div className="text-xs md:text-sm text-sky-300 font-semibold leading-relaxed">
              <MathRenderer content={question.reasonText} />
            </div>
          )}
        </div>
      )}

      {/* ================= INTERACTIVE CLICKABLE OPTIONS (JEE MAIN FORMAT) ================= */}
      {isInteractiveChoice && question.options && (() => {
        const options = question.options;
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-5">
            {(['A', 'B', 'C', 'D'] as const).map((optKey) => {
              const isSelected = selectedOption === optKey;
              const isOptionCorrect = optKey === correctOption;

              let optStyle = 'border-slate-800 bg-slate-800/40 hover:border-emerald-500/50 hover:bg-slate-800/80 text-slate-200';
              if (submitted) {
                if (isOptionCorrect) {
                  optStyle = 'border-emerald-500 bg-emerald-500/20 text-emerald-300 ring-2 ring-emerald-500';
                } else if (isSelected && !isOptionCorrect) {
                  optStyle = 'border-rose-500 bg-rose-500/20 text-rose-300 ring-2 ring-rose-500';
                } else {
                  optStyle = 'border-slate-800/60 bg-slate-900/40 text-slate-500 opacity-60';
                }
              } else if (isSelected) {
                optStyle = 'border-emerald-500 bg-emerald-500/20 text-white';
              }

              return (
                <button
                  key={optKey}
                  disabled={submitted}
                  onClick={() => handleOptionClick(optKey)}
                  className={`flex items-start gap-3 p-3.5 rounded-xl border text-left transition-all duration-150 cursor-pointer disabled:cursor-default shadow-sm ${optStyle}`}
                >
                  <span className="w-7 h-7 rounded-lg bg-slate-900/90 border border-slate-700/80 flex items-center justify-center text-xs font-black shrink-0 mt-0.5 font-mono">
                    {optKey}
                  </span>
                  <div className="text-xs md:text-sm flex-1 pt-0.5 font-medium">
                    <MathRenderer content={options[optKey]} inline />
                  </div>
                  {submitted && isOptionCorrect && (
                    <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5 animate-bounce" />
                  )}
                  {submitted && isSelected && !isOptionCorrect && (
                    <XCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                  )}
                </button>
              );
            })}
          </div>
        );
      })()}

      {/* Sub-Questions for Case Study */}
      {question.subQuestions && question.subQuestions.length > 0 && (
        <div className="space-y-2.5 mb-5">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
            Sub-Questions (Answer Each Part):
          </span>
          {question.subQuestions.map((sq) => (
            <div
              key={sq.qNumber}
              className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start justify-between gap-3 text-xs"
            >
              <div className="space-y-1 text-slate-200">
                <strong className="text-white">Part ({sq.qNumber}):</strong> {sq.question}
              </div>
              <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-bold shrink-0 font-mono">
                [{sq.marks}M]
              </span>
            </div>
          ))}
        </div>
      )}

      {/* Immediate Interactive Feedback Banner after Selection */}
      {submitted && (
        <div
          className={`p-4 rounded-2xl mb-5 border animate-fadeIn flex items-center justify-between gap-3 ${
            isCorrect
              ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-200'
              : 'bg-rose-950/40 border-rose-500/50 text-rose-200'
          }`}
        >
          <div className="flex items-center gap-3">
            {isCorrect ? (
              <CheckCircle className="w-6 h-6 text-emerald-400 shrink-0" />
            ) : (
              <XCircle className="w-6 h-6 text-rose-400 shrink-0" />
            )}
            <div>
              <strong className="text-sm font-black block">
                {isCorrect ? 'Correct Answer! Outstanding Analysis.' : 'Incorrect Choice.'}
              </strong>
              <span className="text-xs text-slate-300">
                {isCorrect
                  ? `Option (${correctOption}) is the accurate scientific answer according to CBSE evaluation.`
                  : `Option (${selectedOption}) was selected. The correct board answer is Option (${correctOption}).`}
              </span>
            </div>
          </div>

          <button
            onClick={handleReset}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 font-bold flex items-center gap-1.5 transition-all cursor-pointer border border-slate-700 shrink-0"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Try Again</span>
          </button>
        </div>
      )}

      {/* Action Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
        <button
          onClick={handleToggleExplanation}
          className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs flex items-center gap-2 transition-all cursor-pointer shadow-md shadow-emerald-600/20"
        >
          <BookOpen className="w-4 h-4" />
          <span>{showExplanation ? 'Hide Full Explanation' : 'View Full Explanation in English'}</span>
          {showExplanation ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
        </button>

        <span className="text-xs text-slate-400 italic">
          {question.format === 'MCQ' || question.format === 'ASSERTION_REASON'
            ? 'Click any option to test & pop explanation'
            : 'Descriptive board question with step-marking'}
        </span>
      </div>

      {/* ================= FULL EXPLANATION IN ENGLISH (JEE MAIN FORMAT) ================= */}
      {showExplanation && (
        <div className="mt-5 pt-5 border-t border-slate-800 space-y-5 animate-fadeIn">
          {/* Section 1: Concept Tested & Model Topper Answer */}
          <div className="p-5 rounded-2xl bg-slate-950 border border-emerald-500/30 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-black text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                <Award className="w-4 h-4 text-emerald-400" />
                1. Concept Tested &amp; Model Topper Answer (in English):
              </span>
              <span className="text-[11px] text-slate-400 font-mono">Full Marks Format</span>
            </div>

            <div className="text-xs md:text-sm text-slate-200 leading-relaxed font-sans whitespace-pre-line bg-slate-900/80 p-4 rounded-xl border border-slate-800 font-mono">
              {question.modelAnswer}
            </div>
          </div>

          {/* Section 2: Official Step-Wise Marking Breakdown */}
          {question.stepWiseMarking && question.stepWiseMarking.length > 0 && (
            <div className="p-5 rounded-2xl bg-slate-950 border border-amber-500/30 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <span className="text-xs font-black text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                  <CheckSquare2 className="w-4 h-4 text-amber-400" />
                  2. Official CBSE Step-Wise Marking Breakdown:
                </span>
                <span className="text-xs text-amber-400 font-bold font-mono">
                  Total: {question.marks} Marks
                </span>
              </div>

              <div className="space-y-2">
                {question.stepWiseMarking.map((step, sIdx) => (
                  <div
                    key={sIdx}
                    className="flex items-start justify-between gap-3 p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs"
                  >
                    <div className="flex items-start gap-2.5 text-slate-300">
                      <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                        {sIdx + 1}
                      </span>
                      <span className="leading-relaxed">{step.stepDescription}</span>
                    </div>
                    <span className="px-2.5 py-1 rounded-lg bg-amber-500/10 text-amber-400 font-bold shrink-0 border border-amber-500/20 font-mono text-xs">
                      {step.marks}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Section 3: Examiner Pitfalls & Warnings */}
          {question.examinerTips && question.examinerTips.length > 0 && (
            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1.5 text-xs text-slate-300">
              <span className="text-sky-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4" />
                3. Examiner Presentation Tips &amp; Common Pitfalls:
              </span>
              <ul className="list-disc list-inside space-y-1 text-slate-300 pt-1 leading-relaxed">
                {question.examinerTips.map((tip, tIdx) => (
                  <li key={tIdx}>{tip}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Section 4: Kota Educator / Guru Ji Hinglish Coaching */}
          {question.guruJiHinglishAdvice && (
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3 text-xs md:text-sm text-amber-200">
              <GraduationCap className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-amber-300 font-bold block mb-0.5 uppercase tracking-wider text-xs">
                  4. Guru Ji Kota Mentorship Secret:
                </strong>
                <p className="leading-relaxed">
                  &quot;{question.guruJiHinglishAdvice}&quot;
                </p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default BoardQuestionCard;
