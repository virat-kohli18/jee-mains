'use client';

import React, { useState } from 'react';
import { PYQQuestion, ErrorTag } from '@/types';
import { getGuruAdvice } from '@/utils/guruMentor';
import MathRenderer from './MathRenderer';
import { 
  GraduationCap, 
  Sparkles, 
  AlertTriangle, 
  CheckCircle2, 
  MessageSquare, 
  ChevronDown, 
  ChevronUp,
  HeartHandshake,
  Lightbulb
} from 'lucide-react';

interface GuruMentorBoxProps {
  question: PYQQuestion;
  isCorrect?: boolean | null;
  userAnswer?: string;
  errorTag?: ErrorTag;
}

export const GuruMentorBox: React.FC<GuruMentorBoxProps> = ({
  question,
  isCorrect = false,
  userAnswer = '',
  errorTag = 'conceptual',
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(true);
  const [selectedQuickDoubt, setSelectedQuickDoubt] = useState<string | null>(null);

  const advice = getGuruAdvice(question, !!isCorrect, userAnswer, errorTag);

  const quickDoubts: Record<string, string> = {
    'Speed kaise badhayein?':
      'Beta, speed calculation se nahi, elimination se aati hai! Pehle 10 seconds mein options dekho. Agar units ya powers alag hain, toh poori value solve karne ki zaroorat hi nahi hoti!',
    'Exam mein panic kaise rokein?':
      'Dekho beta, agar koi question 90 seconds mein samajh na aaye, toh ego par mat lo! Use "Mark for Review" karke aage badho. JEE Main mein 75 mein se 50 question chun ke sahi karna hi 99 percentile dila deta hai!',
    'Section B (Numericals) mein marks kaise score karein?':
      'Section B mein hamesha integer rounding rules padha karo! Agar answer 4.98 aaye aur nearest integer pucha ho, toh 5 likhna. Decimal ki rounding mein bacche 4 marks gawa dete hain.',
  };

  return (
    <div className="mt-4 rounded-xl border border-amber-500/30 bg-gradient-to-b from-amber-950/20 via-slate-900 to-slate-950 p-4 md:p-5 shadow-xl transition-all">
      {/* Teacher Header Bar */}
      <div
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center justify-between cursor-pointer border-b border-amber-500/20 pb-3"
      >
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 flex items-center justify-center text-slate-950 font-bold shadow-md shadow-amber-500/20">
            <GraduationCap className="w-5 h-5 text-slate-950" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                Kota Teacher Mentorship
              </span>
              <span className="text-[10px] px-2 py-0.2 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                Hinglish Guru Mode 👨‍🏫
              </span>
            </div>
            <h4 className="text-sm font-extrabold text-white">
              {advice.salutation}
            </h4>
          </div>
        </div>

        <button className="text-amber-400 p-1 hover:text-white transition-colors">
          {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
      </div>

      {/* Teacher Mentorship Drawer */}
      {isOpen && (
        <div className="pt-4 space-y-4 text-xs md:text-sm text-slate-200">
          {/* Main Teacher Talk */}
          <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 space-y-2">
            <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
              <MessageSquare className="w-3.5 h-3.5 text-amber-400" /> {advice.headline}
            </span>
            <div className="text-slate-300 leading-relaxed whitespace-pre-line text-xs md:text-sm">
              <MathRenderer content={advice.explanationHinglish} />
            </div>
          </div>

          {/* Kota Guru Mantra */}
          <div className="bg-indigo-950/30 p-3.5 rounded-xl border border-indigo-500/30 space-y-1.5">
            <span className="text-xs font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" /> Kota Teacher Secret Trick (Guru Mantra)
            </span>
            <p className="text-indigo-200/90 text-xs md:text-sm font-medium">
              <MathRenderer content={advice.guruMantraTrick} inline />
            </p>
          </div>

          {/* Trap Alert */}
          <div className="bg-rose-950/20 p-3 rounded-xl border border-rose-500/30 text-rose-200/90 text-xs flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-rose-400 block mb-0.5">Examiner ka Trap:</strong>
              <span>{advice.commonTrapWarning}</span>
            </div>
          </div>

          {/* Motivational Quote */}
          <div className="p-2.5 rounded-lg bg-emerald-950/20 border border-emerald-500/20 text-emerald-300 text-xs flex items-center gap-2 font-medium">
            <HeartHandshake className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{advice.motivationalQuote}</span>
          </div>

          {/* Teacher Quick Q&A Pills */}
          <div className="pt-2 border-t border-slate-800/80">
            <span className="text-[11px] uppercase font-bold text-slate-400 block mb-2">
              Ask Sir / Quick Guidance Pills:
            </span>
            <div className="flex flex-wrap gap-2">
              {Object.keys(quickDoubts).map((doubt) => (
                <button
                  key={doubt}
                  onClick={() =>
                    setSelectedQuickDoubt(selectedQuickDoubt === doubt ? null : doubt)
                  }
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                    selectedQuickDoubt === doubt
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {doubt}
                </button>
              ))}
            </div>

            {selectedQuickDoubt && (
              <div className="mt-2.5 p-3 rounded-lg bg-slate-950 border border-amber-500/30 text-xs text-amber-200/90 leading-relaxed animate-fadeIn">
                <strong className="text-amber-400 block mb-1">
                  Sir ka Jawab:
                </strong>
                {quickDoubts[selectedQuickDoubt]}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default GuruMentorBox;
