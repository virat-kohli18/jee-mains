'use client';

import React, { useState } from 'react';
import { BOARD_DERIVATIONS_DIRECTORY } from '@/data/boardData';
import { BoardDerivationItem, SubjectType } from '@/types';
import MathRenderer from '@/components/MathRenderer';
import { 
  Zap, 
  Search, 
  Award, 
  CheckCircle2, 
  GraduationCap, 
  AlertCircle, 
  FileText, 
  Maximize2, 
  CheckSquare2,
  BookOpen
} from 'lucide-react';

export const BoardDerivationsView: React.FC = () => {
  const [selectedSubject, setSelectedSubject] = useState<SubjectType | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDerivation, setSelectedDerivation] = useState<BoardDerivationItem>(BOARD_DERIVATIONS_DIRECTORY[0]);

  const filteredDerivations = BOARD_DERIVATIONS_DIRECTORY.filter((item) => {
    const matchesSubject = selectedSubject === 'all' || item.subject === selectedSubject;
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.chapterName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.statement.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSubject && matchesSearch;
  });

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold uppercase tracking-wider mb-2">
            <Zap className="w-3.5 h-3.5" />
            Class 12th Board Derivations & Mechanisms Directory
          </div>
          <h1 className="text-2xl md:text-3xl font-black text-white">
            Guaranteed 5-Mark & 3-Mark Derivations
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            Complete step-by-step mathematical proofs, organic mechanisms, and diagram guidelines.
          </p>
        </div>

        {/* Counter */}
        <div className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-2xl text-xs font-bold text-slate-300 flex items-center gap-2 shrink-0">
          <Award className="w-4 h-4 text-emerald-400" />
          <span>{filteredDerivations.length} Must-Do Derivations</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between bg-slate-900/80 p-3 rounded-2xl border border-slate-800">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          {(['all', 'physics', 'chemistry', 'mathematics'] as const).map((sub) => {
            const isActive = selectedSubject === sub;
            return (
              <button
                key={sub}
                onClick={() => setSelectedSubject(sub)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {sub === 'all' ? 'All Subjects' : sub}
              </button>
            );
          })}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search derivation or proof..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
        </div>
      </div>

      {/* Main Grid: Sidebar List & Detail View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Derivations List */}
        <div className="lg:col-span-5 space-y-3 max-h-[800px] overflow-y-auto pr-1">
          {filteredDerivations.map((item) => {
            const isSelected = selectedDerivation?.id === item.id;
            return (
              <div
                key={item.id}
                onClick={() => setSelectedDerivation(item)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-emerald-950/40 border-emerald-500/80 shadow-lg shadow-emerald-950/50'
                    : 'bg-slate-900/70 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                          item.subject === 'physics'
                            ? 'bg-sky-500/10 text-sky-400 border border-sky-500/30'
                            : item.subject === 'chemistry'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                        }`}
                      >
                        {item.subject}
                      </span>
                      <span className="text-[11px] text-slate-500">
                        {item.chapterName}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-white leading-snug">
                      {item.title}
                    </h3>
                  </div>

                  <span className="px-2.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-black shrink-0 font-mono">
                    {item.expectedMarks}M
                  </span>
                </div>

                <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-500">
                  <span className="truncate max-w-[220px] text-[11px]">
                    {item.recurrenceFrequency}
                  </span>
                  <span className="text-emerald-400 font-semibold text-[11px]">
                    View Proof &rarr;
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Derivation Full Step-by-Step Proof Pane */}
        <div className="lg:col-span-7">
          {selectedDerivation ? (
            <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 space-y-6 sticky top-20 shadow-2xl">
              {/* Header */}
              <div className="pb-4 border-b border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-xs font-extrabold uppercase px-2.5 py-0.5 rounded-full ${
                        selectedDerivation.subject === 'physics'
                          ? 'bg-sky-500/10 text-sky-400 border border-sky-500/30'
                          : selectedDerivation.subject === 'chemistry'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                          : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                      }`}
                    >
                      {selectedDerivation.subject}
                    </span>
                    <span className="text-xs text-slate-400 font-medium">
                      {selectedDerivation.chapterName}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-xs font-black">
                      Expected {selectedDerivation.expectedMarks} Marks
                    </span>
                  </div>
                </div>

                <h2 className="text-xl md:text-2xl font-black text-white">
                  {selectedDerivation.title}
                </h2>

                <div className="text-xs text-amber-400 font-medium flex items-center gap-1.5">
                  <Award className="w-3.5 h-3.5" />
                  <span>Frequency: {selectedDerivation.recurrenceFrequency}</span>
                </div>
              </div>

              {/* Problem Statement */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5">
                <span className="text-xs font-extrabold text-slate-400 uppercase tracking-wider block">
                  Official Exam Question Statement:
                </span>
                <p className="text-xs md:text-sm text-slate-100 font-medium leading-relaxed">
                  {selectedDerivation.statement}
                </p>
              </div>

              {/* Diagram Checklist (if present) */}
              {selectedDerivation.diagramDescription && (
                <div className="p-4 rounded-2xl bg-sky-950/20 border border-sky-500/30 space-y-1.5">
                  <span className="text-xs font-extrabold text-sky-400 uppercase tracking-wider flex items-center gap-1.5">
                    <CheckSquare2 className="w-4 h-4" />
                    Compulsory Diagram Specifications (1 to 1.5 Marks):
                  </span>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {selectedDerivation.diagramDescription}
                  </p>
                </div>
              )}

              {/* Step-by-Step Proof */}
              <div className="space-y-3">
                <span className="text-xs font-extrabold text-white uppercase tracking-wider block">
                  Step-by-Step Derivation & Proof:
                </span>
                <div className="space-y-2.5">
                  {selectedDerivation.stepByStepProof.map((step, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 rounded-xl bg-slate-950/90 border border-slate-800/90 flex items-start gap-3"
                    >
                      <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                        {idx + 1}
                      </div>
                      <div className="text-xs md:text-sm text-slate-200 leading-relaxed font-sans">
                        <MathRenderer content={step} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Final Boxed Formula */}
              {selectedDerivation.finalFormula && (
                <div className="p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/40 text-center space-y-2">
                  <span className="text-xs font-extrabold text-emerald-400 uppercase tracking-wider block">
                    Final Result / Boxed Formula:
                  </span>
                  <div className="text-base md:text-lg font-bold text-white py-1">
                    <MathRenderer content={`$$${selectedDerivation.finalFormula}$$`} />
                  </div>
                </div>
              )}

              {/* Presentation & Marking Tips */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5 text-xs text-slate-300">
                <strong className="text-slate-200 block font-bold uppercase tracking-wider">
                  CBSE Evaluator Marking Scheme Breakdown:
                </strong>
                <p className="leading-relaxed text-slate-400">
                  {selectedDerivation.boardPresentationTips}
                </p>
              </div>

              {/* Guru Mantra Hinglish */}
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3 text-xs md:text-sm text-amber-200">
                <GraduationCap className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-amber-300 block mb-0.5 font-bold uppercase tracking-wider text-xs">
                    Guru Ji Kota Mentorship Secret:
                  </strong>
                  <p className="leading-relaxed">
                    &quot;{selectedDerivation.guruMantraHinglish}&quot;
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-64 flex items-center justify-center bg-slate-900/40 rounded-3xl border border-slate-800 text-slate-500 text-sm">
              Select a derivation to review full step-by-step proof.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BoardDerivationsView;
