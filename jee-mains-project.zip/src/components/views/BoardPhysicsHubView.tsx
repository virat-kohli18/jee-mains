'use client';

import React, { useState } from 'react';
import { 
  BOARD_PHYSICS_FORMULAS, 
  BOARD_DERIVATIONS_DIRECTORY, 
  CLASS_12_BOARD_QUESTIONS 
} from '@/data/boardData';
import MathRenderer from '@/components/MathRenderer';
import BoardQuestionCard from '@/components/BoardQuestionCard';
import { 
  Zap, 
  BookOpen, 
  Award, 
  Layers, 
  Search, 
  CheckCircle2, 
  ChevronDown, 
  ChevronUp, 
  GraduationCap, 
  AlertCircle,
  FileText
} from 'lucide-react';

export const BoardPhysicsHubView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'formulas' | 'derivations' | 'questions'>('derivations');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Track open state for questions
  const [revealedAnswers, setRevealedAnswers] = useState<Record<string, boolean>>({});
  const [revealedMarkings, setRevealedMarkings] = useState<Record<string, boolean>>({});

  const physicsDerivations = BOARD_DERIVATIONS_DIRECTORY.filter((d) => d.subject === 'physics');
  const physicsQuestions = CLASS_12_BOARD_QUESTIONS.filter((q) => q.subject === 'physics');

  const toggleAnswer = (id: string) => {
    setRevealedAnswers((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleMarking = (id: string) => {
    setRevealedMarkings((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Header Banner */}
      <div className="p-6 md:p-8 rounded-3xl bg-gradient-to-br from-sky-950/80 via-slate-900 to-slate-950 border border-sky-500/30 shadow-2xl space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/20 border border-sky-500/40 text-sky-300 text-xs font-bold uppercase tracking-wider">
          <Zap className="w-4 h-4 text-sky-400" />
          Class 12th Physics &bull; 70 Theory + 30 Practicals
        </div>
        <h1 className="text-3xl md:text-4xl font-black text-white">
          Class 12 Physics Complete Subject Hub
        </h1>
        <p className="text-slate-300 text-sm md:text-base max-w-2xl leading-relaxed">
          Master every single 3M &amp; 5M derivation, formula with SI units, and 334+ authentic board PYQs 
          with step-wise marking schemes and model topper presentation.
        </p>

        {/* 3 Main Internal Navigation Tabs */}
        <div className="pt-2 flex flex-wrap gap-2">
          {[
            { id: 'derivations', label: `Must-Do Derivations (${physicsDerivations.length})`, icon: <Zap className="w-4 h-4" /> },
            { id: 'formulas', label: `All Formulas (${BOARD_PHYSICS_FORMULAS.length})`, icon: <BookOpen className="w-4 h-4" /> },
            { id: 'questions', label: `334+ Board Questions`, icon: <Layers className="w-4 h-4" /> },
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 rounded-2xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer ${
                  isActive
                    ? 'bg-sky-500 text-slate-950 shadow-lg shadow-sky-500/30'
                    : 'bg-slate-900 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ================= DERIVATIONS SECTION ================= */}
      {activeTab === 'derivations' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-sky-400" />
              <span>Must-Do 3M &amp; 5M Derivations Directory</span>
            </h2>
            <span className="text-xs text-sky-400 font-bold bg-sky-500/10 px-3 py-1 rounded-full border border-sky-500/20">
              Guaranteed 25+ Marks in Board Exam
            </span>
          </div>

          <div className="space-y-6">
            {physicsDerivations.map((item, idx) => (
              <div
                key={item.id}
                className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-5 shadow-xl hover:border-sky-500/40 transition-all"
              >
                {/* Header */}
                <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-lg bg-sky-500/20 text-sky-300 flex items-center justify-center text-xs font-bold font-mono">
                        #{idx + 1}
                      </span>
                      <span className="text-xs font-bold text-sky-400">
                        {item.chapterName}
                      </span>
                    </div>
                    <h3 className="text-lg md:text-xl font-black text-white">
                      {item.title}
                    </h3>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold">
                      {item.recurrenceFrequency}
                    </span>
                    <span className="px-3 py-1 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-black">
                      {item.expectedMarks} Marks
                    </span>
                  </div>
                </div>

                {/* Problem Statement */}
                <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-xs md:text-sm text-slate-200 leading-relaxed font-medium">
                  {item.statement}
                </div>

                {/* Diagram Requirement */}
                {item.diagramDescription && (
                  <div className="p-3.5 rounded-2xl bg-sky-950/20 border border-sky-500/30 text-xs text-slate-300 space-y-1">
                    <strong className="text-sky-400 block font-bold uppercase tracking-wider">
                      Compulsory Ray / Circuit Diagram (1.5 Marks):
                    </strong>
                    <p>{item.diagramDescription}</p>
                  </div>
                )}

                {/* Step-by-Step Proof */}
                <div className="space-y-2.5">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                    Step-by-Step Proof:
                  </span>
                  {item.stepByStepProof.map((step, sIdx) => (
                    <div
                      key={sIdx}
                      className="p-3 rounded-xl bg-slate-950/90 border border-slate-800/80 flex items-start gap-3 text-xs md:text-sm text-slate-200"
                    >
                      <span className="w-5 h-5 rounded-full bg-sky-500/20 text-sky-300 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                        {sIdx + 1}
                      </span>
                      <div className="flex-1">
                        <MathRenderer content={step} />
                      </div>
                    </div>
                  ))}
                </div>

                {/* Final Boxed Formula */}
                {item.finalFormula && (
                  <div className="p-4 rounded-2xl bg-sky-950/30 border border-sky-500/40 text-center space-y-1">
                    <span className="text-xs font-bold text-sky-400 uppercase tracking-wider block">
                      Boxed Final Formula:
                    </span>
                    <div className="text-base md:text-lg font-bold text-white py-1">
                      <MathRenderer content={`$$${item.finalFormula}$$`} />
                    </div>
                  </div>
                )}

                {/* Examiner Tips & Guru Ji */}
                <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3 text-xs text-amber-200">
                  <GraduationCap className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-amber-300 font-bold block mb-0.5">Guru Ji Board Secret:</strong>
                    &quot;{item.guruMantraHinglish}&quot;
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= FORMULAS SECTION ================= */}
      {activeTab === 'formulas' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-sky-400" />
              <span>Complete Class 12 Physics Formula Book</span>
            </h2>
            <span className="text-xs text-sky-400 font-bold bg-sky-500/10 px-3 py-1 rounded-full border border-sky-500/20">
              With SI Units &amp; Conditions
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {BOARD_PHYSICS_FORMULAS.map((f) => (
              <div
                key={f.id}
                className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-4 shadow-xl hover:border-slate-700 transition-all flex flex-col justify-between"
              >
                <div className="space-y-2">
                  <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-sky-500/10 text-sky-400 border border-sky-500/30">
                    {f.chapterName}
                  </span>
                  <h3 className="text-base font-bold text-white">
                    {f.title}
                  </h3>

                  {/* Formula Box */}
                  <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-center my-3 text-sky-300">
                    <MathRenderer content={`$$${f.formulaLatex}$$`} />
                  </div>

                  {/* Symbols & Meanings */}
                  <div className="space-y-1 text-xs">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                      Symbols &amp; Meanings:
                    </span>
                    {f.symbolMeanings.map((sym, sIdx) => (
                      <div key={sIdx} className="flex justify-between py-0.5 text-slate-300 border-b border-slate-950">
                        <strong className="text-sky-400 font-mono">{sym.symbol}</strong>
                        <span>{sym.meaning}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800 space-y-1.5 text-xs text-slate-400">
                  <div className="flex justify-between">
                    <span>SI Unit:</span>
                    <strong className="text-emerald-400 font-mono">{f.siUnit}</strong>
                  </div>
                  <div className="text-[11px] text-slate-400 italic">
                    Condition: {f.conditions}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= QUESTIONS SECTION ================= */}
      {activeTab === 'questions' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Layers className="w-5 h-5 text-sky-400" />
              <span>Physics Board Questions Bank ({physicsQuestions.length} Questions)</span>
            </h2>
            <span className="text-xs text-emerald-400 font-bold bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
              1M, 2M, 3M, 4M, 5M Formats
            </span>
          </div>

          <div className="space-y-4">
            {physicsQuestions.slice(0, 30).map((q, idx) => (
              <BoardQuestionCard key={q.id} question={q} questionNumber={idx + 1} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default BoardPhysicsHubView;
