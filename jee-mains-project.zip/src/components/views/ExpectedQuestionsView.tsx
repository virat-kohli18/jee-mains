'use client';

import React, { useState } from 'react';
import { EXPECTED_QUESTION_PATTERNS } from '@/data/weightageAndAnalysisData';
import { SubjectType } from '@/types';
import MathRenderer from '../MathRenderer';
import { Sparkles, TrendingUp, HelpCircle, CheckCircle, Lightbulb } from 'lucide-react';

export const ExpectedQuestionsView: React.FC = () => {
  const [selectedSubject, setSelectedSubject] = useState<SubjectType | 'all'>('all');
  const [revealedIds, setRevealedIds] = useState<Record<string, boolean>>({});

  const filteredPatterns =
    selectedSubject === 'all'
      ? EXPECTED_QUESTION_PATTERNS
      : EXPECTED_QUESTION_PATTERNS.filter((p) => p.subject === selectedSubject);

  const toggleReveal = (id: string) => {
    setRevealedIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-1">
          <Sparkles className="w-4 h-4" /> Pattern-Based Analysis (No Gimmick Guarantees)
        </div>
        <h1 className="text-2xl font-bold text-white">Most Expected Question Patterns</h1>
        <p className="text-xs md:text-sm text-slate-400 mt-1">
          Rooted strictly in empirical shift recurrence from 2015-2024. Every expected question pattern provides the{' '}
          <strong>underlying conceptual reason</strong>, <strong>historical hit rate</strong>, and{' '}
          <strong>instant solving insights</strong>.
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
        {(['all', 'physics', 'chemistry', 'mathematics'] as (SubjectType | 'all')[]).map((subj) => {
          const isActive = selectedSubject === subj;
          const label =
            subj === 'all'
              ? 'All Expected Patterns'
              : subj === 'physics'
              ? 'Physics Patterns'
              : subj === 'chemistry'
              ? 'Chemistry Patterns'
              : 'Mathematics Patterns';

          return (
            <button
              key={subj}
              onClick={() => setSelectedSubject(subj)}
              className={`px-4 py-2 rounded-xl text-xs md:text-sm font-semibold transition-all cursor-pointer ${
                isActive
                  ? 'bg-amber-500 text-slate-950 shadow-md font-bold'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
              }`}
            >
              {label}
            </button>
          );
        })}
      </div>

      {/* Patterns Cards */}
      <div className="space-y-5">
        {filteredPatterns.map((pat) => {
          const isRevealed = !!revealedIds[pat.id];
          return (
            <div
              key={pat.id}
              className="bg-slate-900/90 border border-slate-800 rounded-xl p-6 shadow-lg space-y-4 hover:border-slate-700 transition-all"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs px-2.5 py-1 rounded-md bg-amber-500/10 border border-amber-500/30 text-amber-400 font-bold uppercase">
                    {pat.subject}
                  </span>
                  <span className="text-xs text-slate-400 font-medium">{pat.chapterName}</span>
                </div>
                <span className="text-xs px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 font-semibold flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5" /> {pat.historicalHitRate}
                </span>
              </div>

              <div>
                <h3 className="text-base font-bold text-white mb-2">{pat.patternTitle}</h3>
                <div className="text-xs text-slate-300 bg-slate-950 p-3 rounded-lg border border-slate-800 flex items-start gap-2">
                  <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-amber-400 block mb-0.5">Why This Pattern Recurrs:</strong>
                    <span>{pat.whyExpected}</span>
                  </div>
                </div>
              </div>

              {/* Sample Question */}
              <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 space-y-3">
                <span className="text-[11px] uppercase font-bold text-slate-400 block tracking-wider">
                  Archetype Question:
                </span>
                <p className="text-sm text-slate-100 font-medium">
                  <MathRenderer content={pat.sampleQuestion} />
                </p>

                {pat.options && (() => {
                  const options = pat.options;
                  return (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                      {(['A', 'B', 'C', 'D'] as const).map((opt) => (
                        <div
                          key={opt}
                          className={`text-xs p-2.5 rounded-lg border flex items-center gap-2 ${
                            isRevealed && opt === pat.answer
                              ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-semibold'
                              : 'bg-slate-900 border-slate-800 text-slate-300'
                          }`}
                        >
                          <span className="font-bold text-slate-400">({opt})</span>
                          <span>{options[opt]}</span>
                        </div>
                      ))}
                    </div>
                  );
                })()}
              </div>

              {/* Solving Insight / Answer Toggle */}
              <div>
                <button
                  onClick={() => toggleReveal(pat.id)}
                  className="px-4 py-2 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer"
                >
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>{isRevealed ? 'Hide Solving Insight' : 'Reveal Answer & 60-Second Solving Shortcut'}</span>
                </button>

                {isRevealed && (
                  <div className="mt-3 p-4 rounded-xl bg-slate-950 border border-indigo-500/30 text-xs text-slate-300 space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-emerald-400">Correct Answer:</span>
                      <span className="font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold">
                        Option {pat.answer}
                      </span>
                    </div>
                    <p className="text-slate-300 leading-relaxed">
                      <strong className="text-indigo-400">Solving Shortcut: </strong>
                      {pat.solvingInsight}
                    </p>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ExpectedQuestionsView;
