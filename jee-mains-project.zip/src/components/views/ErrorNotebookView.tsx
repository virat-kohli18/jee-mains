'use client';

import React, { useState } from 'react';
import { StudentProfile, markErrorRetried } from '@/utils/studentStore';
import { ErrorTag, ErrorLogItem } from '@/types';
import MathRenderer from '../MathRenderer';
import { 
  AlertTriangle, 
  RotateCcw, 
  CheckCircle, 
  XCircle, 
  Filter, 
  Tag, 
  Sparkles,
  BookOpen,
  GraduationCap
} from 'lucide-react';
import GuruMentorBox from '../GuruMentorBox';

interface ErrorNotebookViewProps {
  profile: StudentProfile;
  onProfileUpdated: () => void;
}

export const ErrorNotebookView: React.FC<ErrorNotebookViewProps> = ({
  profile,
  onProfileUpdated,
}) => {
  const [selectedTag, setSelectedTag] = useState<ErrorTag | 'all'>('all');
  const [retryInput, setRetryInput] = useState<Record<string, string>>({});
  const [retryStatus, setRetryStatus] = useState<Record<string, 'correct' | 'wrong' | null>>({});

  const filteredErrors = profile.errorNotebook.filter((err) => {
    if (selectedTag === 'all') return true;
    return err.category === selectedTag;
  });

  const handleRetrySubmit = (errorItem: ErrorLogItem) => {
    const userVal = (retryInput[errorItem.id] || '').trim().toUpperCase();
    const isCorrect = userVal === errorItem.correctAnswer.toUpperCase();

    setRetryStatus((prev) => ({
      ...prev,
      [errorItem.id]: isCorrect ? 'correct' : 'wrong',
    }));

    markErrorRetried(errorItem.id, isCorrect);
    onProfileUpdated();
  };

  const getTagColor = (tag: ErrorTag) => {
    switch (tag) {
      case 'conceptual':
        return 'bg-purple-500/10 border-purple-500/30 text-purple-400';
      case 'calculation':
        return 'bg-rose-500/10 border-rose-500/30 text-rose-400';
      case 'formula':
        return 'bg-amber-500/10 border-amber-500/30 text-amber-400';
      case 'misreading':
        return 'bg-sky-500/10 border-sky-500/30 text-sky-400';
      case 'time_management':
        return 'bg-orange-500/10 border-orange-500/30 text-orange-400';
      default:
        return 'bg-slate-800 text-slate-300';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-rose-400 text-xs font-bold uppercase tracking-wider mb-1">
            <AlertTriangle className="w-4 h-4" /> Mistake Diagnostic Engine
          </div>
          <h1 className="text-2xl font-bold text-white">Automated Error Notebook</h1>
          <p className="text-xs md:text-sm text-slate-400 mt-1">
            Every question answered incorrectly in mock tests or practice is auto-saved here. 
            Classified by error root-cause with <strong>interactive retry mode</strong> to eliminate -1 point leaks.
          </p>
        </div>

        <div className="px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-center">
          <span className="text-[10px] text-slate-500 uppercase font-bold block">Total Errors</span>
          <strong className="text-rose-400 text-base">{profile.errorNotebook.length} Saved</strong>
        </div>
      </div>

      {/* Filter by Error Classification */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
        {(['all', 'conceptual', 'calculation', 'formula', 'misreading', 'time_management'] as (ErrorTag | 'all')[]).map((tag) => {
          const isActive = selectedTag === tag;
          const label = tag === 'all' ? 'All Mistakes' : tag.replace('_', ' ');
          const count = tag === 'all' ? profile.errorNotebook.length : profile.errorNotebook.filter((e) => e.category === tag).length;

          return (
            <button
              key={tag}
              onClick={() => setSelectedTag(tag)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold capitalize transition-all cursor-pointer flex items-center gap-1.5 ${
                isActive
                  ? 'bg-rose-600 text-white shadow'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
              }`}
            >
              <span>{label}</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${isActive ? 'bg-white/20' : 'bg-slate-800 text-slate-400'}`}>
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Error Items List */}
      {filteredErrors.length > 0 ? (
        <div className="space-y-4">
          {filteredErrors.map((item) => {
            const q = item.question;
            const currentStatus = retryStatus[item.id];
            return (
              <div
                key={item.id}
                className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4 hover:border-slate-700 transition-all"
              >
                {/* Meta */}
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-bold">
                      {q.id}
                    </span>
                    <span className={`text-xs px-2.5 py-0.5 rounded border uppercase font-bold ${getTagColor(item.category)}`}>
                      {item.category.replace('_', ' ')} Error
                    </span>
                    <span className="text-xs text-slate-400">{q.chapterName} &bull; {q.topicName}</span>
                  </div>

                  {item.retried && (
                    <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5" /> Retried & Resolved
                    </span>
                  )}
                </div>

                {/* Question Text */}
                <div className="text-sm md:text-base text-slate-200">
                  <MathRenderer content={q.questionText} />
                </div>

                {/* Your Mistake Comparison */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <div>
                    <span className="text-slate-400 block mb-0.5">Your Recorded Answer:</span>
                    <strong className="text-rose-400 font-mono text-sm">{item.wrongUserAnswer || 'None / Blank'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block mb-0.5">Verified Correct Answer:</span>
                    <strong className="text-emerald-400 font-mono text-sm">{item.correctAnswer}</strong>
                  </div>
                </div>

                {/* Interactive Retry Field */}
                <div className="pt-2 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2 max-w-sm flex-1">
                    <input
                      type="text"
                      placeholder="Enter answer to re-attempt..."
                      value={retryInput[item.id] || ''}
                      onChange={(e) => setRetryInput({ ...retryInput, [item.id]: e.target.value })}
                      className="bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500 font-mono flex-1"
                    />
                    <button
                      onClick={() => handleRetrySubmit(item)}
                      className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg text-xs transition-all cursor-pointer"
                    >
                      Verify Retry
                    </button>
                  </div>

                  {currentStatus === 'correct' && (
                    <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                      <CheckCircle className="w-4 h-4" /> Correctly Solved!
                    </span>
                  )}
                  {currentStatus === 'wrong' && (
                    <span className="text-xs font-bold text-rose-400 flex items-center gap-1">
                      <XCircle className="w-4 h-4" /> Still incorrect. Review the solution below!
                    </span>
                  )}
                </div>

                {/* Guru Ji Hinglish Teacher Mentorship */}
                <GuruMentorBox
                  question={q}
                  isCorrect={false}
                  userAnswer={item.wrongUserAnswer}
                  errorTag={item.category}
                />
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-12 text-center space-y-3">
          <CheckCircle className="w-10 h-10 text-emerald-400 mx-auto" />
          <h3 className="text-base font-bold text-white">Your Error Notebook is Clean!</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Any questions answered incorrectly during practice or mock tests will automatically appear here for categorization and retry.
          </p>
        </div>
      )}
    </div>
  );
};

export default ErrorNotebookView;
