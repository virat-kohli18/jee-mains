'use client';

import React, { useState } from 'react';
import { StudentProfile, saveStudentProfile } from '@/utils/studentStore';
import { 
  Calendar, 
  Target, 
  Flame, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  Award,
  ArrowRight,
  TrendingUp,
  Bookmark
} from 'lucide-react';
import { NavTab } from '../Sidebar';

interface PlannerViewProps {
  profile: StudentProfile;
  onProfileUpdated: () => void;
  onNavigate: (tab: NavTab) => void;
  onLaunchMockTest: () => void;
}

export const PlannerView: React.FC<PlannerViewProps> = ({
  profile,
  onProfileUpdated,
  onNavigate,
  onLaunchMockTest,
}) => {
  const [dailyGoal, setDailyGoal] = useState<number>(profile.dailyGoal || 25);
  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);

  const solvedToday = Object.values(profile.solvedQuestionIds).length % 30; // representative daily progress

  const handleSaveGoal = () => {
    profile.dailyGoal = dailyGoal;
    saveStudentProfile(profile);
    setSavedSuccess(true);
    onProfileUpdated();
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  // Diagnostic Weak Chapter Recommendations based on error count
  const errorChapters = profile.errorNotebook.map((e) => e.question.chapterName);
  const errorFreq: Record<string, number> = {};
  errorChapters.forEach((ch) => {
    errorFreq[ch] = (errorFreq[ch] || 0) + 1;
  });

  const recommendedWeakChapters = Object.entries(errorFreq)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([ch, count]) => ({ name: ch, errorCount: count }));

  // Default fallback recommendations if error notebook is empty
  const defaultRecommendations = [
    { name: 'Rotational Motion & System of Particles', priority: 'High', reason: 'High weightage & frequent calculation traps' },
    { name: 'Coordination Compounds', priority: 'High', reason: 'Highest ROI in Inorganic Chemistry' },
    { name: 'Vector Algebra & 3D Geometry (Lines)', priority: 'High', reason: 'Guaranteed 3-4 questions per shift' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-1">
          <Calendar className="w-4 h-4" /> Personalized Study Architecture
        </div>
        <h1 className="text-2xl font-bold text-white">Smart Daily Study Planner</h1>
        <p className="text-xs md:text-sm text-slate-400 mt-1">
          Structured for disciplined execution. Set daily PYQ targets, track streak continuity, 
          schedule weekly mock tests, and receive automated <strong>weak-chapter remedial recommendations</strong>.
        </p>
      </div>

      {/* Target Setting & Daily Progress */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Daily Goal Configuration */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Target className="w-4 h-4 text-indigo-400" /> Daily PYQ Target Configuration
          </h3>
          <p className="text-xs text-slate-300">
            Recommended pace: <strong>25 to 35 authentic PYQs per day</strong> balances solving speed with comprehensive 10-point solution analysis.
          </p>

          <div className="flex items-center gap-3">
            <input
              type="number"
              min={10}
              max={100}
              value={dailyGoal}
              onChange={(e) => setDailyGoal(Number(e.target.value))}
              className="bg-slate-950 border border-slate-700 rounded-lg px-4 py-2 text-white font-mono text-base w-32 focus:outline-none focus:border-indigo-500"
            />
            <button
              onClick={handleSaveGoal}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg text-xs transition-all cursor-pointer"
            >
              Update Goal
            </button>
            {savedSuccess && <span className="text-xs font-bold text-emerald-400">Updated!</span>}
          </div>

          <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span>Today's Progress: <strong className="text-emerald-400">{solvedToday} / {dailyGoal}</strong></span>
            <span>Streak: <strong className="text-amber-400">{profile.streakDays} Days</strong></span>
          </div>
        </div>

        {/* Weekly Mock Test Cadence */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-400" /> Weekly NTA Mock Test Routine
          </h3>
          <p className="text-xs text-slate-300">
            Simulate a full 3-hour computer-based test every Sunday from <strong>9:00 AM to 12:00 PM</strong> to synchronize your biological peak alertness.
          </p>

          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
            <div className="text-xs">
              <strong className="text-slate-100 block">Next Scheduled Mock Test:</strong>
              <span className="text-slate-400">Full Syllabus Paper 1 (300 Marks)</span>
            </div>
            <button
              onClick={onLaunchMockTest}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg text-xs transition-all cursor-pointer"
            >
              Start Mock Now
            </button>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-400">
            <Award className="w-3.5 h-3.5 text-amber-400" />
            <span>Completed Mock Tests: <strong className="text-slate-200">{profile.mockTestResults.length}</strong></span>
          </div>
        </div>
      </div>

      {/* Weak-Topic Diagnostic Remedial Engine */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400" /> Personalized Weak-Chapter Remedial Plan
          </h3>
          <span className="text-xs px-2.5 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/30 font-semibold">
            Based on Error Notebook
          </span>
        </div>

        <p className="text-xs text-slate-300">
          Our diagnostic analyzer monitors questions you miss or hesitate on. Prioritize these chapters during today's revision session:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {recommendedWeakChapters.length > 0
            ? recommendedWeakChapters.map((ch, idx) => (
                <div
                  key={idx}
                  className="bg-slate-950 p-4 rounded-xl border border-rose-500/30 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-rose-400">Priority #{idx + 1}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 font-bold">
                      {ch.errorCount} Errors
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-white">{ch.name}</h4>
                  <div className="pt-2">
                    <button
                      onClick={() => onNavigate('revision')}
                      className="text-xs text-indigo-400 hover:underline flex items-center gap-1 font-semibold cursor-pointer"
                    >
                      <span>15-Min Revision</span> <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))
            : defaultRecommendations.map((ch, idx) => (
                <div
                  key={idx}
                  className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-amber-400">{ch.priority} Priority</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 font-bold">
                      High Yield
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-white">{ch.name}</h4>
                  <p className="text-[11px] text-slate-400">{ch.reason}</p>
                  <div className="pt-2">
                    <button
                      onClick={() => onNavigate('revision')}
                      className="text-xs text-indigo-400 hover:underline flex items-center gap-1 font-semibold cursor-pointer"
                    >
                      <span>Review Chapter Notes</span> <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))}
        </div>
      </div>
    </div>
  );
};

export default PlannerView;
