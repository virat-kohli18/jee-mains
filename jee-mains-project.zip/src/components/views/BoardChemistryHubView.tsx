'use client';

import React, { useState } from 'react';
import { 
  BOARD_NAMED_REACTIONS, 
  BOARD_REAGENTS_GUIDE, 
  CLASS_12_BOARD_QUESTIONS 
} from '@/data/boardData';
import MathRenderer from '@/components/MathRenderer';
import BoardQuestionCard from '@/components/BoardQuestionCard';
import { 
  FlaskConical, 
  Award, 
  Layers, 
  Search, 
  CheckCircle2, 
  ChevronDown, 
  ChevronUp, 
  GraduationCap, 
  AlertCircle,
  Sparkles,
  Zap,
  Bookmark
} from 'lucide-react';

export const BoardChemistryHubView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'reactions' | 'reagents' | 'questions'>('reactions');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedImportance, setSelectedImportance] = useState<string>('all');
  
  // Track open state for questions
  const [revealedAnswers, setRevealedAnswers] = useState<Record<string, boolean>>({});
  const [revealedMarkings, setRevealedMarkings] = useState<Record<string, boolean>>({});

  const chemistryQuestions = CLASS_12_BOARD_QUESTIONS.filter((q) => q.subject === 'chemistry');

  const toggleAnswer = (id: string) => {
    setRevealedAnswers((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleMarking = (id: string) => {
    setRevealedMarkings((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const filteredReactions = BOARD_NAMED_REACTIONS.filter((r) => {
    const matchesSearch = r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.chapterName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.reagents.some(rg => rg.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesImportance = selectedImportance === 'all' || r.importance === selectedImportance;
    return matchesSearch && matchesImportance;
  });

  const filteredReagents = BOARD_REAGENTS_GUIDE.filter((rg) => {
    return rg.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rg.primaryFunction.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rg.category.toLowerCase().includes(searchQuery.toLowerCase());
  });

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Header Banner */}
      <div className="p-6 md:p-8 rounded-3xl bg-gradient-to-br from-emerald-950/80 via-slate-900 to-slate-950 border border-emerald-500/30 shadow-2xl space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold uppercase tracking-wider">
          <FlaskConical className="w-4 h-4 text-emerald-400" />
          Class 12th Chemistry &bull; 70 Theory + 30 Practicals
        </div>
        <h1 className="text-3xl md:text-4xl font-black text-white">
          Class 12 Chemistry Complete Subject Hub
        </h1>
        <p className="text-slate-300 text-sm md:text-base max-w-2xl leading-relaxed">
          Dedicated section for Organic Named Reactions with mechanisms, Reagent Master Guide, 
          conversions, and 334+ authentic board questions with step-marking schemes.
        </p>

        {/* 3 Main Internal Navigation Tabs */}
        <div className="pt-2 flex flex-wrap gap-2">
          {[
            { id: 'reactions', label: `Named Reactions (${BOARD_NAMED_REACTIONS.length})`, icon: <Sparkles className="w-4 h-4" /> },
            { id: 'reagents', label: `Reagent Master Guide (${BOARD_REAGENTS_GUIDE.length})`, icon: <FlaskConical className="w-4 h-4" /> },
            { id: 'questions', label: `334+ Board Questions`, icon: <Layers className="w-4 h-4" /> },
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 rounded-2xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer ${
                  isActive
                    ? 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/30'
                    : 'bg-slate-900 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ================= NAMED REACTIONS SECTION ================= */}
      {activeTab === 'reactions' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/80 p-3 rounded-2xl border border-slate-800">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mr-1">Importance:</span>
              {['all', 'Guaranteed', 'High Importance'].map((imp) => (
                <button
                  key={imp}
                  onClick={() => setSelectedImportance(imp)}
                  className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    selectedImportance === imp
                      ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                      : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  {imp === 'all' ? 'All Reactions' : imp}
                </button>
              ))}
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search reaction, reagent, product..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div className="space-y-6">
            {filteredReactions.map((r, idx) => (
              <div
                key={r.id}
                className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-5 shadow-xl hover:border-emerald-500/40 transition-all"
              >
                {/* Header */}
                <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-300 flex items-center justify-center text-xs font-bold font-mono">
                        #{idx + 1}
                      </span>
                      <span className="text-xs font-bold text-emerald-400">
                        {r.chapterName}
                      </span>
                    </div>
                    <h3 className="text-xl font-black text-white">
                      {r.name}
                    </h3>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold">
                      {r.boardExamYears}
                    </span>
                    <span
                      className={`px-3 py-1 rounded-xl text-xs font-black border ${
                        r.importance === 'Guaranteed'
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                          : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                      }`}
                    >
                      {r.importance}
                    </span>
                  </div>
                </div>

                {/* Substrate & Reagent Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-1">
                    <strong className="text-slate-400 uppercase tracking-wider block">Starting Substrate:</strong>
                    <span className="text-slate-200 font-medium">{r.substrate}</span>
                  </div>
                  <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-1">
                    <strong className="text-emerald-400 uppercase tracking-wider block">Reagents &amp; Conditions:</strong>
                    <div className="flex flex-wrap gap-1.5">
                      {r.reagents.map((rg, rIdx) => (
                        <span key={rIdx} className="px-2.5 py-0.5 rounded-md bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 font-mono font-bold">
                          {rg}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Reaction Equation Box */}
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-center my-2 text-xs md:text-sm text-emerald-300 font-mono">
                  <MathRenderer content={`$$${r.reactionEquation}$$`} />
                </div>

                {/* Step-by-Step Mechanism */}
                {r.stepByStepMechanism && r.stepByStepMechanism.length > 0 && (
                  <div className="space-y-2">
                    <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                      Step-by-Step Reaction Mechanism:
                    </span>
                    {r.stepByStepMechanism.map((step, sIdx) => (
                      <div
                        key={sIdx}
                        className="p-3 rounded-xl bg-slate-950/90 border border-slate-800/80 flex items-start gap-2.5 text-xs text-slate-200"
                      >
                        <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-300 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                          {sIdx + 1}
                        </span>
                        <span>{step}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Examiner Trap Alert */}
                <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-start gap-2 text-xs text-rose-200">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-rose-400 font-bold block mb-0.5">Examiner Trap Alert:</strong>
                    {r.examinerTrapAlert}
                  </div>
                </div>

                {/* Guru Ji Kota Educator Advice */}
                <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3 text-xs text-amber-200">
                  <GraduationCap className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-amber-300 font-bold block mb-0.5">Guru Ji Hinglish Tip:</strong>
                    &quot;{r.guruJiHinglishTip}&quot;
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= REAGENTS MASTER GUIDE SECTION ================= */}
      {activeTab === 'reagents' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <FlaskConical className="w-5 h-5 text-emerald-400" />
              <span>Organic Chemistry Reagent Master Guide</span>
            </h2>
            <span className="text-xs text-emerald-400 font-bold bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
              Conversions &bull; Tests &bull; Selectivity
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredReagents.map((rg) => (
              <div
                key={rg.id}
                className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-4 shadow-xl hover:border-slate-700 transition-all flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                      {rg.category}
                    </span>
                    <span className="text-xs font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20">
                      {rg.importance}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-base font-bold text-white">
                      {rg.name}
                    </h3>
                    <span className="text-xs text-slate-400 font-mono block mt-0.5">
                      Formula: {rg.formula}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3 rounded-xl border border-slate-800">
                    <strong className="text-emerald-400 block mb-0.5">Primary Function:</strong>
                    {rg.primaryFunction}
                  </p>

                  {/* Conversions List */}
                  <div className="space-y-1.5 text-xs">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                      Specific Conversions:
                    </span>
                    {rg.conversions.map((conv, cIdx) => (
                      <div key={cIdx} className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-900 space-y-1">
                        <div className="flex justify-between text-slate-200 font-semibold">
                          <span className="text-sky-300">{conv.from}</span>
                          <span className="text-emerald-400">&rarr; {conv.to}</span>
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono">
                          {conv.equation}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800 space-y-2">
                  <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-200">
                    <strong className="text-amber-300 block mb-0.5 font-bold">Guru Mantra:</strong>
                    &quot;{rg.guruMantraHinglish}&quot;
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= QUESTIONS SECTION ================= */}
      {activeTab === 'questions' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Layers className="w-5 h-5 text-emerald-400" />
              <span>Chemistry Board Questions Bank ({chemistryQuestions.length} Questions)</span>
            </h2>
            <span className="text-xs text-emerald-400 font-bold bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
              1M, 2M, 3M, 4M, 5M Formats
            </span>
          </div>

          <div className="space-y-4">
            {chemistryQuestions.slice(0, 30).map((q, idx) => (
              <BoardQuestionCard key={q.id} question={q} questionNumber={idx + 1} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default BoardChemistryHubView;
