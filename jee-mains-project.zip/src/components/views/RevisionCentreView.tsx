'use client';

import React, { useState } from 'react';
import { REVISION_DATA } from '@/data/revisionData';
import { SubjectType } from '@/types';
import MathRenderer from '../MathRenderer';
import { 
  Zap, 
  Clock, 
  Sparkles, 
  AlertTriangle, 
  BookOpen, 
  CheckCircle2, 
  ChevronRight,
  Flame
} from 'lucide-react';

export const RevisionCentreView: React.FC = () => {
  const [selectedSubject, setSelectedSubject] = useState<SubjectType>('physics');
  const [selectedRevisionMode, setSelectedRevisionMode] = useState<'15min' | '30min' | 'complete'>('15min');

  const filteredRevisions = REVISION_DATA.filter((r) => r.subject === selectedSubject);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-1">
          <Zap className="w-4 h-4" /> High-Efficiency Revision Engine
        </div>
        <h1 className="text-2xl font-bold text-white">Chapter-Wise Revision Centre</h1>
        <p className="text-xs md:text-sm text-slate-400 mt-1">
          Tailored for high recall before examination shifts. Toggle between{' '}
          <strong className="text-amber-400">15-minute flash summaries</strong>,{' '}
          <strong className="text-sky-400">30-minute high-yield boosters</strong>, and{' '}
          <strong className="text-emerald-400">complete chapter notes</strong> with shortcuts and trap avoidance.
        </p>
      </div>

      {/* Subject Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          {(['physics', 'chemistry', 'mathematics'] as SubjectType[]).map((subj) => {
            const isActive = selectedSubject === subj;
            const label = subj === 'physics' ? 'Physics' : subj === 'chemistry' ? 'Chemistry' : 'Mathematics';
            return (
              <button
                key={subj}
                onClick={() => setSelectedSubject(subj)}
                className={`px-4 py-2 rounded-xl text-xs md:text-sm font-semibold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow'
                    : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
                }`}
              >
                {label}
              </button>
            );
          })}
        </div>

        {/* Mode Selector */}
        <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setSelectedRevisionMode('15min')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              selectedRevisionMode === '15min' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Clock className="w-3.5 h-3.5" /> 15-Min Flash
          </button>
          <button
            onClick={() => setSelectedRevisionMode('30min')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              selectedRevisionMode === '30min' ? 'bg-sky-500 text-slate-950' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Flame className="w-3.5 h-3.5" /> 30-Min Booster
          </button>
          <button
            onClick={() => setSelectedRevisionMode('complete')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              selectedRevisionMode === 'complete' ? 'bg-emerald-500 text-slate-950' : 'text-slate-400 hover:text-white'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" /> Master Notes
          </button>
        </div>
      </div>

      {/* Revision Content */}
      <div className="space-y-6">
        {filteredRevisions.map((rev) => (
          <div
            key={rev.chapterId}
            className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-indigo-500" />
                {rev.chapterName}
              </h2>
              <span className="text-xs uppercase font-bold px-2.5 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/30">
                {selectedRevisionMode.toUpperCase()} MODE
              </span>
            </div>

            {/* 15-Minute Flash Revision Mode */}
            {selectedRevisionMode === '15min' && (
              <div className="space-y-3">
                <span className="text-xs uppercase font-bold text-amber-400 flex items-center gap-1.5 tracking-wider">
                  <Clock className="w-4 h-4" /> Core High-Yield Bullet Summaries:
                </span>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {rev.fifteenMinSummary.map((point, pIdx) => (
                    <div
                      key={pIdx}
                      className="bg-slate-950 p-3.5 rounded-xl border border-slate-800/80 text-xs md:text-sm text-slate-200 leading-relaxed flex items-start gap-2.5"
                    >
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span><MathRenderer content={point} inline /></span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 30-Minute High-Yield Booster Mode */}
            {selectedRevisionMode === '30min' && (
              <div className="space-y-4">
                <span className="text-xs uppercase font-bold text-sky-400 flex items-center gap-1.5 tracking-wider">
                  <Flame className="w-4 h-4" /> 30-Minute High-Yield Focus Modules:
                </span>
                <div className="space-y-4">
                  {rev.thirtyMinHighYield.map((mod, mIdx) => (
                    <div
                      key={mIdx}
                      className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3"
                    >
                      <h4 className="text-sm font-bold text-white flex items-center gap-2">
                        <span className="text-sky-400 font-mono">0{mIdx + 1}.</span> {mod.coreConcept}
                      </h4>

                      <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-1">
                        <span className="text-[10px] uppercase font-bold text-slate-400 block">Critical Formulas:</span>
                        {mod.keyFormulas.map((f, fIdx) => (
                          <div key={fIdx} className="text-xs md:text-sm text-indigo-300">
                            <MathRenderer content={f} />
                          </div>
                        ))}
                      </div>

                      <div className="bg-rose-950/30 p-3 rounded-lg border border-rose-500/30 space-y-1">
                        <span className="text-[10px] uppercase font-bold text-rose-400 flex items-center gap-1">
                          <AlertTriangle className="w-3.5 h-3.5" /> Critical Negative-Marking Traps:
                        </span>
                        <ul className="list-disc list-inside space-y-1 text-xs text-rose-200">
                          {mod.criticalPitfalls.map((pit, pIdx) => (
                            <li key={pIdx}>{pit}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Master Complete Chapter Mode */}
            {selectedRevisionMode === 'complete' && (
              <div className="space-y-5">
                <div className="space-y-4">
                  {rev.masterConcepts.map((mc, mcIdx) => (
                    <div key={mcIdx} className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                      <h4 className="text-sm font-bold text-emerald-400">{mc.heading}</h4>
                      <p className="text-xs md:text-sm text-slate-300 leading-relaxed">{mc.content}</p>
                      {mc.formulas && (
                        <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 space-y-1 mt-2">
                          {mc.formulas.map((f, fIdx) => (
                            <div key={fIdx} className="text-xs text-indigo-300">
                              <MathRenderer content={f} />
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Always Visible: Shortcuts & Frequent Mistakes Footer */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t border-slate-800">
              {/* Shortcuts */}
              <div className="bg-amber-950/20 border border-amber-500/30 p-3.5 rounded-xl space-y-2">
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" /> Exam Shortcuts & Speed Tricks
                </span>
                <ul className="space-y-1.5 text-xs text-amber-200/90">
                  {rev.shortcutsAndTricks.map((s, sIdx) => (
                    <li key={sIdx} className="flex items-start gap-1.5">
                      <span className="text-amber-400">&bull;</span>
                      <span><MathRenderer content={s} inline /></span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Mistakes */}
              <div className="bg-rose-950/20 border border-rose-500/30 p-3.5 rounded-xl space-y-2">
                <span className="text-xs font-bold text-rose-400 uppercase tracking-wider flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" /> Frequent -1 Mistakes to Avoid
                </span>
                <ul className="space-y-1.5 text-xs text-rose-200/90">
                  {rev.frequentMistakes.map((m, mIdx) => (
                    <li key={mIdx} className="flex items-start gap-1.5">
                      <span className="text-rose-400">&bull;</span>
                      <span>{m}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RevisionCentreView;
