'use client';

import React from 'react';
import { MOCK_TEST_CATALOG, MockTestMeta } from '@/data/pyqRepository';
import { StudentProfile } from '@/utils/studentStore';
import { 
  Clock, 
  Award, 
  Play, 
  CheckCircle2, 
  Flame, 
  ShieldCheck, 
  AlertCircle, 
  GraduationCap,
  Sparkles
} from 'lucide-react';

interface MockTestCenterViewProps {
  profile: StudentProfile;
  onSelectMockTest: (mockId: string) => void;
  onSelectSubjectTest: (subject: 'physics' | 'chemistry' | 'mathematics') => void;
}

export const MockTestCenterView: React.FC<MockTestCenterViewProps> = ({
  profile,
  onSelectMockTest,
  onSelectSubjectTest,
}) => {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-1">
            <Clock className="w-4 h-4" /> Official NTA Simulation Series
          </div>
          <h1 className="text-2xl font-bold text-white">10 Full-Length JEE Main Mock Tests</h1>
          <p className="text-xs md:text-sm text-slate-400 mt-1">
            10 dedicated 3-hour examination papers (75 Qs, 300 Marks, +4/-1 scoring) with non-overlapping authentic PYQs, 
            realistic national percentile estimation, and <strong>Kota Teacher Hinglish Mentorship</strong> on submission.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-center">
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Available Mocks</span>
            <strong className="text-emerald-400 text-base">10 Full Tests (750 Qs)</strong>
          </div>
        </div>
      </div>

      {/* Kota Teacher Exam Tip Banner */}
      <div className="bg-gradient-to-r from-amber-950/30 via-slate-900 to-indigo-950/30 border border-amber-500/30 rounded-2xl p-5 shadow-lg flex items-start gap-4">
        <div className="w-10 h-10 rounded-full bg-amber-500 flex items-center justify-center shrink-0 text-slate-950 shadow-md">
          <GraduationCap className="w-6 h-6" />
        </div>
        <div className="space-y-1">
          <h3 className="text-sm font-bold text-amber-300 flex items-center gap-2">
            Kota Guru Ji Advice: Mock Test Strategy (बेटा, 200+ Score Kaise Karein?)
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            "Dekho beta, pehle 45 minutes mein <strong>Chemistry</strong> niptao (target 60-70 marks). Phir 60 minutes mein <strong>Physics</strong> ke direct formula questions lagao. Bacha hua time <strong>Mathematics</strong> ke un questions ko do jinke steps small hain (jaise Vectors & 3D Lines ya Matrices). Ego par koi question mat lena beta, agar 2 minute mein answer nahi dikhe toh mark for review karke aage badho!"
          </p>
        </div>
      </div>

      {/* 10 Full-Length Mock Tests Grid */}
      <div className="space-y-4">
        <h2 className="text-base font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-emerald-400" /> Full Syllabus Paper 1 Series (Mock 01 to Mock 10)
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {MOCK_TEST_CATALOG.map((mock) => {
            // Check if student already attempted this mock
            const previousAttempt = profile.mockTestResults.find((r) => r.testTitle.includes(mock.title));
            const diffColor =
              mock.difficulty === 'Hard'
                ? 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                : mock.difficulty === 'Moderate'
                ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';

            return (
              <div
                key={mock.id}
                className="bg-slate-900/90 border border-slate-800 hover:border-indigo-500/50 rounded-xl p-5 shadow-lg space-y-4 transition-all duration-200 flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
                    <span className="font-mono text-xs px-2.5 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 font-bold border border-indigo-500/30">
                      MOCK #{mock.testNumber.toString().padStart(2, '0')}
                    </span>
                    <span className={`text-[10px] px-2 py-0.5 rounded border uppercase font-bold ${diffColor}`}>
                      {mock.difficulty}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-base font-bold text-white">{mock.title}</h3>
                    <p className="text-xs text-indigo-400 font-semibold">{mock.subtitle}</p>
                    <p className="text-xs text-slate-400 mt-2 leading-relaxed">{mock.description}</p>
                  </div>

                  {/* Specifications */}
                  <div className="grid grid-cols-3 gap-2 text-center text-xs py-1">
                    <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                      <span className="text-slate-400 block text-[10px]">Questions</span>
                      <strong className="text-white">{mock.totalQuestions} Qs</strong>
                    </div>
                    <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                      <span className="text-slate-400 block text-[10px]">Max Marks</span>
                      <strong className="text-emerald-400">{mock.totalMarks}</strong>
                    </div>
                    <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                      <span className="text-slate-400 block text-[10px]">Duration</span>
                      <strong className="text-amber-400">{mock.durationMinutes} Mins</strong>
                    </div>
                  </div>
                </div>

                {/* Bottom Action / Past Score */}
                <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-3">
                  {previousAttempt ? (
                    <div className="text-xs">
                      <span className="text-slate-400 block">Best Score:</span>
                      <strong className="text-emerald-400 font-bold">
                        {previousAttempt.totalMarks}/300 ({previousAttempt.percentileEstimate}%ile)
                      </strong>
                    </div>
                  ) : (
                    <span className="text-xs text-slate-500">Not Attempted Yet</span>
                  )}

                  <button
                    onClick={() => onSelectMockTest(mock.id)}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg text-xs transition-all flex items-center gap-1.5 shadow-md shadow-indigo-600/20 cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5 fill-white" />
                    <span>{previousAttempt ? 'Retake Mock Test' : 'Start 3-Hour Simulation'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Subject-Wise Fast Drills Section */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-400" /> Subject-Specific Speed Drills (60 Mins - 25 Questions)
        </h3>
        <p className="text-xs text-slate-400">
          Tight on time? Test individual subjects in standard 60-minute examination conditions (20 MCQs + 5 Numericals, 100 Marks).
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <button
            onClick={() => onSelectSubjectTest('physics')}
            className="p-4 rounded-xl bg-slate-950 border border-sky-500/30 hover:border-sky-500 text-left transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-sky-400 uppercase">Physics Drill</span>
              <span className="text-[10px] text-slate-400">25 Qs &bull; 100 M</span>
            </div>
            <p className="text-xs text-slate-300">Mechanics, Modern Physics, Electrodynamics mix</p>
            <span className="text-xs text-sky-400 font-semibold mt-3 block group-hover:underline">
              Start Physics Test &rarr;
            </span>
          </button>

          <button
            onClick={() => onSelectSubjectTest('chemistry')}
            className="p-4 rounded-xl bg-slate-950 border border-emerald-500/30 hover:border-emerald-500 text-left transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-emerald-400 uppercase">Chemistry Drill</span>
              <span className="text-[10px] text-slate-400">25 Qs &bull; 100 M</span>
            </div>
            <p className="text-xs text-slate-300">Physical stoichiometry, Coordination, GOC</p>
            <span className="text-xs text-emerald-400 font-semibold mt-3 block group-hover:underline">
              Start Chemistry Test &rarr;
            </span>
          </button>

          <button
            onClick={() => onSelectSubjectTest('mathematics')}
            className="p-4 rounded-xl bg-slate-950 border border-pink-500/30 hover:border-pink-500 text-left transition-all cursor-pointer group"
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-pink-400 uppercase">Mathematics Drill</span>
              <span className="text-[10px] text-slate-400">25 Qs &bull; 100 M</span>
            </div>
            <p className="text-xs text-slate-300">Vectors & 3D lines, Integrals, Matrices</p>
            <span className="text-xs text-pink-400 font-semibold mt-3 block group-hover:underline">
              Start Mathematics Test &rarr;
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default MockTestCenterView;
