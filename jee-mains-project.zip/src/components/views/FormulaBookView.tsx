'use client';

import React, { useState } from 'react';
import { FORMULA_BOOK } from '@/data/formulaBookData';
import { SubjectType } from '@/types';
import MathRenderer from '../MathRenderer';
import { 
  Bookmark, 
  Search, 
  HelpCircle, 
  CheckCircle, 
  Info, 
  AlertCircle, 
  ChevronDown, 
  ChevronUp,
  BookOpen
} from 'lucide-react';

export const FormulaBookView: React.FC = () => {
  const [selectedSubject, setSelectedSubject] = useState<SubjectType>('physics');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const filteredFormulas = FORMULA_BOOK.filter((item) => {
    if (item.subject !== selectedSubject) return false;
    if (searchQuery.trim().length === 0) return true;
    const q = searchQuery.toLowerCase();
    return (
      item.title.toLowerCase().includes(q) ||
      item.chapterName.toLowerCase().includes(q) ||
      item.topicName.toLowerCase().includes(q) ||
      item.application.toLowerCase().includes(q)
    );
  });

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-1">
            <Bookmark className="w-4 h-4" /> Comprehensive Formula Compendium
          </div>
          <h1 className="text-2xl font-bold text-white">Interactive JEE Main Formula Book</h1>
          <p className="text-xs md:text-sm text-slate-400 mt-1">
            Complete with <strong>symbol meanings</strong>, <strong>SI units</strong>, <strong>operational limits</strong>, 
            <strong>conditions of application</strong>, and <strong>worked example questions</strong>.
          </p>
        </div>

        {/* Search */}
        <div className="relative min-w-[260px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search formulas by name or concept..."
            className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-4 py-2 text-xs md:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Subject Filter Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
        {(['physics', 'chemistry', 'mathematics'] as SubjectType[]).map((subj) => {
          const isActive = selectedSubject === subj;
          const label =
            subj === 'physics'
              ? 'Physics Formula Book'
              : subj === 'chemistry'
              ? 'Chemistry Formula Book'
              : 'Mathematics Formula Book';
          const count = FORMULA_BOOK.filter((f) => f.subject === subj).length;

          return (
            <button
              key={subj}
              onClick={() => {
                setSelectedSubject(subj);
                setExpandedId(null);
              }}
              className={`px-4 py-2 rounded-xl text-xs md:text-sm font-semibold transition-all flex items-center gap-2 cursor-pointer ${
                isActive
                  ? 'bg-indigo-600 text-white shadow'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
              }`}
            >
              <span>{label}</span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${isActive ? 'bg-white/20' : 'bg-slate-800 text-slate-400'}`}>
                {count} Core Formulas
              </span>
            </button>
          );
        })}
      </div>

      {/* Formula List */}
      <div className="space-y-4">
        {filteredFormulas.map((item) => {
          const isExpanded = expandedId === item.id;
          return (
            <div
              key={item.id}
              className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4 hover:border-slate-700 transition-all"
            >
              {/* Card Header */}
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs px-2.5 py-1 rounded-md bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 font-bold uppercase">
                    {item.subject}
                  </span>
                  <span className="text-xs text-slate-400 font-medium">{item.chapterName} &bull; {item.topicName}</span>
                </div>
                {item.pyqRefId && (
                  <span className="text-xs text-slate-400 font-mono">
                    Related PYQ: <strong className="text-slate-300">{item.pyqRefId}</strong>
                  </span>
                )}
              </div>

              {/* Title & Display Formula */}
              <div>
                <h3 className="text-base font-bold text-white mb-2">{item.title}</h3>
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-center overflow-x-auto">
                  <MathRenderer content={`$$${item.formulaLatex}$$`} />
                </div>
              </div>

              {/* Metadata Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                {/* Symbol Meanings */}
                <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-1.5">
                  <span className="uppercase text-[10px] font-bold text-slate-400 block tracking-wider flex items-center gap-1">
                    <Info className="w-3.5 h-3.5 text-indigo-400" /> Symbol Meanings & SI Units:
                  </span>
                  <div className="space-y-1 text-slate-300">
                    {item.symbolMeanings.map((sym, sIdx) => (
                      <div key={sIdx} className="flex items-start gap-1.5">
                        <span className="font-mono font-bold text-indigo-300 shrink-0">
                          <MathRenderer content={`$${sym.symbol}$`} inline />:
                        </span>
                        <span>{sym.meaning}</span>
                      </div>
                    ))}
                    <div className="pt-1 text-slate-400 text-[11px] border-t border-slate-800 mt-1">
                      SI Units: <strong className="text-slate-200">{item.siUnits}</strong>
                    </div>
                  </div>
                </div>

                {/* Application & Conditions */}
                <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-2">
                  <div>
                    <span className="uppercase text-[10px] font-bold text-emerald-400 block tracking-wider mb-0.5">
                      Operational Application:
                    </span>
                    <p className="text-slate-300 text-xs">{item.application}</p>
                  </div>

                  <div>
                    <span className="uppercase text-[10px] font-bold text-rose-400 block tracking-wider mb-0.5 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 text-rose-400" /> Conditions of Validity:
                    </span>
                    <p className="text-rose-200/90 text-xs">{item.conditions}</p>
                  </div>
                </div>
              </div>

              {/* Worked Example Accordion */}
              <div className="pt-2 border-t border-slate-800">
                <button
                  onClick={() => toggleExpand(item.id)}
                  className="flex items-center justify-between w-full text-xs font-semibold text-indigo-400 hover:text-indigo-300 transition-colors cursor-pointer"
                >
                  <span className="flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>{isExpanded ? 'Hide Worked Exam Problem' : 'View Worked Exemplar Problem & Fast Derivation'}</span>
                  </span>
                  {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>

                {isExpanded && (
                  <div className="mt-3 p-4 rounded-xl bg-slate-950 border border-indigo-500/30 text-xs space-y-2 text-slate-300">
                    <p className="font-medium text-slate-100">
                      <strong>Problem: </strong>
                      <MathRenderer content={item.exampleProblem.question} inline />
                    </p>
                    <p className="text-emerald-400 font-bold">
                      Answer: {item.exampleProblem.answer}
                    </p>
                    <p className="text-slate-400">
                      <strong>Quick Approach: </strong>
                      {item.exampleProblem.quickSolution}
                    </p>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default FormulaBookView;
