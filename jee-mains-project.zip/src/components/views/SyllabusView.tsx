'use client';

import React, { useState } from 'react';
import { OFFICIAL_SYLLABUS_CHAPTERS } from '@/data/syllabusData';
import { SubjectType, Chapter } from '@/types';
import { 
  BookOpen, 
  Search, 
  AlertTriangle, 
  CheckCircle2, 
  TrendingUp, 
  MinusCircle, 
  ChevronDown, 
  ChevronRight,
  ShieldAlert
} from 'lucide-react';

export const SyllabusView: React.FC = () => {
  const [activeSubject, setActiveSubject] = useState<SubjectType | 'deleted'>('physics');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [expandedChapterIds, setExpandedChapterIds] = useState<Record<string, boolean>>({
    'phy-modern-physics': true,
    'chem-coordination': true,
    'math-vectors-3d': true,
  });

  const toggleChapter = (chId: string) => {
    setExpandedChapterIds((prev) => ({ ...prev, [chId]: !prev[chId] }));
  };

  const filteredChapters = OFFICIAL_SYLLABUS_CHAPTERS.filter((ch) => {
    if (activeSubject !== 'deleted' && ch.subject !== activeSubject) return false;
    if (searchQuery.trim().length === 0) return true;
    const q = searchQuery.toLowerCase();
    return (
      ch.name.toLowerCase().includes(q) ||
      ch.code.toLowerCase().includes(q) ||
      ch.topics.some((t) => t.name.toLowerCase().includes(q) || t.subtopics.some((s) => s.name.toLowerCase().includes(q)))
    );
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-1">
            <BookOpen className="w-4 h-4" /> Official NTA Rationalized Curriculum
          </div>
          <h1 className="text-2xl font-bold text-white">Official JEE Main Paper 1 Syllabus</h1>
          <p className="text-xs md:text-sm text-slate-400">
            Strict hierarchy: <strong>Subject &rarr; Chapter &rarr; Topic &rarr; Subtopic</strong>. 
            All deleted topics permanently pruned from active study paths.
          </p>
        </div>

        {/* Search */}
        <div className="relative min-w-[260px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search chapter, topic, formula..."
            className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-4 py-2 text-xs md:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
        {(['physics', 'chemistry', 'mathematics'] as SubjectType[]).map((subj) => {
          const isActive = activeSubject === subj;
          const label = subj === 'physics' ? 'Physics' : subj === 'chemistry' ? 'Chemistry' : 'Mathematics';
          const count = OFFICIAL_SYLLABUS_CHAPTERS.filter((c) => c.subject === subj).length;
          return (
            <button
              key={subj}
              onClick={() => setActiveSubject(subj)}
              className={`px-4 py-2 rounded-xl text-xs md:text-sm font-semibold transition-all flex items-center gap-2 cursor-pointer ${
                isActive
                  ? 'bg-indigo-600 text-white shadow'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
              }`}
            >
              <span>{label}</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${isActive ? 'bg-white/20' : 'bg-slate-800 text-slate-400'}`}>
                {count} Chapters
              </span>
            </button>
          );
        })}

        {/* Deleted Syllabus Audit Tab */}
        <button
          onClick={() => setActiveSubject('deleted')}
          className={`px-4 py-2 rounded-xl text-xs md:text-sm font-semibold transition-all flex items-center gap-2 cursor-pointer ${
            activeSubject === 'deleted'
              ? 'bg-rose-600 text-white shadow'
              : 'bg-rose-500/10 text-rose-300 hover:bg-rose-500/20 border border-rose-500/30'
          }`}
        >
          <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
          <span>Deleted Syllabus Audit (Excluded Topics)</span>
        </button>
      </div>

      {/* Active Subject Syllabus Tree */}
      {activeSubject !== 'deleted' ? (
        <div className="space-y-4">
          {filteredChapters.map((chapter) => {
            const isExpanded = !!expandedChapterIds[chapter.id];
            const priorityBadge =
              chapter.priority === 'HIGH'
                ? 'bg-rose-500/10 border-rose-500/30 text-rose-400'
                : chapter.priority === 'MEDIUM'
                ? 'bg-amber-500/10 border-amber-500/30 text-amber-400'
                : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400';

            return (
              <div
                key={chapter.id}
                className="bg-slate-900/90 border border-slate-800 rounded-xl overflow-hidden transition-all"
              >
                {/* Chapter Banner */}
                <div
                  onClick={() => toggleChapter(chapter.id)}
                  className="p-4 md:p-5 flex items-center justify-between gap-4 cursor-pointer hover:bg-slate-800/40"
                >
                  <div className="flex items-center gap-3">
                    <button className="text-slate-400">
                      {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                    </button>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-bold">
                          {chapter.code}
                        </span>
                        <h2 className="text-sm md:text-base font-bold text-white">{chapter.name}</h2>
                        <span className={`text-[10px] uppercase px-2 py-0.5 rounded border font-bold ${priorityBadge}`}>
                          {chapter.priority} PRIORITY
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 text-xs shrink-0">
                    <div className="text-right hidden sm:block">
                      <span className="text-slate-400 block text-[10px]">Avg Qs / Paper</span>
                      <strong className="text-indigo-400 text-sm">{chapter.avgQuestionsPerPaper}</strong>
                    </div>
                    <div className="text-right hidden sm:block">
                      <span className="text-slate-400 block text-[10px]">Hist. Weightage</span>
                      <strong className="text-emerald-400 text-sm">{chapter.historicalWeightage}%</strong>
                    </div>
                  </div>
                </div>

                {/* Topics & Subtopics Drawer */}
                {isExpanded && (
                  <div className="px-5 pb-5 pt-1 border-t border-slate-800/80 bg-slate-950/40 space-y-4">
                    {chapter.topics.map((topic, tIdx) => (
                      <div key={topic.id} className="border-l-2 border-indigo-500/40 pl-4 space-y-2">
                        <h3 className="text-xs md:text-sm font-semibold text-indigo-300 flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                          Topic {tIdx + 1}: {topic.name}
                        </h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 pt-1">
                          {topic.subtopics.map((sub) => (
                            <div
                              key={sub.id}
                              className="text-xs bg-slate-900 border border-slate-800 p-2.5 rounded-lg text-slate-300 flex items-start gap-2"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                              <span>{sub.name}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ) : (
        /* Deleted Syllabus Audit View */
        <div className="space-y-6">
          <div className="bg-rose-950/20 border border-rose-500/30 p-5 rounded-xl space-y-2 text-xs md:text-sm text-rose-200">
            <h3 className="text-base font-bold text-rose-300 flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-rose-400" />
              Official NTA Rationalized / Deleted Topic Audit
            </h3>
            <p>
              The following chapters and topics were <strong>officially purged</strong> from the JEE Main examination by NTA.
              Our platform strictly excludes these topics so that you never waste time studying obsolete material.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* Physics Deleted */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
              <h3 className="text-sm font-bold text-sky-400 uppercase tracking-wider border-b border-slate-800 pb-2">
                Physics: Deleted Content
              </h3>
              <ul className="text-xs text-slate-300 space-y-2">
                <li className="flex items-start gap-2">
                  <MinusCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  <span><strong>Communication Systems:</strong> Entire chapter removed.</span>
                </li>
                <li className="flex items-start gap-2">
                  <MinusCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  <span><strong>Transistors:</strong> npn/pnp, amplifier characteristics removed.</span>
                </li>
                <li className="flex items-start gap-2">
                  <MinusCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  <span><strong>Earth Magnetism Elements:</strong> Magnetic inclination, dip, declination details removed.</span>
                </li>
                <li className="flex items-start gap-2">
                  <MinusCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  <span><strong>Carnot Engine:</strong> Carnot cycle and efficiency removed.</span>
                </li>
                <li className="flex items-start gap-2">
                  <MinusCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  <span><strong>Damped Oscillations & Doppler Effect:</strong> Specific acoustic Doppler equations removed.</span>
                </li>
                <li className="flex items-start gap-2">
                  <MinusCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  <span><strong>Potentiometer:</strong> Replaced exclusively by Meter Bridge in experimental physics.</span>
                </li>
              </ul>
            </div>

            {/* Chemistry Deleted */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
              <h3 className="text-sm font-bold text-emerald-400 uppercase tracking-wider border-b border-slate-800 pb-2">
                Chemistry: Deleted Content
              </h3>
              <ul className="text-xs text-slate-300 space-y-2">
                <li className="flex items-start gap-2">
                  <MinusCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  <span><strong>States of Matter:</strong> Gaseous and Liquid States chapter removed.</span>
                </li>
                <li className="flex items-start gap-2">
                  <MinusCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  <span><strong>Solid State:</strong> Entire chapter removed.</span>
                </li>
                <li className="flex items-start gap-2">
                  <MinusCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  <span><strong>Surface Chemistry:</strong> Entire chapter removed.</span>
                </li>
                <li className="flex items-start gap-2">
                  <MinusCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  <span><strong>Hydrogen & s-Block Elements:</strong> Entire chapters removed.</span>
                </li>
                <li className="flex items-start gap-2">
                  <MinusCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  <span><strong>Metallurgy:</strong> General Principles & Isolation removed.</span>
                </li>
                <li className="flex items-start gap-2">
                  <MinusCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  <span><strong>Polymers & Everyday Chemistry:</strong> Entire chapters removed.</span>
                </li>
                <li className="flex items-start gap-2">
                  <MinusCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  <span><strong>Environmental Chemistry:</strong> Entire chapter removed.</span>
                </li>
              </ul>
            </div>

            {/* Mathematics Deleted */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
              <h3 className="text-sm font-bold text-pink-400 uppercase tracking-wider border-b border-slate-800 pb-2">
                Mathematics: Deleted Content
              </h3>
              <ul className="text-xs text-slate-300 space-y-2">
                <li className="flex items-start gap-2">
                  <MinusCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  <span><strong>Mathematical Induction:</strong> Entire chapter removed.</span>
                </li>
                <li className="flex items-start gap-2">
                  <MinusCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  <span><strong>Mathematical Reasoning:</strong> Entire logic/reasoning chapter removed.</span>
                </li>
                <li className="flex items-start gap-2">
                  <MinusCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  <span><strong>Planes in 3D:</strong> Critical! Only 3D lines are active; Plane equations are deleted.</span>
                </li>
                <li className="flex items-start gap-2">
                  <MinusCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  <span><strong>Scalar/Vector Triple Products:</strong> Only dot and cross products retained.</span>
                </li>
                <li className="flex items-start gap-2">
                  <MinusCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  <span><strong>Rolle's & LMVT:</strong> Mean value theorems removed from AOD.</span>
                </li>
                <li className="flex items-start gap-2">
                  <MinusCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                  <span><strong>Special Series Summation:</strong> Sigma n, n^2, n^3 and AGP removed.</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SyllabusView;
