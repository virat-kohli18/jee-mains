'use client';

import React, { useState, useMemo } from 'react';
import { CLASS_12_BOARD_QUESTIONS } from '@/data/boardData';
import { BoardQuestionFormat, SubjectType } from '@/types';
import BoardQuestionCard from '@/components/BoardQuestionCard';
import { 
  Layers, 
  Search, 
  Award, 
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  Sparkles
} from 'lucide-react';

const PAGE_SIZE = 20;

export const BoardQuestionBankView: React.FC = () => {
  const [selectedSubject, setSelectedSubject] = useState<SubjectType | 'all'>('all');
  const [selectedFormat, setSelectedFormat] = useState<BoardQuestionFormat | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState<number>(1);

  const filteredQuestions = useMemo(() => {
    return CLASS_12_BOARD_QUESTIONS.filter((q) => {
      const matchesSub = selectedSubject === 'all' || q.subject === selectedSubject;
      const matchesFormat = selectedFormat === 'all' || q.format === selectedFormat;
      const matchesSearch = q.questionText.toLowerCase().includes(searchQuery.toLowerCase()) ||
        q.chapterName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        q.board.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesSub && matchesFormat && matchesSearch;
    });
  }, [selectedSubject, selectedFormat, searchQuery]);

  const totalPages = Math.ceil(filteredQuestions.length / PAGE_SIZE) || 1;
  const paginatedQuestions = useMemo(() => {
    const start = (currentPage - 1) * PAGE_SIZE;
    return filteredQuestions.slice(start, start + PAGE_SIZE);
  }, [filteredQuestions, currentPage]);

  const handleSubjectChange = (sub: SubjectType | 'all') => {
    setSelectedSubject(sub);
    setCurrentPage(1);
  };

  const handleFormatChange = (fmt: BoardQuestionFormat | 'all') => {
    setSelectedFormat(fmt);
    setCurrentPage(1);
  };

  const handlePageChange = (newPage: number) => {
    setCurrentPage(newPage);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleResetFilters = () => {
    setSelectedSubject('all');
    setSelectedFormat('all');
    setSearchQuery('');
    setCurrentPage(1);
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-2">
            <Layers className="w-3.5 h-3.5" />
            Class 12th Board Interactive Question Bank
          </div>
          <h1 className="text-2xl md:text-3xl font-black text-white">
            1,000+ Board Questions (Interactive Mode)
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            Click any option for instant pop sound, live answer validation, and full English explanations with step-wise marks allocation.
          </p>
        </div>

        {/* Counter Pill */}
        <div className="flex items-center gap-2">
          <div className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-2xl text-xs font-bold text-slate-300 flex items-center gap-2 shrink-0">
            <Award className="w-4 h-4 text-emerald-400" />
            <span>{filteredQuestions.length} Total Questions</span>
          </div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="space-y-3 bg-slate-900/80 p-4 rounded-3xl border border-slate-800">
        {/* Subject Filter */}
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mr-2">Subject:</span>
            {(['all', 'physics', 'chemistry', 'mathematics'] as const).map((sub) => {
              const isActive = selectedSubject === sub;
              return (
                <button
                  key={sub}
                  onClick={() => handleSubjectChange(sub)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer ${
                    isActive
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                      : 'bg-slate-950 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
                  }`}
                >
                  {sub === 'all' ? 'All Subjects' : sub}
                </button>
              );
            })}
          </div>

          <button
            onClick={handleResetFilters}
            className="text-xs text-slate-400 hover:text-white flex items-center gap-1 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3 h-3" /> Reset
          </button>
        </div>

        {/* Format Filter */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-800/80">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mr-2">Format:</span>
          {[
            { id: 'all', label: 'All Formats' },
            { id: 'MCQ', label: '1M: MCQs (Clickable)' },
            { id: 'ASSERTION_REASON', label: '1M: Assertion-Reason' },
            { id: 'VSA', label: '2M: Very Short Answer' },
            { id: 'SA', label: '3M: Short Answer' },
            { id: 'CASE_BASED', label: '4M: Case Studies' },
            { id: 'LA', label: '5M: Long Answer / Derivations' },
          ].map((item) => {
            const isActive = selectedFormat === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleFormatChange(item.id as any)}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                    : 'bg-slate-950 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>

        {/* Search */}
        <div className="relative pt-2 border-t border-slate-800/80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-5" />
          <input
            type="text"
            placeholder="Search questions by topic, keyword, or board..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Interactive Helper Banner */}
      <div className="flex items-center justify-between p-3.5 rounded-2xl bg-indigo-950/20 border border-indigo-500/20 text-xs text-slate-300">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-indigo-400 shrink-0" />
          <span>
            <strong className="text-white">JEE Main Style Interactive Options:</strong> Click any option to hear the pop sound, receive instant green/red feedback, and view the full English step-by-step evaluation!
          </span>
        </div>
        <span className="text-slate-400 font-mono hidden sm:inline-block">
          Page {currentPage} of {totalPages}
        </span>
      </div>

      {/* Question Cards List */}
      <div className="space-y-4">
        {paginatedQuestions.length === 0 ? (
          <div className="p-12 text-center bg-slate-900/40 rounded-3xl border border-slate-800 text-slate-400 text-sm">
            No board questions found matching your filter criteria.
          </div>
        ) : (
          paginatedQuestions.map((q, idx) => (
            <BoardQuestionCard 
              key={q.id} 
              question={q} 
              questionNumber={(currentPage - 1) * PAGE_SIZE + idx + 1} 
            />
          ))
        )}
      </div>

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between pt-6 border-t border-slate-800">
          <button
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs font-bold text-slate-300 hover:text-white hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-all"
          >
            <ChevronLeft className="w-4 h-4" /> Previous Page
          </button>

          <span className="text-xs text-slate-400 font-medium">
            Page <strong className="text-white">{currentPage}</strong> of <strong className="text-white">{totalPages}</strong>
          </span>

          <button
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs font-bold text-slate-300 hover:text-white hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-all"
          >
            Next Page <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};

export default BoardQuestionBankView;
