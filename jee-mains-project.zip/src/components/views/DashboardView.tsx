'use client';

import React from 'react';
import { StudentProfile } from '@/utils/studentStore';
import { 
  CheckCircle2, 
  Target, 
  Flame, 
  Clock, 
  TrendingUp, 
  AlertTriangle, 
  BookOpen, 
  Zap, 
  Play, 
  Award,
  ArrowRight
} from 'lucide-react';
import { NavTab } from '../Sidebar';

interface DashboardViewProps {
  profile: StudentProfile;
  totalPYQCount: number;
  onNavigate: (tab: NavTab) => void;
  onLaunchMockTest: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  profile,
  totalPYQCount,
  onNavigate,
  onLaunchMockTest,
}) => {
  const solvedCount = Object.keys(profile.solvedQuestionIds).length;
  const correctCount = Object.values(profile.solvedQuestionIds).filter((q) => q.isCorrect).length;
  const accuracy = solvedCount > 0 ? Math.round((correctCount / solvedCount) * 100) : 0;
  const prepPercentage = Math.min(100, Math.round((solvedCount / totalPYQCount) * 100));

  const errorCount = profile.errorNotebook.length;
  const unretriedErrors = profile.errorNotebook.filter((e) => !e.retried).length;

  const latestMock = profile.mockTestResults[0];

  return (
    <div className="space-y-6">
      {/* Hero Welcome Banner */}
      <div className="bg-gradient-to-r from-indigo-900/60 via-slate-900 to-slate-900 border border-indigo-500/30 rounded-2xl p-6 md:p-8 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-500/40 text-xs font-semibold text-indigo-300">
              <SparkleIcon /> Master Preparation Hub &bull; JEE Main 2027
            </div>
            <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
              Welcome back, Candidate
            </h1>
            <p className="text-sm md:text-base text-slate-300 leading-relaxed">
              Exclusively calibrated for <strong>JEE MAIN PAPER 1 (B.E./B.Tech)</strong>. Zero extraneous content, 
              100% official NTA rationalized syllabus with <strong>{totalPYQCount}+ verified authentic PYQs</strong>.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={onLaunchMockTest}
              className="px-6 py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-sm transition-all shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 group cursor-pointer"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>Launch 3-Hr NTA Mock Test</span>
            </button>
            <button
              onClick={() => onNavigate('pyqs')}
              className="px-5 py-3.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-xl text-sm transition-all border border-slate-700 flex items-center justify-center gap-2 cursor-pointer"
            >
              <BookOpen className="w-4 h-4" />
              <span>Practice PYQs</span>
            </button>
          </div>
        </div>
      </div>

      {/* Preparation Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Overall Completion */}
        <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-xl space-y-1">
          <span className="text-xs text-slate-400 font-medium flex items-center gap-1.5">
            <Target className="w-3.5 h-3.5 text-indigo-400" /> Syllabus Coverage
          </span>
          <div className="text-2xl font-bold text-white">{prepPercentage}%</div>
          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div className="bg-indigo-500 h-full rounded-full transition-all" style={{ width: `${prepPercentage}%` }} />
          </div>
        </div>

        {/* Total PYQs Solved */}
        <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-xl space-y-1">
          <span className="text-xs text-slate-400 font-medium flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> PYQs Solved
          </span>
          <div className="text-2xl font-bold text-emerald-400">
            {solvedCount}{' '}
            <span className="text-xs text-slate-500 font-normal">/ {totalPYQCount}</span>
          </div>
          <span className="text-[11px] text-slate-400 block">{correctCount} verified correct</span>
        </div>

        {/* Accuracy Rate */}
        <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-xl space-y-1">
          <span className="text-xs text-slate-400 font-medium flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-sky-400" /> Problem Accuracy
          </span>
          <div className="text-2xl font-bold text-sky-400">{accuracy}%</div>
          <span className="text-[11px] text-slate-400 block">Target: &gt;85% for Top NITs</span>
        </div>

        {/* Daily Streak */}
        <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-xl space-y-1">
          <span className="text-xs text-slate-400 font-medium flex items-center gap-1.5">
            <Flame className="w-3.5 h-3.5 text-amber-500" /> Prep Streak
          </span>
          <div className="text-2xl font-bold text-amber-400">{profile.streakDays} Days</div>
          <span className="text-[11px] text-slate-400 block">Goal: 25 PYQs / day</span>
        </div>
      </div>

      {/* Subject-Wise Mastery Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Physics Card */}
        <div className="bg-slate-900/80 border border-slate-800 hover:border-sky-500/40 rounded-xl p-5 space-y-4 transition-all">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-sky-400" />
              <h3 className="text-base font-bold text-white">Physics</h3>
            </div>
            <span className="text-xs px-2.5 py-1 rounded bg-sky-500/10 text-sky-400 border border-sky-500/20 font-semibold">
              779+ PYQs
            </span>
          </div>
          <p className="text-xs text-slate-400">
            Top weightage: <strong>Modern Physics (12.8%)</strong>, Current Electricity (10.0%), Electrostatics (8.8%).
          </p>
          <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-800/80">
            <button
              onClick={() => onNavigate('revision')}
              className="text-sky-400 hover:underline flex items-center gap-1 font-medium"
            >
              15-Min Notes <ArrowRight className="w-3 h-3" />
            </button>
            <button
              onClick={() => onNavigate('formulas')}
              className="text-slate-400 hover:text-white"
            >
              Formula Book
            </button>
          </div>
        </div>

        {/* Chemistry Card */}
        <div className="bg-slate-900/80 border border-slate-800 hover:border-emerald-500/40 rounded-xl p-5 space-y-4 transition-all">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-emerald-400" />
              <h3 className="text-base font-bold text-white">Chemistry</h3>
            </div>
            <span className="text-xs px-2.5 py-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-semibold">
              780+ PYQs
            </span>
          </div>
          <p className="text-xs text-slate-400">
            Top weightage: <strong>Coordination Compounds (10.4%)</strong>, GOC (10.0%), Chemical Bonding (9.6%).
          </p>
          <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-800/80">
            <button
              onClick={() => onNavigate('revision')}
              className="text-emerald-400 hover:underline flex items-center gap-1 font-medium"
            >
              15-Min Notes <ArrowRight className="w-3 h-3" />
            </button>
            <button
              onClick={() => onNavigate('formulas')}
              className="text-slate-400 hover:text-white"
            >
              Formula Book
            </button>
          </div>
        </div>

        {/* Mathematics Card */}
        <div className="bg-slate-900/80 border border-slate-800 hover:border-pink-500/40 rounded-xl p-5 space-y-4 transition-all">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-pink-400" />
              <h3 className="text-base font-bold text-white">Mathematics</h3>
            </div>
            <span className="text-xs px-2.5 py-1 rounded bg-pink-500/10 text-pink-400 border border-pink-500/20 font-semibold">
              700+ PYQs
            </span>
          </div>
          <p className="text-xs text-slate-400">
            Top weightage: <strong>Vectors & 3D Lines (12.8%)</strong>, Definite Integrals (10.4%), Matrices (9.6%).
          </p>
          <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-800/80">
            <button
              onClick={() => onNavigate('revision')}
              className="text-pink-400 hover:underline flex items-center gap-1 font-medium"
            >
              15-Min Notes <ArrowRight className="w-3 h-3" />
            </button>
            <button
              onClick={() => onNavigate('formulas')}
              className="text-slate-400 hover:text-white"
            >
              Formula Book
            </button>
          </div>
        </div>
      </div>

      {/* Two Column Layout: Quick Actions & Error Alert */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Error Notebook Alert */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                Error Notebook Diagnostics
              </h3>
            </div>
            <span className="text-xs px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 font-semibold">
              {errorCount} Logged
            </span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Every question you miss in mock tests or practice is auto-logged here. Review and retry your{' '}
            <strong className="text-rose-400">{unretriedErrors} unretried questions</strong> to convert weak points into guaranteed marks.
          </p>
          <div className="pt-2">
            <button
              onClick={() => onNavigate('errors')}
              className="w-full py-2.5 rounded-lg bg-rose-600/20 hover:bg-rose-600/30 border border-rose-500/30 text-rose-300 text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <span>Open Error Notebook & Retry Questions</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Latest Mock Test Summary */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-400" />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                Latest Mock Exam Result
              </h3>
            </div>
            {latestMock && (
              <span className="text-xs font-mono font-bold text-emerald-400">
                {latestMock.totalMarks} / {latestMock.maxMarks}
              </span>
            )}
          </div>
          {latestMock ? (
            <div className="space-y-2 text-xs text-slate-300">
              <p className="font-semibold text-slate-100">{latestMock.testTitle}</p>
              <div className="flex items-center justify-between text-slate-400">
                <span>Estimated Percentile: <strong className="text-indigo-400 font-bold">{latestMock.percentileEstimate}%ile</strong></span>
                <span>Completed on {new Date(latestMock.completedAt).toLocaleDateString()}</span>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-400">
              You haven't attempted a full NTA mock exam yet. Take a realistic 3-hour test to gauge your percentile!
            </p>
          )}
          <div className="pt-2">
            <button
              onClick={onLaunchMockTest}
              className="w-full py-2.5 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/30 text-indigo-300 text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <span>Take Full NTA Simulation Test</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const SparkleIcon = () => (
  <svg className="w-3.5 h-3.5 text-indigo-400" viewBox="0 0 24 24" fill="currentColor">
    <path d="M12 2L14.5 9.5L22 12L14.5 14.5L12 22L9.5 14.5L2 12L9.5 9.5L12 2Z" />
  </svg>
);

export default DashboardView;
