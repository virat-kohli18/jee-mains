'use client';

import React, { useState } from 'react';
import { BOARD_SAMPLE_PAPERS } from '@/data/boardData';
import { BoardSamplePaper, BoardQuestion } from '@/types';
import MathRenderer from '@/components/MathRenderer';
import BoardQuestionCard from '@/components/BoardQuestionCard';
import { 
  FileText, 
  Clock, 
  Award, 
  CheckCircle2, 
  ChevronDown, 
  ChevronUp, 
  CheckSquare2, 
  AlertCircle, 
  GraduationCap,
  Layers,
  BookOpen
} from 'lucide-react';

export const BoardSamplePapersView: React.FC = () => {
  const [selectedPaperId, setSelectedPaperId] = useState<string>(BOARD_SAMPLE_PAPERS[0]?.id || 'b-sp-phy-01');
  const [revealedSolutions, setRevealedSolutions] = useState<Record<string, boolean>>({});
  const [revealedMarkings, setRevealedMarkings] = useState<Record<string, boolean>>({});

  const activePaper = BOARD_SAMPLE_PAPERS.find((p) => p.id === selectedPaperId) || BOARD_SAMPLE_PAPERS[0];

  const toggleSolution = (id: string) => {
    setRevealedSolutions((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleMarking = (id: string) => {
    setRevealedMarkings((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/10 border border-teal-500/20 text-teal-400 text-xs font-bold uppercase tracking-wider mb-2">
            <FileText className="w-3.5 h-3.5" />
            Class 12th Board Examination Sample Papers
          </div>
          <h1 className="text-2xl md:text-3xl font-black text-white">
            Official Pattern 3-Hour Descriptive Sample Papers
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            Section A to E structure with full step-wise marking schemes and model solution sheets.
          </p>
        </div>

        {/* Paper Selector Tabs */}
        <div className="flex items-center gap-2 bg-slate-900/90 p-1.5 rounded-2xl border border-slate-800">
          {BOARD_SAMPLE_PAPERS.map((paper) => {
            const isActive = paper.id === activePaper.id;
            return (
              <button
                key={paper.id}
                onClick={() => setSelectedPaperId(paper.id)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer ${
                  isActive
                    ? 'bg-teal-600 text-white shadow-md shadow-teal-600/30'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {paper.subject} ({paper.totalMarks}M)
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Paper Header Banner */}
      <div className="p-6 rounded-3xl bg-slate-900/90 border border-teal-500/30 space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-teal-500/20 text-teal-300 border border-teal-500/40">
                CBSE Official Standard
              </span>
              <span className="text-xs text-slate-400">Time: {activePaper.timeAllowedHours} Hours</span>
            </div>
            <h2 className="text-xl md:text-2xl font-black text-white">
              {activePaper.title}
            </h2>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-4 py-2 rounded-2xl bg-slate-950 border border-slate-800 text-center">
              <span className="text-2xl font-black text-teal-400 font-mono block">
                {activePaper.totalMarks}
              </span>
              <span className="text-[10px] text-slate-400 font-bold uppercase">Max Marks</span>
            </div>
          </div>
        </div>

        {/* General Instructions Card */}
        <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
          <span className="text-xs font-extrabold text-slate-300 uppercase tracking-wider block">
            General Instructions:
          </span>
          <ul className="list-disc list-inside space-y-1 text-xs text-slate-400 leading-relaxed">
            {activePaper.generalInstructions.map((inst, idx) => (
              <li key={idx}>{inst}</li>
            ))}
          </ul>
        </div>
      </div>

      {/* Questions in this Paper */}
      <div className="space-y-6">
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          <Layers className="w-5 h-5 text-teal-400" />
          <span>Paper Questions &amp; Marking Evaluation:</span>
        </h3>

        {activePaper.questions.map((q, idx) => (
          <BoardQuestionCard key={q.id} question={q} questionNumber={idx + 1} />
        ))}
      </div>
    </div>
  );
};

export default BoardSamplePapersView;
