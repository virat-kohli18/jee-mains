'use client';

import React, { useState } from 'react';
import { CLASS_12_BOARD_NOTES } from '@/data/boardData';
import { BoardRevisionNote, SubjectType } from '@/types';
import MathRenderer from '@/components/MathRenderer';
import { 
  BookOpen, 
  Search, 
  Award, 
  CheckCircle2, 
  AlertTriangle, 
  GraduationCap, 
  FileCheck, 
  Sparkles,
  Bookmark
} from 'lucide-react';

export const BoardRevisionNotesView: React.FC = () => {
  const [selectedSubject, setSelectedSubject] = useState<SubjectType | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredNotes = CLASS_12_BOARD_NOTES.filter((note) => {
    const matchesSubject = selectedSubject === 'all' || note.subject === selectedSubject;
    const matchesSearch = note.chapterName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.ncertKeyDefinitions.some(d => d.term.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesSubject && matchesSearch;
  });

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/10 border border-sky-500/20 text-sky-400 text-xs font-bold uppercase tracking-wider mb-2">
            <Bookmark className="w-3.5 h-3.5" />
            Class 12th Board Rapid Revision Notes
          </div>
          <h1 className="text-2xl md:text-3xl font-black text-white">
            NCERT Definitions, Formulas &amp; Step Checklists
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            High-yield textbook definitions, guaranteed board questions, and examiner trap alerts.
          </p>
        </div>

        {/* Counter */}
        <div className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-2xl text-xs font-bold text-slate-300 flex items-center gap-2 shrink-0">
          <Award className="w-4 h-4 text-emerald-400" />
          <span>{filteredNotes.length} Key Chapters Covered</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between bg-slate-900/80 p-3 rounded-2xl border border-slate-800">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          {(['all', 'physics', 'chemistry', 'mathematics'] as const).map((sub) => {
            const isActive = selectedSubject === sub;
            return (
              <button
                key={sub}
                onClick={() => setSelectedSubject(sub)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer ${
                  isActive
                    ? 'bg-sky-600 text-white shadow-md shadow-sky-600/30'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {sub === 'all' ? 'All Subjects' : sub}
              </button>
            );
          })}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search definitions or chapters..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-500"
          />
        </div>
      </div>

      {/* Revision Notes List */}
      <div className="space-y-6">
        {filteredNotes.map((note) => (
          <div
            key={note.chapterId}
            className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-6 shadow-xl"
          >
            {/* Note Card Header */}
            <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <span
                  className={`text-xs font-extrabold uppercase px-2.5 py-1 rounded-full ${
                    note.subject === 'physics'
                      ? 'bg-sky-500/10 text-sky-400 border border-sky-500/30'
                      : note.subject === 'chemistry'
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                      : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                  }`}
                >
                  {note.subject}
                </span>

                <h2 className="text-xl font-black text-white">
                  {note.chapterName}
                </h2>
              </div>

              <div className="px-3.5 py-1 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-xs font-black font-mono">
                {note.marksWeightage} Marks in Board Exam
              </div>
            </div>

            {/* NCERT Key Definitions Grid */}
            <div className="space-y-3">
              <h3 className="text-xs font-extrabold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                NCERT Official Definitions &amp; Laws:
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {note.ncertKeyDefinitions.map((def, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <strong className="text-sm font-bold text-sky-300">
                        {def.term}
                      </strong>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {def.definition}
                    </p>
                    {def.formulaOrLaw && (
                      <div className="pt-1 text-xs text-emerald-400 font-mono">
                        <MathRenderer content={`$${def.formulaOrLaw}$`} />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Guaranteed Questions & Step-Marking Checklist in 2 Columns */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Guaranteed Board Questions */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2.5">
                <span className="text-xs font-extrabold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-emerald-400" />
                  Guaranteed Questions to Practice:
                </span>
                <ul className="space-y-2 text-xs text-slate-300">
                  {note.guaranteedQuestions.map((gq, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <span>{gq}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Step Marking Checklist */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2.5">
                <span className="text-xs font-extrabold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <FileCheck className="w-4 h-4 text-amber-400" />
                  Step-Marking Checklist (Don&apos;t Lose Marks):
                </span>
                <ul className="space-y-2 text-xs text-slate-300">
                  {note.stepMarkingChecklist.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Examiner Trap Alerts */}
            {note.examinerTrapAlerts && note.examinerTrapAlerts.length > 0 && (
              <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 space-y-1.5 text-xs text-rose-200">
                <span className="font-extrabold text-rose-400 uppercase tracking-wider flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4" />
                  Examiner Trap Alerts (Where Students Commonly Lose Marks):
                </span>
                <ul className="list-disc list-inside space-y-1 text-slate-300">
                  {note.examinerTrapAlerts.map((trap, idx) => (
                    <li key={idx}>{trap}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Guru Ji Board Secret */}
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3 text-xs md:text-sm text-amber-200">
              <GraduationCap className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-amber-300 font-bold block mb-0.5 uppercase tracking-wider text-xs">
                  Guru Ji Board Examination Secret:
                </strong>
                <p className="leading-relaxed">
                  &quot;{note.guruJiBoardSecretHinglish}&quot;
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BoardRevisionNotesView;
