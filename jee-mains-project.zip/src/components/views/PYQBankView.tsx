'use client';

import React, { useState, useMemo } from 'react';
import { PYQQuestion, SubjectType, QuestionType, DifficultyLevel } from '@/types';
import { filterPYQQuestions, getAllPYQQuestions } from '@/data/pyqRepository';
import { OFFICIAL_SYLLABUS_CHAPTERS } from '@/data/syllabusData';
import QuestionCard from '../QuestionCard';
import { 
  Database, 
  Search, 
  Filter, 
  RotateCcw, 
  ChevronLeft, 
  ChevronRight,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';

interface PYQBankViewProps {
  initialSubject?: SubjectType | 'all';
}

const PAGE_SIZE = 12;

export const PYQBankView: React.FC<PYQBankViewProps> = ({ initialSubject = 'all' }) => {
  const [selectedSubject, setSelectedSubject] = useState<SubjectType | 'all'>(initialSubject);
  const [selectedChapter, setSelectedChapter] = useState<string>('all');
  const [selectedYear, setSelectedYear] = useState<number | 'all'>('all');
  const [selectedType, setSelectedType] = useState<QuestionType | 'all'>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<DifficultyLevel | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [currentPage, setCurrentPage] = useState<number>(1);

  // Chapters list based on selected subject
  const availableChapters = useMemo(() => {
    if (selectedSubject === 'all') return OFFICIAL_SYLLABUS_CHAPTERS;
    return OFFICIAL_SYLLABUS_CHAPTERS.filter((ch) => ch.subject === selectedSubject);
  }, [selectedSubject]);

  // Filtered Questions
  const filteredQuestions = useMemo(() => {
    return filterPYQQuestions({
      subject: selectedSubject,
      chapterId: selectedChapter,
      year: selectedYear,
      questionType: selectedType,
      difficulty: selectedDifficulty,
      searchQuery,
    });
  }, [selectedSubject, selectedChapter, selectedYear, selectedType, selectedDifficulty, searchQuery]);

  // Pagination slice
  const totalPages = Math.ceil(filteredQuestions.length / PAGE_SIZE) || 1;
  const paginatedQuestions = useMemo(() => {
    const start = (currentPage - 1) * PAGE_SIZE;
    return filteredQuestions.slice(start, start + PAGE_SIZE);
  }, [filteredQuestions, currentPage]);

  const handleResetFilters = () => {
    setSelectedSubject('all');
    setSelectedChapter('all');
    setSelectedYear('all');
    setSelectedType('all');
    setSelectedDifficulty('all');
    setSearchQuery('');
    setCurrentPage(1);
  };

  const handlePageChange = (newPage: number) => {
    setCurrentPage(newPage);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-1">
            <Database className="w-4 h-4" /> 100% Authentic Previous 10 Years Question Bank
          </div>
          <h1 className="text-2xl font-bold text-white">2,000+ Authentic JEE Main PYQs</h1>
          <p className="text-xs md:text-sm text-slate-400">
            Official NTA shift papers (2015–2024). Verified scoring keys with 10-point textbook solutions.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-center">
            <span className="text-[10px] text-slate-500 uppercase font-bold block">In Database</span>
            <strong className="text-emerald-400 text-base">{getAllPYQQuestions().length} Verified Qs</strong>
          </div>
        </div>
      </div>

      {/* Multi-Attribute Filter Panel */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4 shadow-md">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-300">
            <Filter className="w-4 h-4 text-indigo-400" /> Filter & Search Engine
          </div>
          <button
            onClick={handleResetFilters}
            className="text-xs text-slate-400 hover:text-white flex items-center gap-1 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Reset All Filters
          </button>
        </div>

        {/* Filter Controls Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {/* Subject Filter */}
          <div>
            <label className="block text-[11px] uppercase font-bold text-slate-400 mb-1">Subject</label>
            <select
              value={selectedSubject}
              onChange={(e) => {
                setSelectedSubject(e.target.value as any);
                setSelectedChapter('all');
                setCurrentPage(1);
              }}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="all">All Subjects (2,259)</option>
              <option value="physics">Physics (779)</option>
              <option value="chemistry">Chemistry (780)</option>
              <option value="mathematics">Mathematics (700)</option>
            </select>
          </div>

          {/* Chapter Filter */}
          <div className="lg:col-span-2">
            <label className="block text-[11px] uppercase font-bold text-slate-400 mb-1">Chapter</label>
            <select
              value={selectedChapter}
              onChange={(e) => {
                setSelectedChapter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 truncate"
            >
              <option value="all">All Chapters</option>
              {availableChapters.map((ch) => (
                <option key={ch.id} value={ch.id}>
                  {ch.name}
                </option>
              ))}
            </select>
          </div>

          {/* Year Filter */}
          <div>
            <label className="block text-[11px] uppercase font-bold text-slate-400 mb-1">Exam Year</label>
            <select
              value={selectedYear}
              onChange={(e) => {
                setSelectedYear(e.target.value === 'all' ? 'all' : Number(e.target.value));
                setCurrentPage(1);
              }}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="all">All Years (2015-2024)</option>
              {[2024, 2023, 2022, 2021, 2020, 2019, 2018, 2017, 2016, 2015].map((yr) => (
                <option key={yr} value={yr}>
                  JEE Main {yr}
                </option>
              ))}
            </select>
          </div>

          {/* Type Filter */}
          <div>
            <label className="block text-[11px] uppercase font-bold text-slate-400 mb-1">Format</label>
            <select
              value={selectedType}
              onChange={(e) => {
                setSelectedType(e.target.value as any);
                setCurrentPage(1);
              }}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="all">All Types</option>
              <option value="MCQ">Single Correct MCQ</option>
              <option value="NUMERICAL">Numerical / Integer</option>
            </select>
          </div>

          {/* Difficulty Filter */}
          <div>
            <label className="block text-[11px] uppercase font-bold text-slate-400 mb-1">Difficulty</label>
            <select
              value={selectedDifficulty}
              onChange={(e) => {
                setSelectedDifficulty(e.target.value as any);
                setCurrentPage(1);
              }}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="all">All Levels</option>
              <option value="Easy">Easy Level</option>
              <option value="Medium">Medium Level</option>
              <option value="Hard">Hard Level</option>
            </select>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="Search questions by keyword, formula, concept or question code (e.g. PHY-2024)..."
            className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-4 py-2.5 text-xs md:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Results Header */}
      <div className="flex items-center justify-between text-xs text-slate-400">
        <span>
          Showing <strong className="text-white">{filteredQuestions.length}</strong> matching questions (Page{' '}
          <strong className="text-indigo-400">{currentPage}</strong> of{' '}
          <strong className="text-slate-200">{totalPages}</strong>)
        </span>
        <span className="flex items-center gap-1 text-emerald-400 font-medium">
          <ShieldCheck className="w-4 h-4" /> 100% Verified Answer Keys
        </span>
      </div>

      {/* Questions List */}
      {paginatedQuestions.length > 0 ? (
        <div className="space-y-4">
          {paginatedQuestions.map((question) => (
            <QuestionCard key={question.id} question={question} />
          ))}
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-12 text-center space-y-3">
          <p className="text-base text-slate-300">No questions matched your filter criteria.</p>
          <button
            onClick={handleResetFilters}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold"
          >
            Reset Filters
          </button>
        </div>
      )}

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-3 pt-4 pb-8">
          <button
            disabled={currentPage === 1}
            onClick={() => handlePageChange(currentPage - 1)}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" /> Previous
          </button>

          <span className="text-xs text-slate-400">
            Page <strong className="text-white">{currentPage}</strong> of{' '}
            <strong className="text-white">{totalPages}</strong>
          </span>

          <button
            disabled={currentPage === totalPages}
            onClick={() => handlePageChange(currentPage + 1)}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer"
          >
            Next <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};

export default PYQBankView;
