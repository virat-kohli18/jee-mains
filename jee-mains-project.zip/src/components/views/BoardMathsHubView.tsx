'use client';

import React, { useState } from 'react';
import { 
  BOARD_MATH_TRICKS, 
  BOARD_MATH_FORMULAS, 
  CLASS_12_BOARD_QUESTIONS 
} from '@/data/boardData';
import MathRenderer from '@/components/MathRenderer';
import BoardQuestionCard from '@/components/BoardQuestionCard';
import { 
  Calculator, 
  Zap, 
  BookOpen, 
  Layers, 
  Search, 
  CheckCircle2, 
  ChevronDown, 
  ChevronUp, 
  GraduationCap, 
  AlertCircle,
  Clock,
  Award
} from 'lucide-react';
import { BoardQuestionFormat } from '@/types';

export const BoardMathsHubView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'tricks' | 'formulas' | 'questions'>('tricks');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFormat, setSelectedFormat] = useState<BoardQuestionFormat | 'all'>('all');
  
  // Track open state for questions
  const [revealedAnswers, setRevealedAnswers] = useState<Record<string, boolean>>({});
  const [revealedMarkings, setRevealedMarkings] = useState<Record<string, boolean>>({});

  const mathsQuestions = CLASS_12_BOARD_QUESTIONS.filter((q) => q.subject === 'mathematics');

  const filteredQuestions = mathsQuestions.filter((q) => {
    const matchesFormat = selectedFormat === 'all' || q.format === selectedFormat;
    const matchesSearch = q.questionText.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.chapterName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFormat && matchesSearch;
  });

  const toggleAnswer = (id: string) => {
    setRevealedAnswers((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleMarking = (id: string) => {
    setRevealedMarkings((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Header Banner */}
      <div className="p-6 md:p-8 rounded-3xl bg-gradient-to-br from-rose-950/80 via-slate-900 to-slate-950 border border-rose-500/30 shadow-2xl space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-bold uppercase tracking-wider">
          <Calculator className="w-4 h-4 text-rose-400" />
          Class 12th Mathematics &bull; 80 Theory + 20 Internal
        </div>
        <h1 className="text-3xl md:text-4xl font-black text-white">
          Class 12 Mathematics Complete Subject Hub
        </h1>
        <p className="text-slate-300 text-sm md:text-base max-w-2xl leading-relaxed">
          Master every formula across Calculus, Vectors, 3D, and Matrices, examine board speed &amp; verification tricks, 
          and practice 334+ authentic board questions across separate section categories.
        </p>

        {/* 3 Main Internal Navigation Tabs */}
        <div className="pt-2 flex flex-wrap gap-2">
          {[
            { id: 'tricks', label: `Board Exam Tricks (${BOARD_MATH_TRICKS.length})`, icon: <Zap className="w-4 h-4" /> },
            { id: 'formulas', label: `All Formulas (${BOARD_MATH_FORMULAS.length})`, icon: <BookOpen className="w-4 h-4" /> },
            { id: 'questions', label: `334+ Board Questions`, icon: <Layers className="w-4 h-4" /> },
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 rounded-2xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer ${
                  isActive
                    ? 'bg-rose-500 text-slate-950 shadow-lg shadow-rose-500/30'
                    : 'bg-slate-900 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ================= MATHS TRICKS SECTION ================= */}
      {activeTab === 'tricks' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-rose-400" />
              <span>Board Exam Speed, Verification &amp; Shortcut Tricks</span>
            </h2>
            <span className="text-xs text-rose-400 font-bold bg-rose-500/10 px-3 py-1 rounded-full border border-rose-500/20">
              Save 25+ Minutes in Exam Hall
            </span>
          </div>

          <div className="space-y-6">
            {BOARD_MATH_TRICKS.map((trick, idx) => (
              <div
                key={trick.id}
                className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-5 shadow-xl hover:border-rose-500/40 transition-all"
              >
                {/* Header */}
                <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-lg bg-rose-500/20 text-rose-300 flex items-center justify-center text-xs font-bold font-mono">
                        #{idx + 1}
                      </span>
                      <span className="text-xs font-bold text-rose-400">
                        {trick.chapterName}
                      </span>
                    </div>
                    <h3 className="text-xl font-black text-white">
                      {trick.trickTitle}
                    </h3>
                  </div>

                  {/* Timing Comparison */}
                  <div className="flex items-center gap-2">
                    <div className="px-3 py-1 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-slate-500" />
                      <span>Standard: {trick.standardMethodTime}</span>
                    </div>
                    <div className="px-3 py-1 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-xs text-emerald-300 font-bold flex items-center gap-1.5 font-mono">
                      <Zap className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Shortcut: {trick.shortcutTime}</span>
                    </div>
                  </div>
                </div>

                {/* Concept and How It Works */}
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 text-xs md:text-sm text-slate-200">
                  <strong className="text-rose-400 block uppercase tracking-wider text-xs">
                    How The Trick Works:
                  </strong>
                  <p className="leading-relaxed">{trick.howItWorks}</p>
                </div>

                {/* Formula or Rule Box */}
                <div className="p-4 rounded-2xl bg-rose-950/20 border border-rose-500/30 text-center my-2 text-rose-300 font-mono">
                  <MathRenderer content={`$$${trick.formulaOrRule}$$`} />
                </div>

                {/* Worked Exemplar Comparison */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5">
                    <strong className="text-slate-400 uppercase tracking-wider block">Standard Method:</strong>
                    <p className="text-slate-300 leading-relaxed">{trick.exampleProblem.standardMethod}</p>
                  </div>
                  <div className="p-3.5 rounded-2xl bg-emerald-950/20 border border-emerald-500/30 space-y-1.5">
                    <strong className="text-emerald-400 uppercase tracking-wider block">Shortcut Verification:</strong>
                    <p className="text-emerald-200 leading-relaxed font-semibold">{trick.exampleProblem.shortcutVerification}</p>
                  </div>
                </div>

                {/* Caution Alert */}
                <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-2 text-xs text-amber-200">
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-amber-400 font-bold block mb-0.5">Board Examination Caution:</strong>
                    {trick.boardExamCaution}
                  </div>
                </div>

                {/* Guru Ji Advice */}
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-start gap-3 text-xs text-slate-300">
                  <GraduationCap className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white font-bold block mb-0.5">Guru Ji Mentorship Advice:</strong>
                    &quot;{trick.guruMantraHinglish}&quot;
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= MATHS FORMULAS SECTION ================= */}
      {activeTab === 'formulas' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-rose-400" />
              <span>Complete Class 12 Mathematics Formula Book</span>
            </h2>
            <span className="text-xs text-rose-400 font-bold bg-rose-500/10 px-3 py-1 rounded-full border border-rose-500/20">
              Calculus, Vectors, 3D, Matrices
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {BOARD_MATH_FORMULAS.map((f) => (
              <div
                key={f.id}
                className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-4 shadow-xl hover:border-slate-700 transition-all flex flex-col justify-between"
              >
                <div className="space-y-2">
                  <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/30">
                    {f.chapterName}
                  </span>
                  <h3 className="text-base font-bold text-white">
                    {f.title}
                  </h3>

                  {/* Formula Box */}
                  <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-center my-3 text-rose-300">
                    <MathRenderer content={`$$${f.formulaLatex}$$`} />
                  </div>

                  {/* Symbols & Meanings */}
                  <div className="space-y-1 text-xs">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                      Symbols &amp; Meanings:
                    </span>
                    {f.symbolMeanings.map((sym, sIdx) => (
                      <div key={sIdx} className="flex justify-between py-0.5 text-slate-300 border-b border-slate-950">
                        <strong className="text-rose-400 font-mono">{sym.symbol}</strong>
                        <span>{sym.meaning}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800 space-y-1.5 text-xs text-slate-400">
                  <div className="flex justify-between">
                    <span>Units:</span>
                    <strong className="text-emerald-400 font-mono">{f.siUnit}</strong>
                  </div>
                  <div className="text-[11px] text-slate-400 italic">
                    Conditions: {f.conditions}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= QUESTIONS SECTION WITH SEPARATE FORMAT SECTIONS ================= */}
      {activeTab === 'questions' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/80 p-3 rounded-2xl border border-slate-800">
            {/* Format Filter */}
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mr-1">Section:</span>
              {[
                { id: 'all', label: 'All' },
                { id: 'MCQ', label: 'Sec A: MCQ (1M)' },
                { id: 'ASSERTION_REASON', label: 'Sec A: A-R (1M)' },
                { id: 'VSA', label: 'Sec B: VSA (2M)' },
                { id: 'SA', label: 'Sec C: SA (3M)' },
                { id: 'CASE_BASED', label: 'Sec D: Case (4M)' },
                { id: 'LA', label: 'Sec E: LA (5M)' },
              ].map((fmt) => (
                <button
                  key={fmt.id}
                  onClick={() => setSelectedFormat(fmt.id as any)}
                  className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    selectedFormat === fmt.id
                      ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30'
                      : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  {fmt.label}
                </button>
              ))}
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search maths questions..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
              />
            </div>
          </div>

          <div className="space-y-4">
            {filteredQuestions.slice(0, 30).map((q, idx) => (
              <BoardQuestionCard key={q.id} question={q} questionNumber={idx + 1} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default BoardMathsHubView;
