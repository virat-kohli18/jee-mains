'use client';

import React from 'react';
import { 
  CLASS_12_BOARD_CHAPTERS, 
  BOARD_DERIVATIONS_DIRECTORY, 
  CLASS_12_BOARD_QUESTIONS,
  BOARD_SAMPLE_PAPERS 
} from '@/data/boardData';
import { BoardNavTab } from '@/types';
import { 
  GraduationCap, 
  Award, 
  BookOpen, 
  FileCheck, 
  CheckCircle2, 
  ArrowRight, 
  Zap, 
  Layers,
  FileText
} from 'lucide-react';

interface BoardDashboardViewProps {
  onNavigate: (tab: BoardNavTab) => void;
}

export const BoardDashboardView: React.FC<BoardDashboardViewProps> = ({ onNavigate }) => {
  // Target 12th Board Exam date: Feb 15, 2027
  const boardExamDate = new Date('2027-02-15T10:30:00+05:30');
  const today = new Date();
  const diffDays = Math.max(0, Math.ceil((boardExamDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)));

  const derivationsCount = BOARD_DERIVATIONS_DIRECTORY.length;
  const samplePapersCount = BOARD_SAMPLE_PAPERS.length;

  return (
    <div className="space-y-8 animate-fadeIn pb-12">
      {/* Top Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-950/80 via-slate-900 to-slate-950 border border-emerald-500/30 p-6 md:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 -mt-12 -mr-12 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold uppercase tracking-wider">
              <GraduationCap className="w-4 h-4 text-emerald-400" />
              Class 12th Board Preparation (CBSE & State Boards)
            </div>
            <h1 className="text-3xl md:text-4xl font-black text-white tracking-tight">
              Target <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-300">95%+ in 12th Boards</span>
            </h1>
            <p className="text-slate-300 text-sm md:text-base max-w-2xl leading-relaxed">
              Step-wise marking schemes, model topper answers, high-yield derivations directory, 
              and authentic board questions across Physics (70M), Chemistry (70M), and Mathematics (80M).
            </p>
          </div>

          {/* Countdown & Quick Stats */}
          <div className="flex flex-row md:flex-col gap-3 shrink-0">
            <div className="bg-slate-900/90 border border-emerald-500/30 rounded-2xl p-4 text-center min-w-[140px] shadow-lg">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Board Exams Target
              </span>
              <div className="text-3xl font-black text-emerald-400 font-mono mt-1">
                {diffDays}
              </div>
              <span className="text-xs text-slate-400 font-medium">Days Remaining</span>
            </div>
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 text-center min-w-[140px]">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Target Score
              </span>
              <div className="text-2xl font-black text-white mt-1">
                98% / 100
              </div>
              <span className="text-xs text-emerald-400 font-medium">Topper Benchmark</span>
            </div>
          </div>
        </div>
      </div>

      {/* Guru Ji Kota Educator Board Mentorship Box */}
      <div className="p-5 md:p-6 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-200">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center shrink-0">
            <GraduationCap className="w-6 h-6 text-amber-400" />
          </div>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 font-bold text-xs uppercase tracking-wider">
                Guru Ji Board Secret Mantra
              </span>
              <span className="text-xs text-amber-300/80">Step-Marking Psychology</span>
            </div>
            <p className="text-sm text-slate-200 leading-relaxed">
              &quot;Beta, dhyan se suno: JEE Main mein sirf final answer dekha jaata hai, lekin <strong>12th Board Exam mein examiner har ek step ke number deta hai!</strong> Agar Ray Optics ke diagram mein arrow lagana bhool gaye, toh bina sochey 1 mark kat jaata hai. Agar chemistry ke distinction test mein observable color ya gas change nahi likha, toh 1/2 mark cut hoga. Is platform par har question ke sath <strong>Step-wise Marking Scheme</strong> aur <strong>Model Topper Answer</strong> diya hai — isko dhyan se dekho aur practice karo!&quot;
            </p>
          </div>
        </div>
      </div>

      {/* 4 Feature Highlights Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <button
          onClick={() => onNavigate('board_derivations')}
          className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-emerald-500/50 hover:bg-slate-900 transition-all text-left group cursor-pointer"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 mb-3 group-hover:scale-110 transition-transform">
            <Zap className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white group-hover:text-emerald-400 transition-colors">
            Must-Do Derivations
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Lens Maker, Huygens, LCR phasor, Matrix method &mdash; guaranteed 5-markers.
          </p>
          <div className="mt-3 flex items-center gap-1 text-xs text-emerald-400 font-bold">
            <span>{derivationsCount} Core Derivations</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </button>

        <button
          onClick={() => onNavigate('board_questions')}
          className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-indigo-500/50 hover:bg-slate-900 transition-all text-left group cursor-pointer"
        >
          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 mb-3 group-hover:scale-110 transition-transform">
            <Layers className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white group-hover:text-indigo-400 transition-colors">
            1M to 5M Question Bank
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            MCQs, Assertion-Reason, VSA, SA, Case Studies & LA with step-marking.
          </p>
          <div className="mt-3 flex items-center gap-1 text-xs text-indigo-400 font-bold">
            <span>Explore Questions</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </button>

        <button
          onClick={() => onNavigate('board_notes')}
          className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-sky-500/50 hover:bg-slate-900 transition-all text-left group cursor-pointer"
        >
          <div className="w-10 h-10 rounded-xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400 mb-3 group-hover:scale-110 transition-transform">
            <BookOpen className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white group-hover:text-sky-400 transition-colors">
            NCERT Revision Notes
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Key definitions, formula sheets, diagram checklists, and frequent traps.
          </p>
          <div className="mt-3 flex items-center gap-1 text-xs text-sky-400 font-bold">
            <span>Read Chapter Notes</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </button>

        <button
          onClick={() => onNavigate('board_papers')}
          className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-teal-500/50 hover:bg-slate-900 transition-all text-left group cursor-pointer"
        >
          <div className="w-10 h-10 rounded-xl bg-teal-500/10 border border-teal-500/20 flex items-center justify-center text-teal-400 mb-3 group-hover:scale-110 transition-transform">
            <FileText className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white group-hover:text-teal-400 transition-colors">
            Board Sample Papers
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Official 3-hour exam format with full marking scheme & answer keys.
          </p>
          <div className="mt-3 flex items-center gap-1 text-xs text-teal-400 font-bold">
            <span>{samplePapersCount} Official Papers</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </button>
      </div>

      {/* Subject Marks Blueprint (CBSE Pattern) */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-6">
        <h2 className="text-xl font-bold text-white flex items-center gap-2 mb-4">
          <Award className="w-5 h-5 text-emerald-400" />
          Class 12th Board Examination Pattern & Marks Weightage
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Physics */}
          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-extrabold text-sky-400 uppercase tracking-wider">Physics</span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-sky-500/10 text-sky-400 border border-sky-500/20">
                70 Theory + 30 Practicals
              </span>
            </div>
            <div className="space-y-2 text-xs text-slate-300">
              <div className="flex justify-between py-1 border-b border-slate-900">
                <span>Optics (Ray & Wave):</span>
                <strong className="text-white">14 Marks</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-900">
                <span>EMI & Alternating Current:</span>
                <strong className="text-white">9 Marks</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-900">
                <span>Electrostatics & Potential:</span>
                <strong className="text-white">12 Marks</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-900">
                <span>Current Electricity:</span>
                <strong className="text-white">7 Marks</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-900">
                <span>Semiconductor Electronics:</span>
                <strong className="text-white">8 Marks</strong>
              </div>
            </div>
            <button
              onClick={() => onNavigate('board_physics')}
              className="w-full py-2.5 bg-sky-600/20 hover:bg-sky-600 text-sky-300 hover:text-white border border-sky-500/30 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5"
            >
              <span>Explore Physics Hub (Derivations & Formulas)</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Chemistry */}
          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-extrabold text-emerald-400 uppercase tracking-wider">Chemistry</span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                70 Theory + 30 Practicals
              </span>
            </div>
            <div className="space-y-2 text-xs text-slate-300">
              <div className="flex justify-between py-1 border-b border-slate-900">
                <span>Electrochemistry:</span>
                <strong className="text-white">9 Marks</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-900">
                <span>Aldehydes, Ketones & Acids:</span>
                <strong className="text-white">8 Marks</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-900">
                <span>Solutions:</span>
                <strong className="text-white">7 Marks</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-900">
                <span>Chemical Kinetics:</span>
                <strong className="text-white">7 Marks</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-900">
                <span>Coordination Compounds:</span>
                <strong className="text-white">7 Marks</strong>
              </div>
            </div>
            <button
              onClick={() => onNavigate('board_chemistry')}
              className="w-full py-2.5 bg-emerald-600/20 hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/30 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5"
            >
              <span>Explore Chemistry Hub (Reactions & Reagents)</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Mathematics */}
          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-extrabold text-rose-400 uppercase tracking-wider">Mathematics</span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-500/10 text-rose-400 border border-rose-500/20">
                80 Theory + 20 Internal
              </span>
            </div>
            <div className="space-y-2 text-xs text-slate-300">
              <div className="flex justify-between py-1 border-b border-slate-900">
                <span>Calculus (Total):</span>
                <strong className="text-white">35 Marks</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-900">
                <span>Vectors & 3D Geometry:</span>
                <strong className="text-white">14 Marks</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-900">
                <span>Matrices & Determinants:</span>
                <strong className="text-white">10 Marks</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-900">
                <span>Relations & Functions + ITF:</span>
                <strong className="text-white">8 Marks</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-900">
                <span>Probability:</span>
                <strong className="text-white">8 Marks</strong>
              </div>
            </div>
            <button
              onClick={() => onNavigate('board_maths')}
              className="w-full py-2.5 bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/30 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5"
            >
              <span>Explore Maths Hub (Tricks & Formulas)</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Board Presentation Golden Rules by Guru Ji */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-6">
        <h2 className="text-xl font-bold text-white flex items-center gap-2 mb-4">
          <FileCheck className="w-5 h-5 text-amber-400" />
          Topper&apos;s Presentation Rulebook (Avoid Step Marks Deduction)
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs md:text-sm text-slate-300">
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/80 space-y-2">
            <div className="flex items-center gap-2 text-amber-400 font-bold">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Ray & Wave Optics Diagrams:</span>
            </div>
            <p className="text-slate-400 pl-6">
              Arrows on rays are compulsory! A ray diagram without arrows indicating the direction of light will be awarded 0 marks by CBSE evaluators. Always label normal, angles i and r.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/80 space-y-2">
            <div className="flex items-center gap-2 text-amber-400 font-bold">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Matrix Inverse Method (5M):</span>
            </div>
            <p className="text-slate-400 pl-6">
              Write all 9 cofactors C11 through C33 step-by-step. Transpose the cofactor matrix to get adj(A). After solving, substitute x, y, z into Equation 1 to guarantee 100% full marks.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/80 space-y-2">
            <div className="flex items-center gap-2 text-amber-400 font-bold">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Organic Chemistry Distinction Tests:</span>
            </div>
            <p className="text-slate-400 pl-6">
              State the reagent name, the exact observable reaction (e.g. &quot;formation of silver mirror&quot;, &quot;brisk effervescence of CO2&quot;), and the balanced chemical equation.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/80 space-y-2">
            <div className="flex items-center gap-2 text-amber-400 font-bold">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>SI Units & Significant Figures:</span>
            </div>
            <p className="text-slate-400 pl-6">
              Every numerical answer in Physics and Physical Chemistry MUST have correct SI units (e.g., m/s, V, J/mol). Omitting units leads to 0.5 mark deduction per question.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BoardDashboardView;
