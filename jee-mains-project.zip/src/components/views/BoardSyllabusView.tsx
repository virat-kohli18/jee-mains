'use client';

import React, { useState } from 'react';
import { CLASS_12_BOARD_CHAPTERS, BoardChapterInfo } from '@/data/boardData';
import { SubjectType } from '@/types';
import { 
  BookOpen, 
  Search, 
  Award, 
  Sparkles, 
  CheckCircle2, 
  ChevronRight, 
  AlertCircle,
  FileCheck2,
  GraduationCap
} from 'lucide-react';

export const BoardSyllabusView: React.FC = () => {
  const [selectedSubject, setSelectedSubject] = useState<SubjectType | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedChapter, setSelectedChapter] = useState<BoardChapterInfo | null>(CLASS_12_BOARD_CHAPTERS[0]);

  const filteredChapters = CLASS_12_BOARD_CHAPTERS.filter((chap) => {
    const matchesSubject = selectedSubject === 'all' || chap.subject === selectedSubject;
    const matchesSearch = chap.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      chap.frequentQuestionTypes.some(t => t.toLowerCase().includes(searchQuery.toLowerCase())) ||
      chap.keyDerivationsOrMechanisms.some(d => d.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesSubject && matchesSearch;
  });

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold uppercase tracking-wider mb-2">
            <BookOpen className="w-3.5 h-3.5" />
            Class 12th Board Examination Syllabus
          </div>
          <h1 className="text-2xl md:text-3xl font-black text-white">
            NCERT Class 12 Syllabus & Marks Weightage
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            Official chapter-wise theory marks distribution, must-do derivations, and examiner guidelines.
          </p>
        </div>

        {/* Total Marks Pill */}
        <div className="flex items-center gap-2 px-4 py-2 bg-slate-900 border border-slate-800 rounded-2xl text-xs font-bold text-slate-300">
          <Award className="w-4 h-4 text-emerald-400" />
          <span>Physics (70M) &bull; Chemistry (70M) &bull; Maths (80M)</span>
        </div>
      </div>

      {/* Subject Filter Bar & Search */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="flex items-center gap-2 bg-slate-900/90 p-1.5 rounded-2xl border border-slate-800 w-full sm:w-auto">
          {(['all', 'physics', 'chemistry', 'mathematics'] as const).map((sub) => {
            const isActive = selectedSubject === sub;
            return (
              <button
                key={sub}
                onClick={() => setSelectedSubject(sub)}
                className={`px-4 py-1.5 rounded-xl text-xs font-bold capitalize transition-all cursor-pointer ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {sub === 'all' ? 'All Subjects' : sub}
              </button>
            );
          })}
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search chapters or derivations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-900/90 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
        </div>
      </div>

      {/* Main Grid: Chapter List & Detail Drawer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Chapter List Column */}
        <div className="lg:col-span-5 space-y-3 max-h-[750px] overflow-y-auto pr-1">
          {filteredChapters.map((chap) => {
            const isSelected = selectedChapter?.id === chap.id;
            return (
              <div
                key={chap.id}
                onClick={() => setSelectedChapter(chap)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-emerald-950/40 border-emerald-500/80 shadow-lg shadow-emerald-950/50'
                    : 'bg-slate-900/70 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full ${
                          chap.subject === 'physics'
                            ? 'bg-sky-500/10 text-sky-400 border border-sky-500/30'
                            : chap.subject === 'chemistry'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                        }`}
                      >
                        {chap.subject}
                      </span>
                      <span className="text-[11px] text-slate-500 font-medium">
                        {chap.ncertPart}
                      </span>
                    </div>
                    <h3 className="text-sm font-bold text-white leading-snug">
                      {chap.name}
                    </h3>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-base font-black text-emerald-400 font-mono">
                      {chap.boardMarksWeightage}
                    </span>
                    <span className="text-[10px] text-slate-500 block uppercase">Marks</span>
                  </div>
                </div>

                <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                  <span className="text-[11px] text-slate-500 truncate max-w-[200px]">
                    {chap.keyDerivationsOrMechanisms[0] || 'High Yield NCERT'}
                  </span>
                  <div className="flex items-center gap-1 text-emerald-400 text-xs font-semibold">
                    <span>Details</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Chapter Comprehensive Detail Pane */}
        <div className="lg:col-span-7">
          {selectedChapter ? (
            <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 space-y-6 sticky top-20">
              {/* Header */}
              <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-800">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span
                      className={`text-xs font-extrabold uppercase px-2.5 py-0.5 rounded-full ${
                        selectedChapter.subject === 'physics'
                          ? 'bg-sky-500/10 text-sky-400 border border-sky-500/30'
                          : selectedChapter.subject === 'chemistry'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                          : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                      }`}
                    >
                      {selectedChapter.subject}
                    </span>
                    <span className="text-xs text-slate-400 font-medium">
                      {selectedChapter.ncertPart}
                    </span>
                  </div>
                  <h2 className="text-xl md:text-2xl font-black text-white">
                    {selectedChapter.name}
                  </h2>
                </div>

                <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-2xl px-4 py-2.5 text-center shrink-0">
                  <span className="text-2xl font-black text-emerald-400 font-mono block">
                    {selectedChapter.boardMarksWeightage}
                  </span>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    Total Marks
                  </span>
                </div>
              </div>

              {/* High Yield Derivations & Mechanisms */}
              <div className="space-y-3">
                <h3 className="text-sm font-extrabold text-white flex items-center gap-2 uppercase tracking-wider">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  Must-Master Derivations & Mechanisms (3M & 5M)
                </h3>
                <div className="space-y-2">
                  {selectedChapter.keyDerivationsOrMechanisms.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 flex items-start gap-3"
                    >
                      <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                        {idx + 1}
                      </div>
                      <span className="text-xs text-slate-200 font-medium leading-relaxed">
                        {item}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Frequent Question Formats */}
              <div className="space-y-3">
                <h3 className="text-sm font-extrabold text-white flex items-center gap-2 uppercase tracking-wider">
                  <FileCheck2 className="w-4 h-4 text-sky-400" />
                  Frequent Board Exam Question Formats
                </h3>
                <div className="flex flex-wrap gap-2">
                  {selectedChapter.frequentQuestionTypes.map((qType, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-semibold text-slate-300 flex items-center gap-1.5"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      {qType}
                    </span>
                  ))}
                </div>
              </div>

              {/* Examiner Tips & Warning */}
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-2">
                <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider">
                  <AlertCircle className="w-4 h-4" />
                  Official Board Examiner Warning & Presentation Tip
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {selectedChapter.boardExamTips}
                </p>
              </div>

              {/* Guru Ji Note */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-start gap-3 text-xs text-slate-300">
                <GraduationCap className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white block mb-0.5">Guru Ji Mentorship Tip:</strong>
                  &quot;Beta, is chapter ke numericals solve karte waqt standard NCERT solved examples ko kam se kam do baar haath se likh kar solve karo. Board paper mein 70% numericals direct NCERT se aate hain!&quot;
                </div>
              </div>
            </div>
          ) : (
            <div className="h-64 flex items-center justify-center bg-slate-900/40 rounded-3xl border border-slate-800 text-slate-500 text-sm">
              Select a chapter to inspect syllabus details.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BoardSyllabusView;
