'use client';

import React, { useState } from 'react';
import { CHAPTER_WEIGHTAGE_DATA } from '@/data/weightageAndAnalysisData';
import WeightageChart from '../WeightageChart';
import { SubjectType } from '@/types';
import { 
  BarChart2, 
  TrendingUp, 
  Award, 
  AlertCircle, 
  ArrowUpRight, 
  ArrowDownRight, 
  Minus 
} from 'lucide-react';

export const WeightageView: React.FC = () => {
  const [selectedSubject, setSelectedSubject] = useState<SubjectType | 'all'>('all');

  const filteredChapters =
    selectedSubject === 'all'
      ? CHAPTER_WEIGHTAGE_DATA
      : CHAPTER_WEIGHTAGE_DATA.filter((c) => c.subject === selectedSubject);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-1">
          <BarChart2 className="w-4 h-4" /> 10-Year Empirical Examination Analysis
        </div>
        <h1 className="text-2xl font-bold text-white">Chapter-Wise Weightage & Priority Matrix</h1>
        <p className="text-xs md:text-sm text-slate-400 mt-1">
          Analyzed across ~150+ official JEE Main shift papers (2015-2024). Classifies every chapter into{' '}
          <strong className="text-rose-400">HIGH</strong>, <strong className="text-amber-400">MEDIUM</strong>, and{' '}
          <strong className="text-emerald-400">LOWER</strong> priority with empirical question frequencies and recent trends.
        </p>
      </div>

      {/* Subject Filter Bar */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
        {(['all', 'physics', 'chemistry', 'mathematics'] as (SubjectType | 'all')[]).map((subj) => {
          const isActive = selectedSubject === subj;
          const label =
            subj === 'all'
              ? 'All Subjects'
              : subj === 'physics'
              ? 'Physics'
              : subj === 'chemistry'
              ? 'Chemistry'
              : 'Mathematics';

          return (
            <button
              key={subj}
              onClick={() => setSelectedSubject(subj)}
              className={`px-4 py-2 rounded-xl text-xs md:text-sm font-semibold transition-all cursor-pointer ${
                isActive
                  ? 'bg-indigo-600 text-white shadow'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
              }`}
            >
              {label}
            </button>
          );
        })}
      </div>

      {/* Interactive Recharts Component */}
      <WeightageChart selectedSubject={selectedSubject} />

      {/* Chapter Priority Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">
            Detailed Chapter Frequency Breakdown
          </h3>
          <span className="text-xs text-slate-400">Accounting for shifted patterns & recent syllabus trims</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Priority</th>
                <th className="py-3 px-4">Chapter Name</th>
                <th className="py-3 px-4">Subject</th>
                <th className="py-3 px-4 text-center">Avg Qs / Paper</th>
                <th className="py-3 px-4 text-center">Hist. Weightage</th>
                <th className="py-3 px-4 text-center">Avg Marks</th>
                <th className="py-3 px-4 text-center">Recent Trend</th>
                <th className="py-3 px-4">Strategic Takeaway</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredChapters.map((ch) => {
                const priorityBadge =
                  ch.priority === 'HIGH'
                    ? 'bg-rose-500/10 border border-rose-500/30 text-rose-400'
                    : ch.priority === 'MEDIUM'
                    ? 'bg-amber-500/10 border border-amber-500/30 text-amber-400'
                    : 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400';

                return (
                  <tr key={ch.chapterId} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3.5 px-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${priorityBadge}`}>
                        {ch.priority}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-white">{ch.chapterName}</td>
                    <td className="py-3.5 px-4 uppercase text-[10px] font-medium text-slate-400">
                      {ch.subject}
                    </td>
                    <td className="py-3.5 px-4 text-center font-mono font-bold text-indigo-400 text-sm">
                      {ch.avgQuestionsPerPaper}
                    </td>
                    <td className="py-3.5 px-4 text-center font-mono font-bold text-emerald-400">
                      {ch.weightagePercent}%
                    </td>
                    <td className="py-3.5 px-4 text-center font-mono font-bold text-amber-400">
                      {ch.historicalMarksContribution}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      {ch.trend2024 === 'increasing' ? (
                        <span className="inline-flex items-center gap-1 text-emerald-400 font-semibold text-[11px]">
                          <ArrowUpRight className="w-3.5 h-3.5" /> Rising
                        </span>
                      ) : ch.trend2024 === 'decreasing' ? (
                        <span className="inline-flex items-center gap-1 text-rose-400 font-semibold text-[11px]">
                          <ArrowDownRight className="w-3.5 h-3.5" /> Lower
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-slate-400 font-semibold text-[11px]">
                          <Minus className="w-3.5 h-3.5" /> Stable
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-slate-400 max-w-xs">{ch.examTakeaway}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default WeightageView;
