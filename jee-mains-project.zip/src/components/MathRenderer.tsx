'use client';

import React, { useMemo } from 'react';
import katex from 'katex';

interface MathRendererProps {
  content: string;
  className?: string;
  inline?: boolean;
}

export const MathRenderer: React.FC<MathRendererProps> = ({ content, className = '', inline = false }) => {
  const renderedHtml = useMemo(() => {
    if (!content) return '';

    try {
      // Split by display math $$...$$ and inline math $...$
      // We parse tokens sequentially
      const parts: { type: 'text' | 'inline' | 'display'; text: string }[] = [];
      let cursor = 0;
      const len = content.length;

      while (cursor < len) {
        // Look for display math $$
        const nextDisplay = content.indexOf('$$', cursor);
        const nextInline = content.indexOf('$', cursor);

        if (nextDisplay !== -1 && (nextInline === -1 || nextDisplay <= nextInline)) {
          // Check if there is text before $$
          if (nextDisplay > cursor) {
            parts.push({ type: 'text', text: content.slice(cursor, nextDisplay) });
          }
          const endDisplay = content.indexOf('$$', nextDisplay + 2);
          if (endDisplay !== -1) {
            parts.push({
              type: 'display',
              text: content.slice(nextDisplay + 2, endDisplay),
            });
            cursor = endDisplay + 2;
          } else {
            // unmatched $$, treat rest as text
            parts.push({ type: 'text', text: content.slice(nextDisplay) });
            break;
          }
        } else if (nextInline !== -1) {
          // Check if there is text before $
          if (nextInline > cursor) {
            parts.push({ type: 'text', text: content.slice(cursor, nextInline) });
          }
          const endInline = content.indexOf('$', nextInline + 1);
          if (endInline !== -1) {
            parts.push({
              type: 'inline',
              text: content.slice(nextInline + 1, endInline),
            });
            cursor = endInline + 1;
          } else {
            // unmatched $, treat rest as text
            parts.push({ type: 'text', text: content.slice(nextInline) });
            break;
          }
        } else {
          parts.push({ type: 'text', text: content.slice(cursor) });
          break;
        }
      }

      // Convert parts to HTML
      return parts
        .map((part) => {
          if (part.type === 'text') {
            // Convert linebreaks to <br/> safely
            return part.text.replace(/\n/g, '<br/>');
          }
          try {
            return katex.renderToString(part.text, {
              displayMode: part.type === 'display',
              throwOnError: false,
              output: 'html',
            });
          } catch {
            return `<code>${part.text}</code>`;
          }
        })
        .join('');
    } catch {
      return content;
    }
  }, [content]);

  return (
    <span
      className={`math-rendered ${className} ${inline ? 'inline-block' : 'block'}`}
      dangerouslySetInnerHTML={{ __html: renderedHtml }}
    />
  );
};

export default MathRenderer;
