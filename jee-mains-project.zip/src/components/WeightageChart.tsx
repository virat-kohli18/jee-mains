'use client';

import React, { useState } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie,
} from 'recharts';
import { CHAPTER_WEIGHTAGE_DATA } from '@/data/weightageAndAnalysisData';
import { SubjectType } from '@/types';

interface WeightageChartProps {
  selectedSubject?: SubjectType | 'all';
}

export const WeightageChart: React.FC<WeightageChartProps> = ({ selectedSubject = 'all' }) => {
  const [activeTab, setActiveTab] = useState<'bar' | 'pie'>('bar');

  const filteredData =
    selectedSubject === 'all'
      ? CHAPTER_WEIGHTAGE_DATA
      : CHAPTER_WEIGHTAGE_DATA.filter((d) => d.subject === selectedSubject);

  const barData = filteredData.map((d) => ({
    name: d.chapterName.length > 20 ? d.chapterName.slice(0, 18) + '...' : d.chapterName,
    fullName: d.chapterName,
    avgQuestions: d.avgQuestionsPerPaper,
    weightage: d.weightagePercent,
    marks: d.historicalMarksContribution,
    priority: d.priority,
    subject: d.subject,
  }));

  // Pie distribution of priority
  const highCount = filteredData.filter((d) => d.priority === 'HIGH').length;
  const medCount = filteredData.filter((d) => d.priority === 'MEDIUM').length;
  const lowCount = filteredData.filter((d) => d.priority === 'LOWER').length;

  const pieData = [
    { name: 'High Priority', value: highCount, color: '#f43f5e' },
    { name: 'Medium Priority', value: medCount, color: '#eab308' },
    { name: 'Lower Priority', value: lowCount, color: '#10b981' },
  ];

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-lg">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-5 border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-base font-bold text-white">Historical 10-Year Weightage & Question Frequency</h3>
          <p className="text-xs text-slate-400">Based on empirical NTA shift data (2015-2024)</p>
        </div>
        <div className="flex items-center gap-2 bg-slate-950 p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => setActiveTab('bar')}
            className={`px-3 py-1 rounded-md text-xs font-semibold transition-all ${
              activeTab === 'bar' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            Avg Qs / Paper
          </button>
          <button
            onClick={() => setActiveTab('pie')}
            className={`px-3 py-1 rounded-md text-xs font-semibold transition-all ${
              activeTab === 'pie' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            Priority Split
          </button>
        </div>
      </div>

      {activeTab === 'bar' ? (
        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={barData} margin={{ top: 10, right: 10, left: -20, bottom: 25 }}>
              <XAxis
                dataKey="name"
                stroke="#64748b"
                fontSize={11}
                tickLine={false}
                angle={-25}
                textAnchor="end"
              />
              <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="bg-slate-950 border border-slate-700 p-3 rounded-lg shadow-xl text-xs space-y-1">
                        <p className="font-bold text-white">{data.fullName}</p>
                        <p className="text-slate-300">
                          Avg Questions: <strong className="text-indigo-400">{data.avgQuestions}</strong> / paper
                        </p>
                        <p className="text-slate-300">
                          Weightage: <strong className="text-emerald-400">{data.weightage}%</strong>
                        </p>
                        <p className="text-slate-300">
                          Historical Marks: <strong className="text-amber-400">{data.marks}</strong> marks
                        </p>
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold mt-1 ${
                            data.priority === 'HIGH'
                              ? 'bg-rose-500/20 text-rose-400'
                              : data.priority === 'MEDIUM'
                              ? 'bg-amber-500/20 text-amber-400'
                              : 'bg-emerald-500/20 text-emerald-400'
                          }`}
                        >
                          {data.priority} PRIORITY
                        </span>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Bar dataKey="avgQuestions" radius={[6, 6, 0, 0]}>
                {barData.map((entry, index) => {
                  const color =
                    entry.priority === 'HIGH'
                      ? '#f43f5e'
                      : entry.priority === 'MEDIUM'
                      ? '#eab308'
                      : '#10b981';
                  return <Cell key={`cell-${index}`} fill={color} />;
                })}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      ) : (
        <div className="h-72 w-full flex items-center justify-center">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={95}
                paddingAngle={5}
                dataKey="value"
                label={({ name, percent }: { name?: string; percent?: number }) =>
                  `${name || ''}: ${((percent || 0) * 100).toFixed(0)}%`
                }
              >
                {pieData.map((entry, index) => (
                  <Cell key={`pie-cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Legend footer */}
      <div className="flex items-center justify-center gap-6 text-xs text-slate-400 pt-3 border-t border-slate-800/80">
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-rose-500" /> High Priority (Do Not Skip)
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-amber-500" /> Medium Priority
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-emerald-500" /> Lower Priority
        </div>
      </div>
    </div>
  );
};

export default WeightageChart;
