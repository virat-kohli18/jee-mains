'use client';

import React, { useState, useEffect, useRef } from 'react';
import { PYQQuestion, SubjectType, PaletteStatus, MockTestResult, ErrorTag } from '@/types';
import MathRenderer from './MathRenderer';
import { 
  Clock, 
  AlertCircle, 
  CheckCircle, 
  XCircle, 
  RotateCcw, 
  Award, 
  BarChart3, 
  HelpCircle,
  ShieldCheck,
  ChevronRight,
  ChevronLeft,
  GraduationCap
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { saveMockResult, recordQuestionAttempt } from '@/utils/studentStore';
import GuruMentorBox from './GuruMentorBox';

interface MockTestSimulatorProps {
  testTitle: string;
  durationSeconds?: number;
  questions: PYQQuestion[];
  onExitTest: () => void;
}

export const MockTestSimulator: React.FC<MockTestSimulatorProps> = ({
  testTitle,
  durationSeconds = 180 * 60, // 3 hours
  questions,
  onExitTest,
}) => {
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [activeSubject, setActiveSubject] = useState<SubjectType>('physics');
  const [activeSection, setActiveSection] = useState<'A' | 'B'>('A');
  const [timeRemaining, setTimeRemaining] = useState<number>(durationSeconds);
  const [isTestSubmitted, setIsTestSubmitted] = useState<boolean>(false);
  const [showSubmitModal, setShowSubmitModal] = useState<boolean>(false);
  const [testResult, setTestResult] = useState<MockTestResult | null>(null);

  // User responses: questionId -> answer string
  const [userAnswers, setUserAnswers] = useState<Record<string, string>>({});
  // Question statuses: questionId -> PaletteStatus
  const [paletteStatuses, setPaletteStatuses] = useState<Record<string, PaletteStatus>>({});
  // Time spent per question: questionId -> seconds
  const [timeSpent, setTimeSpent] = useState<Record<string, number>>({});

  // Input for current numerical question
  const [numericalInput, setNumericalInput] = useState<string>('');

  const currentQ = questions[currentIdx];

  // Initialize statuses
  useEffect(() => {
    const initialStatuses: Record<string, PaletteStatus> = {};
    questions.forEach((q, idx) => {
      initialStatuses[q.id] = idx === 0 ? 'NOT_ANSWERED' : 'NOT_VISITED';
    });
    setPaletteStatuses(initialStatuses);
  }, [questions]);

  // Timer countdown
  useEffect(() => {
    if (isTestSubmitted) return;
    const interval = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          handleAutoSubmit();
          return 0;
        }
        return prev - 1;
      });

      // Track time spent on current question
      if (currentQ) {
        setTimeSpent((prev) => ({
          ...prev,
          [currentQ.id]: (prev[currentQ.id] || 0) + 1,
        }));
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isTestSubmitted, currentQ]);

  // Sync numerical input when switching questions
  useEffect(() => {
    if (currentQ) {
      if (currentQ.questionType === 'NUMERICAL') {
        setNumericalInput(userAnswers[currentQ.id] || '');
      }
      setActiveSubject(currentQ.subject);
    }
  }, [currentIdx, currentQ, userAnswers]);

  const handleSelectOption = (optKey: string) => {
    if (isTestSubmitted) return;
    setUserAnswers((prev) => ({ ...prev, [currentQ.id]: optKey }));
  };

  const handleSaveAndNext = () => {
    if (currentQ.questionType === 'NUMERICAL') {
      if (numericalInput.trim()) {
        setUserAnswers((prev) => ({ ...prev, [currentQ.id]: numericalInput.trim() }));
        setPaletteStatuses((prev) => ({ ...prev, [currentQ.id]: 'ANSWERED' }));
      } else {
        setPaletteStatuses((prev) => ({ ...prev, [currentQ.id]: 'NOT_ANSWERED' }));
      }
    } else {
      if (userAnswers[currentQ.id]) {
        setPaletteStatuses((prev) => ({ ...prev, [currentQ.id]: 'ANSWERED' }));
      } else {
        setPaletteStatuses((prev) => ({ ...prev, [currentQ.id]: 'NOT_ANSWERED' }));
      }
    }

    goToNextQuestion();
  };

  const handleSaveAndMarkForReview = () => {
    if (currentQ.questionType === 'NUMERICAL') {
      if (numericalInput.trim()) {
        setUserAnswers((prev) => ({ ...prev, [currentQ.id]: numericalInput.trim() }));
        setPaletteStatuses((prev) => ({ ...prev, [currentQ.id]: 'ANSWERED_AND_MARKED_FOR_REVIEW' }));
      } else {
        setPaletteStatuses((prev) => ({ ...prev, [currentQ.id]: 'MARKED_FOR_REVIEW' }));
      }
    } else {
      if (userAnswers[currentQ.id]) {
        setPaletteStatuses((prev) => ({ ...prev, [currentQ.id]: 'ANSWERED_AND_MARKED_FOR_REVIEW' }));
      } else {
        setPaletteStatuses((prev) => ({ ...prev, [currentQ.id]: 'MARKED_FOR_REVIEW' }));
      }
    }

    goToNextQuestion();
  };

  const handleMarkForReviewAndNext = () => {
    setPaletteStatuses((prev) => ({
      ...prev,
      [currentQ.id]: userAnswers[currentQ.id] ? 'ANSWERED_AND_MARKED_FOR_REVIEW' : 'MARKED_FOR_REVIEW',
    }));
    goToNextQuestion();
  };

  const handleClearResponse = () => {
    setUserAnswers((prev) => {
      const copy = { ...prev };
      delete copy[currentQ.id];
      return copy;
    });
    setNumericalInput('');
    setPaletteStatuses((prev) => ({ ...prev, [currentQ.id]: 'NOT_ANSWERED' }));
  };

  const goToNextQuestion = () => {
    if (currentIdx < questions.length - 1) {
      const nextIdx = currentIdx + 1;
      setCurrentIdx(nextIdx);
      const nextQ = questions[nextIdx];
      if (paletteStatuses[nextQ.id] === 'NOT_VISITED') {
        setPaletteStatuses((prev) => ({ ...prev, [nextQ.id]: 'NOT_ANSWERED' }));
      }
    }
  };

  const handleJumpToQuestion = (targetIdx: number) => {
    setCurrentIdx(targetIdx);
    const targetQ = questions[targetIdx];
    if (paletteStatuses[targetQ.id] === 'NOT_VISITED') {
      setPaletteStatuses((prev) => ({ ...prev, [targetQ.id]: 'NOT_ANSWERED' }));
    }
  };

  // Calculation of final score and percentile
  const calculateResult = (): MockTestResult => {
    let totalMarks = 0;
    const maxMarks = questions.length * 4;

    const subjectStats: Record<SubjectType, {
      score: number;
      correctCount: number;
      incorrectCount: number;
      unattemptedCount: number;
      timeSpent: number;
    }> = {
      physics: { score: 0, correctCount: 0, incorrectCount: 0, unattemptedCount: 0, timeSpent: 0 },
      chemistry: { score: 0, correctCount: 0, incorrectCount: 0, unattemptedCount: 0, timeSpent: 0 },
      mathematics: { score: 0, correctCount: 0, incorrectCount: 0, unattemptedCount: 0, timeSpent: 0 },
    };

    questions.forEach((q) => {
      const sub = q.subject;
      const ans = userAnswers[q.id];
      const spent = timeSpent[q.id] || 0;
      subjectStats[sub].timeSpent += spent;

      if (!ans) {
        subjectStats[sub].unattemptedCount += 1;
      } else {
        let isCorrect = false;
        if (q.questionType === 'MCQ') {
          isCorrect = ans.toUpperCase() === q.correctAnswer.toUpperCase();
        } else {
          const userNum = parseFloat(ans);
          const correctNum = parseFloat(q.correctAnswer);
          isCorrect = !isNaN(userNum) && Math.abs(userNum - correctNum) <= 0.05;
        }

        if (isCorrect) {
          totalMarks += 4;
          subjectStats[sub].score += 4;
          subjectStats[sub].correctCount += 1;
          recordQuestionAttempt(q, ans, true);
        } else {
          totalMarks -= 1;
          subjectStats[sub].score -= 1;
          subjectStats[sub].incorrectCount += 1;
          recordQuestionAttempt(q, ans, false, 'conceptual');
        }
      }
    });

    // Estimate Percentile based on empirical JEE Main cutoff distribution
    let percentile = 50.0;
    const scorePct = (totalMarks / maxMarks) * 100;
    if (totalMarks >= 250) percentile = 99.85;
    else if (totalMarks >= 210) percentile = 99.20;
    else if (totalMarks >= 180) percentile = 98.40;
    else if (totalMarks >= 150) percentile = 96.80;
    else if (totalMarks >= 120) percentile = 93.50;
    else if (totalMarks >= 90) percentile = 88.00;
    else if (totalMarks >= 60) percentile = 78.00;
    else percentile = Math.max(20, Math.min(65, 30 + scorePct * 0.8));

    const result: MockTestResult = {
      id: `res-${Date.now()}`,
      testTitle,
      completedAt: new Date().toISOString(),
      timeSpentSeconds: durationSeconds - timeRemaining,
      totalMarks,
      maxMarks,
      percentileEstimate: Number(percentile.toFixed(2)),
      subjectScores: (['physics', 'chemistry', 'mathematics'] as SubjectType[]).map((s) => {
        const stats = subjectStats[s];
        const attempted = stats.correctCount + stats.incorrectCount;
        const accuracy = attempted > 0 ? (stats.correctCount / attempted) * 100 : 0;
        return {
          subject: s,
          score: stats.score,
          maxScore: 100,
          correctCount: stats.correctCount,
          incorrectCount: stats.incorrectCount,
          unattemptedCount: stats.unattemptedCount,
          accuracyPercent: Number(accuracy.toFixed(1)),
          timeSpentSeconds: stats.timeSpent,
        };
      }),
      attempts: {},
    };

    saveMockResult(result);
    return result;
  };

  const handleFinishSubmit = () => {
    setShowSubmitModal(false);
    const res = calculateResult();
    setTestResult(res);
    setIsTestSubmitted(true);

    if (res.totalMarks >= 160) {
      try {
        confetti({
          particleCount: 120,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {}
    }
  };

  const handleAutoSubmit = () => {
    setShowSubmitModal(false);
    const res = calculateResult();
    setTestResult(res);
    setIsTestSubmitted(true);
  };

  // Format seconds to HH:MM:SS
  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Group questions by subject
  const physicsQuestions = questions.filter((q) => q.subject === 'physics');
  const chemQuestions = questions.filter((q) => q.subject === 'chemistry');
  const mathQuestions = questions.filter((q) => q.subject === 'mathematics');

  const currentSubjectQuestions =
    activeSubject === 'physics'
      ? physicsQuestions
      : activeSubject === 'chemistry'
      ? chemQuestions
      : mathQuestions;

  // Counts for palette
  const answeredCount = Object.values(paletteStatuses).filter((s) => s === 'ANSWERED').length;
  const notAnsweredCount = Object.values(paletteStatuses).filter((s) => s === 'NOT_ANSWERED').length;
  const notVisitedCount = Object.values(paletteStatuses).filter((s) => s === 'NOT_VISITED').length;
  const markedReviewCount = Object.values(paletteStatuses).filter((s) => s === 'MARKED_FOR_REVIEW').length;
  const ansAndMarkedCount = Object.values(paletteStatuses).filter(
    (s) => s === 'ANSWERED_AND_MARKED_FOR_REVIEW'
  ).length;

  // ===================== RESULT VIEW =====================
  if (isTestSubmitted && testResult) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-8">
        <div className="max-w-5xl mx-auto space-y-8">
          {/* Top Banner */}
          <div className="bg-gradient-to-r from-indigo-900/60 to-slate-900 border border-indigo-500/30 rounded-2xl p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl">
            <div>
              <div className="flex items-center gap-2 text-indigo-400 text-xs font-semibold uppercase tracking-widest mb-1">
                <Award className="w-4 h-4" /> Official NTA Simulation Result
              </div>
              <h1 className="text-2xl md:text-3xl font-bold text-white mb-2">{testResult.testTitle}</h1>
              <p className="text-sm text-slate-400">
                Completed on {new Date(testResult.completedAt).toLocaleString()} &bull; Total Time:{' '}
                {formatTime(testResult.timeSpentSeconds)}
              </p>
            </div>

            <div className="flex items-center gap-6 bg-slate-900/90 border border-slate-800 p-4 rounded-xl">
              <div className="text-center">
                <span className="text-xs text-slate-400 uppercase font-semibold block">Total Score</span>
                <span className="text-3xl font-extrabold text-emerald-400">
                  {testResult.totalMarks}{' '}
                  <span className="text-sm text-slate-500 font-normal">/ {testResult.maxMarks}</span>
                </span>
              </div>
              <div className="w-px h-10 bg-slate-800" />
              <div className="text-center">
                <span className="text-xs text-slate-400 uppercase font-semibold block">Est. Percentile</span>
                <span className="text-3xl font-extrabold text-indigo-400">
                  {testResult.percentileEstimate}%ile
                </span>
              </div>
            </div>
          </div>

          {/* Kota Guru Ji Hinglish Performance Review */}
          <div className="bg-gradient-to-r from-amber-950/30 via-slate-900 to-indigo-950/30 border border-amber-500/30 rounded-2xl p-5 shadow-lg flex items-start gap-4">
            <div className="w-11 h-11 rounded-full bg-amber-500 flex items-center justify-center shrink-0 text-slate-950 shadow-md">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                  Guru Ji's Hinglish Mentorship
                </span>
                <span className="text-[10px] px-2 py-0.2 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                  Sir ka Personalized Feedback 👨‍🏫
                </span>
              </div>
              <p className="text-xs md:text-sm text-slate-200 leading-relaxed font-medium">
                {testResult.totalMarks >= 200
                  ? "Shabash mere sher/sherni! 👏 200+ score matlab tum top NITs (Trichy, Surathkal, Warangal) ke Computer Science/Circuital branches ki race mein bilkul aage ho! Bas negative marking ko thoda aur control kar lo, 99.5+ percentile pakka hai!"
                  : testResult.totalMarks >= 130
                  ? "Bahut badiya koshish hai beta! 🤝 Tumara base strong hai, lekin dekho jahan -1 hua hai wahan mostly silly calculation ya question misread karne ki wajah se marks kate hain. Agar wo 4-5 negative bach jaate toh tumara score aasaani se 170+ pahunch jaata!"
                  : "Ghabrana bilkul nahi hai beta! Main hu na tumhare sath! 🤝 Mock test ka matlab hi yahi hota hai ki main exam se pehle saari galtiyan yahan ho jayein. Har galat question ko neeche dekho, sir ne solution mein trick explain ki hai, use seekho aur Error Notebook mein lock karo!"}
              </p>
            </div>
          </div>

          {/* Subject-Wise Performance Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {testResult.subjectScores.map((scoreObj) => {
              const subColor =
                scoreObj.subject === 'physics'
                  ? 'border-sky-500/30 text-sky-400'
                  : scoreObj.subject === 'chemistry'
                  ? 'border-emerald-500/30 text-emerald-400'
                  : 'border-pink-500/30 text-pink-400';

              return (
                <div key={scoreObj.subject} className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <h3 className={`text-sm uppercase tracking-wider font-bold ${subColor}`}>
                      {scoreObj.subject}
                    </h3>
                    <span className="text-lg font-extrabold text-slate-100">
                      {scoreObj.score} <span className="text-xs text-slate-500">/ 100</span>
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center text-xs">
                    <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                      <span className="text-emerald-400 font-bold block text-sm">+{scoreObj.correctCount}</span>
                      <span className="text-slate-400">Correct</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                      <span className="text-rose-400 font-bold block text-sm">-{scoreObj.incorrectCount}</span>
                      <span className="text-slate-400">Wrong</span>
                    </div>
                    <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                      <span className="text-slate-400 font-bold block text-sm">{scoreObj.unattemptedCount}</span>
                      <span className="text-slate-500">Left</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800/60">
                    <span>Accuracy: <strong className="text-slate-200">{scoreObj.accuracyPercent}%</strong></span>
                    <span>Time: <strong className="text-slate-200">{formatTime(scoreObj.timeSpentSeconds)}</strong></span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Question Review Section with Detailed Solutions */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
            <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" /> Complete Question Review & Solutions
            </h2>
            <div className="space-y-4">
              {questions.map((q, idx) => {
                const userAns = userAnswers[q.id];
                let isRight = false;
                if (userAns) {
                  if (q.questionType === 'MCQ') {
                    isRight = userAns.toUpperCase() === q.correctAnswer.toUpperCase();
                  } else {
                    const userNum = parseFloat(userAns);
                    const correctNum = parseFloat(q.correctAnswer);
                    isRight = !isNaN(userNum) && Math.abs(userNum - correctNum) <= 0.05;
                  }
                }

                return (
                  <div key={q.id} className="p-4 rounded-xl border border-slate-800 bg-slate-950/60">
                    <div className="flex items-center justify-between gap-2 mb-2 flex-wrap text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-slate-300">Q.{idx + 1}</span>
                        <span className="uppercase text-slate-400 px-2 py-0.5 rounded bg-slate-800">
                          {q.subject}
                        </span>
                        <span className="text-slate-400">{q.chapterName}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {!userAns ? (
                          <span className="text-slate-500 font-medium">Unattempted (0 Marks)</span>
                        ) : isRight ? (
                          <span className="text-emerald-400 font-bold flex items-center gap-1">
                            <CheckCircle className="w-3.5 h-3.5" /> Correct (+4)
                          </span>
                        ) : (
                          <span className="text-rose-400 font-bold flex items-center gap-1">
                            <XCircle className="w-3.5 h-3.5" /> Incorrect (-1) &bull; Auto-saved to Error Notebook
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="text-sm text-slate-200 mb-3">
                      <MathRenderer content={q.questionText} />
                    </div>

                    <div className="text-xs flex items-center gap-4 text-slate-400 mb-3 bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                      <span>Your Answer: <strong className={isRight ? 'text-emerald-400' : userAns ? 'text-rose-400' : 'text-slate-500'}>{userAns || 'None'}</strong></span>
                      <span>Official Answer: <strong className="text-emerald-400">{q.correctAnswer}</strong></span>
                    </div>

                    {/* Quick Solution Accordion */}
                    <details className="text-xs text-slate-300 bg-slate-900/40 p-3 rounded-lg border border-slate-800/80 cursor-pointer">
                      <summary className="font-semibold text-indigo-400 hover:text-indigo-300">
                        View Textbook Solution & Concept Tested
                      </summary>
                      <div className="mt-3 space-y-2 pt-2 border-t border-slate-800">
                        <p><strong>Concept:</strong> {q.solution.conceptTested}</p>
                        <p><strong>Formula:</strong> <MathRenderer content={q.solution.formulaRequired} inline /></p>
                        <ol className="list-decimal list-inside space-y-1">
                          {q.solution.stepByStep.map((s, sIdx) => (
                            <li key={sIdx}><MathRenderer content={s} inline /></li>
                          ))}
                        </ol>
                        <p className="text-amber-300"><strong>Shortcut:</strong> {q.solution.shortApproach}</p>
                      </div>
                    </details>

                    {/* Guru Ji Hinglish Teacher Mentorship */}
                    <GuruMentorBox
                      question={q}
                      isCorrect={isRight}
                      userAnswer={userAns}
                      errorTag={isRight ? undefined : 'conceptual'}
                    />
                  </div>
                );
              })}
            </div>
          </div>

          <div className="flex justify-center pb-8">
            <button
              onClick={onExitTest}
              className="px-8 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-xl text-sm transition-all"
            >
              Exit Mock Test & Return to Dashboard
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ===================== TEST IN-PROGRESS INTERFACE =====================
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans select-none">
      {/* Top NTA Exam Header */}
      <header className="bg-slate-900 border-b border-slate-800 px-4 py-3 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center font-bold text-white text-sm shadow">
            NTA
          </div>
          <div>
            <h1 className="text-sm md:text-base font-bold text-white leading-tight">{testTitle}</h1>
            <span className="text-xs text-slate-400">JEE MAIN (PAPER 1: B.E./B.Tech) - Computer Based Test Simulation</span>
          </div>
        </div>

        {/* 3-Hour Countdown Timer */}
        <div className="flex items-center gap-4">
          <div
            className={`flex items-center gap-2 px-4 py-2 rounded-xl border font-mono font-bold text-base md:text-lg ${
              timeRemaining < 600
                ? 'bg-rose-500/20 border-rose-500 text-rose-400 animate-pulse'
                : timeRemaining < 1800
                ? 'bg-amber-500/20 border-amber-500 text-amber-400'
                : 'bg-emerald-500/10 border-emerald-500/40 text-emerald-400'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>{formatTime(timeRemaining)}</span>
          </div>

          <button
            onClick={() => setShowSubmitModal(true)}
            className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs md:text-sm rounded-lg transition-all"
          >
            Submit Test
          </button>
        </div>
      </header>

      {/* Subject & Section Bar */}
      <div className="bg-slate-900/60 border-b border-slate-800 px-4 py-2 flex items-center justify-between gap-3 overflow-x-auto">
        <div className="flex items-center gap-2">
          {(['physics', 'chemistry', 'mathematics'] as SubjectType[]).map((subj) => {
            const isActive = activeSubject === subj;
            const label = subj === 'physics' ? 'Physics' : subj === 'chemistry' ? 'Chemistry' : 'Mathematics';
            return (
              <button
                key={subj}
                onClick={() => {
                  setActiveSubject(subj);
                  // jump to first question of this subject
                  const firstSubjIdx = questions.findIndex((q) => q.subject === subj);
                  if (firstSubjIdx >= 0) handleJumpToQuestion(firstSubjIdx);
                }}
                className={`px-4 py-1.5 rounded-lg text-xs md:text-sm font-semibold transition-all ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {label}
              </button>
            );
          })}
        </div>

        {/* Section A (MCQs) & Section B (Numericals) */}
        <div className="flex items-center gap-2 text-xs font-semibold">
          <span className="text-slate-400 hidden sm:inline">Section:</span>
          <span className="px-2.5 py-1 rounded bg-slate-800 border border-slate-700 text-slate-200">
            {currentQ?.questionType === 'MCQ' ? 'Section A (MCQs)' : 'Section B (Numericals)'}
          </span>
          <span className="px-2 py-1 rounded bg-emerald-950/80 border border-emerald-700/50 text-emerald-400">
            +4 / -1 Marking
          </span>
        </div>
      </div>

      {/* Main Body: Left Question Pane & Right Palette */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Left: Question Content & Action Buttons */}
        <div className="flex-1 flex flex-col border-b lg:border-b-0 lg:border-r border-slate-800 p-4 md:p-6 overflow-y-auto">
          {/* Question Header */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
            <div className="flex items-center gap-3">
              <span className="text-base font-bold text-white">
                Question No. {currentIdx + 1}
              </span>
              <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-indigo-300 border border-slate-700">
                {currentQ?.questionType}
              </span>
              <span className="text-xs text-slate-400 hidden sm:inline">
                {currentQ?.chapterName}
              </span>
            </div>
            <div className="text-xs text-slate-400">
              Marks: <span className="text-emerald-400 font-bold">+4</span> |{' '}
              <span className="text-rose-400 font-bold">-1</span>
            </div>
          </div>

          {/* Question Text */}
          <div className="text-base md:text-lg text-slate-100 leading-relaxed mb-6 flex-1">
            {currentQ && <MathRenderer content={currentQ.questionText} />}
          </div>

          {/* Answer Area */}
          <div className="mb-6">
            {currentQ?.questionType === 'MCQ' && currentQ.options && (() => {
              const options = currentQ.options;
              return (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {(['A', 'B', 'C', 'D'] as const).map((optKey) => {
                    const isChecked = userAnswers[currentQ.id] === optKey;
                    return (
                      <label
                        key={optKey}
                        onClick={() => handleSelectOption(optKey)}
                        className={`flex items-start gap-3 p-3.5 rounded-xl border text-sm cursor-pointer transition-all ${
                          isChecked
                            ? 'border-indigo-500 bg-indigo-500/20 text-white ring-1 ring-indigo-500'
                            : 'border-slate-800 bg-slate-900/60 hover:bg-slate-800/80 text-slate-300'
                        }`}
                      >
                        <input
                          type="radio"
                          name={`q-${currentQ.id}`}
                          checked={isChecked}
                          onChange={() => handleSelectOption(optKey)}
                          className="mt-1 text-indigo-600 focus:ring-0"
                        />
                        <span className="font-bold text-slate-200">({optKey})</span>
                        <div className="flex-1">
                          <MathRenderer content={options[optKey]} inline />
                        </div>
                      </label>
                    );
                  })}
                </div>
              );
            })()}

            {currentQ?.questionType === 'NUMERICAL' && (
              <div className="max-w-md bg-slate-900 p-4 rounded-xl border border-slate-800">
                <label className="block text-xs uppercase tracking-wider text-slate-400 mb-2 font-bold">
                  Enter Numerical Value (Section B):
                </label>
                <input
                  type="text"
                  value={numericalInput}
                  onChange={(e) => setNumericalInput(e.target.value)}
                  placeholder="Enter integer or decimal value"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-lg font-mono text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            )}
          </div>

          {/* Bottom Action Bar */}
          <div className="border-t border-slate-800 pt-4 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={handleSaveAndNext}
                className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg text-xs md:text-sm transition-all"
              >
                Save & Next
              </button>
              <button
                onClick={handleSaveAndMarkForReview}
                className="px-4 py-2.5 bg-purple-700 hover:bg-purple-600 text-white font-semibold rounded-lg text-xs md:text-sm transition-all"
              >
                Save & Mark for Review
              </button>
              <button
                onClick={handleClearResponse}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-lg text-xs md:text-sm transition-all"
              >
                Clear Response
              </button>
              <button
                onClick={handleMarkForReviewAndNext}
                className="px-4 py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-semibold rounded-lg text-xs md:text-sm transition-all"
              >
                Mark for Review & Next
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                disabled={currentIdx === 0}
                onClick={() => setCurrentIdx((p) => Math.max(0, p - 1))}
                className="p-2.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-300 rounded-lg text-xs transition-all"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                disabled={currentIdx === questions.length - 1}
                onClick={goToNextQuestion}
                className="p-2.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-300 rounded-lg text-xs transition-all"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Right: Question Palette & Legend */}
        <div className="w-full lg:w-80 bg-slate-900/90 p-4 flex flex-col overflow-y-auto">
          {/* NTA Palette Legend */}
          <div className="grid grid-cols-2 gap-2 text-xs mb-4 pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded bg-emerald-600 flex items-center justify-center font-bold text-white text-xs">
                {answeredCount}
              </span>
              <span className="text-slate-300">Answered</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded bg-rose-600 flex items-center justify-center font-bold text-white text-xs">
                {notAnsweredCount}
              </span>
              <span className="text-slate-300">Not Answered</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded bg-slate-700 flex items-center justify-center font-bold text-white text-xs">
                {notVisitedCount}
              </span>
              <span className="text-slate-300">Not Visited</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded bg-purple-700 flex items-center justify-center font-bold text-white text-xs">
                {markedReviewCount}
              </span>
              <span className="text-slate-300">Marked Review</span>
            </div>
            <div className="col-span-2 flex items-center gap-2 pt-1">
              <span className="w-6 h-6 rounded bg-purple-700 relative flex items-center justify-center font-bold text-white text-xs">
                <span className="w-2 h-2 rounded-full bg-emerald-400 absolute bottom-0.5 right-0.5" />
                {ansAndMarkedCount}
              </span>
              <span className="text-slate-300 text-xs">Answered & Marked Review</span>
            </div>
          </div>

          {/* Palette Questions Grid */}
          <div className="flex-1">
            <span className="text-xs uppercase font-bold text-slate-400 block mb-2 tracking-wider">
              {activeSubject} Questions:
            </span>
            <div className="grid grid-cols-5 gap-2">
              {currentSubjectQuestions.map((q) => {
                const qGlobalIdx = questions.findIndex((item) => item.id === q.id);
                const status = paletteStatuses[q.id] || 'NOT_VISITED';
                const isSelected = currentIdx === qGlobalIdx;

                let btnColor = 'bg-slate-700 text-slate-300';
                if (status === 'ANSWERED') btnColor = 'bg-emerald-600 text-white font-bold';
                else if (status === 'NOT_ANSWERED') btnColor = 'bg-rose-600 text-white font-bold';
                else if (status === 'MARKED_FOR_REVIEW') btnColor = 'bg-purple-700 text-white font-bold';
                else if (status === 'ANSWERED_AND_MARKED_FOR_REVIEW')
                  btnColor = 'bg-purple-700 text-white font-bold ring-2 ring-emerald-400';

                return (
                  <button
                    key={q.id}
                    onClick={() => handleJumpToQuestion(qGlobalIdx)}
                    className={`h-9 rounded-lg text-xs font-semibold flex items-center justify-center transition-all ${btnColor} ${
                      isSelected ? 'ring-2 ring-white scale-105' : ''
                    }`}
                  >
                    {qGlobalIdx + 1}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Confirmation Modal Before Test Submission */}
      {showSubmitModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 shadow-2xl">
            <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-amber-400" /> Confirm Test Submission
            </h2>
            <p className="text-sm text-slate-300 mb-4">
              Are you sure you want to finish this mock test? Once submitted, your score and detailed analysis will be computed.
            </p>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 text-xs mb-5">
              <div className="flex justify-between">
                <span className="text-slate-400">Total Questions:</span>
                <span className="font-bold text-slate-100">{questions.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-emerald-400">Answered:</span>
                <span className="font-bold text-emerald-400">{answeredCount + ansAndMarkedCount}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-rose-400">Unanswered / Left:</span>
                <span className="font-bold text-rose-400">{notAnsweredCount + notVisitedCount}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-purple-400">Marked for Review:</span>
                <span className="font-bold text-purple-400">{markedReviewCount}</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3">
              <button
                onClick={() => setShowSubmitModal(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-lg text-xs transition-all"
              >
                Resume Test
              </button>
              <button
                onClick={handleFinishSubmit}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-500 text-white font-semibold rounded-lg text-xs transition-all shadow-lg"
              >
                Yes, Submit Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MockTestSimulator;
