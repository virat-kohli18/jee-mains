'use client';

import React, { useState } from 'react';
import { PYQQuestion, ErrorTag } from '@/types';
import MathRenderer from './MathRenderer';
import { 
  CheckCircle, 
  XCircle, 
  Bookmark, 
  ChevronDown, 
  ChevronUp, 
  Sparkles, 
  AlertTriangle, 
  Zap, 
  BookOpen, 
  HelpCircle,
  Tag
} from 'lucide-react';
import { recordQuestionAttempt, toggleBookmark } from '@/utils/studentStore';
import GuruMentorBox from './GuruMentorBox';
import { GraduationCap } from 'lucide-react';

interface QuestionCardProps {
  question: PYQQuestion;
  initialBookmarked?: boolean;
  onAttempted?: (isCorrect: boolean) => void;
}

export const QuestionCard: React.FC<QuestionCardProps> = ({
  question,
  initialBookmarked = false,
  onAttempted,
}) => {
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [numericalInput, setNumericalInput] = useState<string>('');
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [isBookmarked, setIsBookmarked] = useState<boolean>(initialBookmarked);
  const [showSolution, setShowSolution] = useState<boolean>(false);
  const [errorTag, setErrorTag] = useState<ErrorTag>('conceptual');
  const [errorSaved, setErrorSaved] = useState<boolean>(false);

  const isMcq = question.questionType === 'MCQ';

  const handleSubmit = (chosenAnswer: string) => {
    if (submitted) return;

    let correct = false;
    if (isMcq) {
      setSelectedOption(chosenAnswer);
      correct = chosenAnswer.toUpperCase() === question.correctAnswer.toUpperCase();
    } else {
      const userVal = parseFloat(numericalInput.trim());
      const correctVal = parseFloat(question.correctAnswer.trim());
      correct = !isNaN(userVal) && Math.abs(userVal - correctVal) <= 0.05;
    }

    setSubmitted(true);
    setIsCorrect(correct);

    recordQuestionAttempt(question, chosenAnswer, correct, errorTag);
    if (onAttempted) onAttempted(correct);
  };

  const handleBookmarkToggle = () => {
    const updated = toggleBookmark(question.id);
    setIsBookmarked(updated);
  };

  const handleSaveErrorCategory = (tag: ErrorTag) => {
    setErrorTag(tag);
    recordQuestionAttempt(question, selectedOption || numericalInput, false, tag);
    setErrorSaved(true);
    setTimeout(() => setErrorSaved(false), 2000);
  };

  // Color theme by subject
  const subjectColor =
    question.subject === 'physics'
      ? 'border-sky-500/30 text-sky-400 bg-sky-500/10'
      : question.subject === 'chemistry'
      ? 'border-emerald-500/30 text-emerald-400 bg-emerald-500/10'
      : 'border-pink-500/30 text-pink-400 bg-pink-500/10';

  const difficultyColor =
    question.difficulty === 'Easy'
      ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20'
      : question.difficulty === 'Medium'
      ? 'text-amber-400 bg-amber-500/10 border-amber-500/20'
      : 'text-rose-400 bg-rose-500/10 border-rose-500/20';

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 md:p-6 mb-5 shadow-lg transition-all duration-200 hover:border-slate-700">
      {/* Top Meta Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-4 pb-3 border-b border-slate-800/80">
        <div className="flex flex-wrap items-center gap-2">
          {/* Question ID */}
          <span className="font-mono text-xs px-2.5 py-1 rounded-md bg-slate-800 text-slate-300 font-semibold">
            {question.id}
          </span>

          {/* Subject Badge */}
          <span className={`text-xs px-2.5 py-1 rounded-md border font-medium uppercase tracking-wider ${subjectColor}`}>
            {question.subject}
          </span>

          {/* Type Badge */}
          <span className="text-xs px-2.5 py-1 rounded-md bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 font-medium">
            {question.questionType}
          </span>

          {/* Difficulty Badge */}
          <span className={`text-xs px-2.5 py-1 rounded-md border font-medium ${difficultyColor}`}>
            {question.difficulty}
          </span>

          {/* Verified Official Tag */}
          <span className="text-xs px-2.5 py-1 rounded-md bg-emerald-950/60 border border-emerald-600/40 text-emerald-300 flex items-center gap-1 font-medium">
            <CheckCircle className="w-3 h-3 text-emerald-400" /> Verified PYQ
          </span>
        </div>

        {/* Action Buttons: Source Reference & Bookmark */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 hidden sm:inline-block font-medium">
            {question.officialSource}
          </span>
          <button
            onClick={handleBookmarkToggle}
            className={`p-2 rounded-lg border transition-all ${
              isBookmarked
                ? 'bg-amber-500/20 border-amber-500/50 text-amber-400'
                : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:text-amber-300'
            }`}
            title={isBookmarked ? 'Bookmarked' : 'Add to Starred Questions'}
          >
            <Bookmark className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Chapter & Topic Breadcrumb */}
      <div className="text-xs text-slate-400 mb-3 flex items-center gap-2 flex-wrap">
        <span className="text-slate-300 font-medium">{question.chapterName}</span>
        <span className="text-slate-600">&bull;</span>
        <span className="text-indigo-400">{question.topicName}</span>
        <span className="text-slate-600">&bull;</span>
        <span className="text-slate-400">
          JEE Main {question.year} ({question.session} - {question.shift})
        </span>
      </div>

      {/* Question Text with KaTeX */}
      <div className="text-slate-100 text-base md:text-lg leading-relaxed mb-6 font-normal">
        <MathRenderer content={question.questionText} />
      </div>

      {/* Answer Options for MCQ */}
      {isMcq && question.options && (() => {
        const options = question.options;
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-6">
            {(['A', 'B', 'C', 'D'] as const).map((optKey) => {
              const isSelected = selectedOption === optKey;
              const isOptionCorrect = optKey === question.correctAnswer;

              let optStyle = 'border-slate-800 bg-slate-800/40 hover:border-indigo-500/50 hover:bg-slate-800/80 text-slate-200';
              if (submitted) {
                if (isOptionCorrect) {
                  optStyle = 'border-emerald-500 bg-emerald-500/20 text-emerald-300 ring-1 ring-emerald-500';
                } else if (isSelected && !isOptionCorrect) {
                  optStyle = 'border-rose-500 bg-rose-500/20 text-rose-300 ring-1 ring-rose-500';
                } else {
                  optStyle = 'border-slate-800/60 bg-slate-900/40 text-slate-500 opacity-60';
                }
              } else if (isSelected) {
                optStyle = 'border-indigo-500 bg-indigo-500/20 text-white';
              }

              return (
                <button
                  key={optKey}
                  disabled={submitted}
                  onClick={() => handleSubmit(optKey)}
                  className={`flex items-start gap-3 p-3.5 rounded-lg border text-left transition-all duration-150 cursor-pointer disabled:cursor-default ${optStyle}`}
                >
                  <span className="w-7 h-7 rounded-md bg-slate-900/80 border border-slate-700/80 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                    {optKey}
                  </span>
                  <div className="text-sm md:text-base flex-1 pt-0.5">
                    <MathRenderer content={options[optKey]} inline />
                  </div>
                  {submitted && isOptionCorrect && (
                    <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  )}
                  {submitted && isSelected && !isOptionCorrect && (
                    <XCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                  )}
                </button>
              );
            })}
          </div>
        );
      })()}

      {/* Input for Numerical Type */}
      {!isMcq && (
        <div className="mb-6 bg-slate-800/30 p-4 rounded-xl border border-slate-800">
          <label className="block text-xs uppercase tracking-wider text-slate-400 mb-2 font-semibold">
            Enter Numerical / Integer Value:
          </label>
          <div className="flex items-center gap-3 max-w-md">
            <input
              type="text"
              disabled={submitted}
              value={numericalInput}
              onChange={(e) => setNumericalInput(e.target.value)}
              placeholder="e.g. 24 or 1.5"
              className="bg-slate-950 border border-slate-700 rounded-lg px-4 py-2.5 text-slate-100 font-mono text-base focus:outline-none focus:border-indigo-500 disabled:opacity-75 flex-1"
            />
            {!submitted ? (
              <button
                onClick={() => handleSubmit(numericalInput)}
                disabled={numericalInput.trim() === ''}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-500 text-white font-medium rounded-lg text-sm transition-all"
              >
                Submit Answer
              </button>
            ) : (
              <span className="text-sm font-semibold px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300">
                Official Key: {question.correctAnswer}
              </span>
            )}
          </div>
        </div>
      )}

      {/* Feedback & Error Tagging (if wrong) */}
      {submitted && (
        <div className={`p-4 rounded-xl mb-5 border ${isCorrect ? 'bg-emerald-950/30 border-emerald-500/40' : 'bg-rose-950/30 border-rose-500/40'}`}>
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-2">
              {isCorrect ? (
                <>
                  <CheckCircle className="w-5 h-5 text-emerald-400" />
                  <span className="text-sm font-semibold text-emerald-300">
                    Correct! (+4 Marks)
                  </span>
                </>
              ) : (
                <>
                  <XCircle className="w-5 h-5 text-rose-400" />
                  <span className="text-sm font-semibold text-rose-300">
                    Incorrect (-1 Mark) &bull; Correct Answer:{' '}
                    <span className="font-mono text-emerald-400 font-bold ml-1">{question.correctAnswer}</span>
                  </span>
                </>
              )}
            </div>

            {/* Error Notebook Quick Tagging */}
            {!isCorrect && (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-slate-400 flex items-center gap-1">
                  <Tag className="w-3.5 h-3.5 text-amber-400" /> Tag Mistake:
                </span>
                {(['conceptual', 'calculation', 'formula', 'misreading', 'time_management'] as ErrorTag[]).map((tag) => (
                  <button
                    key={tag}
                    onClick={() => handleSaveErrorCategory(tag)}
                    className={`px-2 py-1 rounded text-xs transition-all ${
                      errorTag === tag
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {tag.replace('_', ' ')}
                  </button>
                ))}
                {errorSaved && <span className="text-emerald-400 text-xs font-bold">Saved!</span>}
              </div>
            )}
          </div>

          {/* Guru Ji Kota Teacher Hinglish Mentorship Box */}
          <GuruMentorBox
            question={question}
            isCorrect={isCorrect}
            userAnswer={selectedOption || numericalInput}
            errorTag={errorTag}
          />
        </div>
      )}

      {/* Expandable 10-Point Detailed Solution Drawer */}
      <div className="mt-4 pt-3 border-t border-slate-800/80">
        <button
          onClick={() => setShowSolution(!showSolution)}
          className="w-full flex items-center justify-between p-3 rounded-lg bg-slate-800/50 hover:bg-slate-800 text-slate-200 text-sm font-medium transition-all"
        >
          <span className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-400" />
            <span>{showSolution ? 'Hide Complete 10-Point Solution' : 'View Complete 10-Point Textbook Solution'}</span>
          </span>
          {showSolution ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
        </button>

        {showSolution && (
          <div className="mt-4 p-5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-5 text-sm text-slate-300">
            {/* 1. Correct Answer */}
            <div className="border-l-2 border-emerald-500 pl-3">
              <span className="text-xs uppercase font-bold text-emerald-400 tracking-wider block mb-1">
                1. Official Correct Answer
              </span>
              <div className="text-base text-slate-100 font-semibold">
                <MathRenderer content={question.solution.correctAnswerText} inline />
              </div>
            </div>

            {/* 2. Concept Tested */}
            <div className="border-l-2 border-indigo-500 pl-3">
              <span className="text-xs uppercase font-bold text-indigo-400 tracking-wider block mb-1">
                2. Concept Tested
              </span>
              <p className="text-slate-200">{question.solution.conceptTested}</p>
            </div>

            {/* 3. Formula Required */}
            <div className="border-l-2 border-sky-500 pl-3">
              <span className="text-xs uppercase font-bold text-sky-400 tracking-wider block mb-1">
                3. Formula Required
              </span>
              <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                <MathRenderer content={question.solution.formulaRequired} />
              </div>
            </div>

            {/* 4. Step-by-Step Solution */}
            <div className="border-l-2 border-purple-500 pl-3">
              <span className="text-xs uppercase font-bold text-purple-400 tracking-wider block mb-2">
                4. Step-by-Step Textbook Derivation
              </span>
              <ol className="list-decimal list-inside space-y-2 text-slate-200">
                {question.solution.stepByStep.map((step, idx) => (
                  <li key={idx} className="leading-relaxed">
                    <MathRenderer content={step} inline />
                  </li>
                ))}
              </ol>
            </div>

            {/* 5. Why Correct & 6. Why other options incorrect */}
            <div className="border-l-2 border-teal-500 pl-3">
              <span className="text-xs uppercase font-bold text-teal-400 tracking-wider block mb-1">
                5 & 6. Validation & Distractor Analysis
              </span>
              <p className="text-slate-300 mb-2">{question.solution.whyCorrect}</p>
              {question.solution.whyOptionsIncorrect && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
                  {(['A', 'B', 'C', 'D'] as const).map((opt) => (
                    <div key={opt} className="text-xs bg-slate-900/60 p-2 rounded border border-slate-800/80">
                      <span className="font-bold text-slate-200 mr-1">Option {opt}:</span>
                      <span className="text-slate-400">{question.solution.whyOptionsIncorrect?.[opt]}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* 7. Short Approach */}
            <div className="border-l-2 border-amber-500 pl-3">
              <span className="text-xs uppercase font-bold text-amber-400 tracking-wider flex items-center gap-1 mb-1">
                <Zap className="w-3.5 h-3.5 text-amber-400" /> 7. 60-Second Short Approach / Speed Technique
              </span>
              <p className="text-amber-200/90 font-medium">{question.solution.shortApproach}</p>
            </div>

            {/* 8. Common Mistakes */}
            <div className="border-l-2 border-rose-500 pl-3">
              <span className="text-xs uppercase font-bold text-rose-400 tracking-wider flex items-center gap-1 mb-1">
                <AlertTriangle className="w-3.5 h-3.5 text-rose-400" /> 8. Common Traps & Pitfalls (-1 Traps)
              </span>
              <p className="text-rose-200/90">{question.solution.commonMistakes}</p>
            </div>

            {/* 9. Exam Tricks */}
            <div className="border-l-2 border-yellow-500 pl-3">
              <span className="text-xs uppercase font-bold text-yellow-400 tracking-wider flex items-center gap-1 mb-1">
                <Sparkles className="w-3.5 h-3.5 text-yellow-400" /> 9. JEE Main Pro Exam Trick
              </span>
              <p className="text-yellow-200/90">{question.solution.examTricks}</p>
            </div>

            {/* 10. Related Concepts */}
            <div className="border-l-2 border-blue-500 pl-3">
              <span className="text-xs uppercase font-bold text-blue-400 tracking-wider flex items-center gap-1 mb-2">
                <BookOpen className="w-3.5 h-3.5 text-blue-400" /> 10. Related High-Yield Topics
              </span>
              <div className="flex flex-wrap gap-2">
                {question.solution.relatedConcepts.map((item, idx) => (
                  <span key={idx} className="text-xs px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300">
                    {item}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default QuestionCard;
