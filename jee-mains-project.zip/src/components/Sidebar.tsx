'use client';

import React from 'react';
import {
  LayoutDashboard,
  BookOpen,
  Database,
  BarChart2,
  Sparkles,
  Zap,
  Bookmark,
  Clock,
  AlertTriangle,
  Calendar,
  X,
  Target,
  GraduationCap,
  Layers,
  FileText,
  Award,
  FlaskConical,
  Calculator
} from 'lucide-react';
import { PlatformMode, BoardNavTab } from '@/types';

export type NavTab =
  | 'dashboard'
  | 'syllabus'
  | 'pyqs'
  | 'weightage'
  | 'expected'
  | 'revision'
  | 'formulas'
  | 'mocktest'
  | 'errors'
  | 'planner';

interface SidebarProps {
  currentMode: PlatformMode;
  onSelectMode: (mode: PlatformMode) => void;
  activeJeeTab: NavTab;
  onSelectJeeTab: (tab: NavTab) => void;
  activeBoardTab: BoardNavTab;
  onSelectBoardTab: (tab: BoardNavTab) => void;
  isOpen: boolean;
  onClose: () => void;
  totalPYQCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentMode,
  onSelectMode,
  activeJeeTab,
  onSelectJeeTab,
  activeBoardTab,
  onSelectBoardTab,
  isOpen,
  onClose,
  totalPYQCount = 2259,
}) => {
  // JEE Main Nav Items
  const jeeNavItems: { id: NavTab; label: string; icon: React.ReactNode; badge?: string }[] = [
    { id: 'dashboard', label: 'Preparation Dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'syllabus', label: 'Official Syllabus (NTA)', icon: <BookOpen className="w-4 h-4" />, badge: 'Active' },
    { id: 'pyqs', label: 'Authentic PYQ Bank', icon: <Database className="w-4 h-4" />, badge: `${totalPYQCount}+` },
    { id: 'weightage', label: '10-Year Weightage & Trends', icon: <BarChart2 className="w-4 h-4" /> },
    { id: 'expected', label: 'Most Expected Questions', icon: <Sparkles className="w-4 h-4" />, badge: 'High Yield' },
    { id: 'revision', label: 'Revision Centre', icon: <Zap className="w-4 h-4" /> },
    { id: 'formulas', label: 'Formula Books', icon: <Bookmark className="w-4 h-4" /> },
    { id: 'mocktest', label: '10 Full NTA Mock Tests', icon: <Clock className="w-4 h-4" />, badge: '10 Mocks' },
    { id: 'errors', label: 'Error Notebook', icon: <AlertTriangle className="w-4 h-4" /> },
    { id: 'planner', label: 'Smart Study Planner', icon: <Calendar className="w-4 h-4" /> },
  ];

  // 12th Board Nav Items
  const boardNavItems: { id: BoardNavTab; label: string; icon: React.ReactNode; badge?: string }[] = [
    { id: 'board_dashboard', label: 'Board Exam Dashboard', icon: <LayoutDashboard className="w-4 h-4" />, badge: '95%+ Target' },
    { id: 'board_physics', label: 'Class 12 Physics', icon: <Zap className="w-4 h-4" />, badge: 'Derivations' },
    { id: 'board_chemistry', label: 'Class 12 Chemistry', icon: <FlaskConical className="w-4 h-4" />, badge: 'Reactions' },
    { id: 'board_maths', label: 'Class 12 Mathematics', icon: <Calculator className="w-4 h-4" />, badge: 'Tricks' },
    { id: 'board_questions', label: '1,000+ Question Bank', icon: <Layers className="w-4 h-4" />, badge: '1,002 Qs' },
    { id: 'board_reactions', label: 'Named Reactions Guide', icon: <Sparkles className="w-4 h-4" />, badge: 'Organic' },
    { id: 'board_reagents', label: 'Reagents Master Guide', icon: <FlaskConical className="w-4 h-4" />, badge: 'Selectivity' },
    { id: 'board_derivations', label: 'Must-Do Derivations', icon: <Award className="w-4 h-4" />, badge: '5-Markers' },
    { id: 'board_tricks', label: 'Maths Exam Tricks', icon: <Clock className="w-4 h-4" />, badge: 'Shortcuts' },
    { id: 'board_papers', label: '3-Hr Board Sample Papers', icon: <FileText className="w-4 h-4" />, badge: 'Official' },
    { id: 'board_notes', label: 'NCERT Revision Notes', icon: <Bookmark className="w-4 h-4" />, badge: 'High Yield' },
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-72 bg-slate-950 border-r border-slate-800 flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Logo & Platform Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-white text-base shadow-lg transition-all ${
                currentMode === 'jee_main'
                  ? 'bg-gradient-to-tr from-indigo-600 to-sky-500 shadow-indigo-500/20'
                  : 'bg-gradient-to-tr from-emerald-600 to-teal-500 shadow-emerald-500/20'
              }`}
            >
              {currentMode === 'jee_main' ? 'JEE' : '12th'}
            </div>
            <div>
              <h2 className="text-sm font-extrabold text-white tracking-tight leading-tight">
                {currentMode === 'jee_main' ? 'JEE MAIN 2027' : 'CLASS 12 BOARDS'}
              </h2>
              <span
                className={`text-[10px] font-semibold tracking-wider uppercase block ${
                  currentMode === 'jee_main' ? 'text-sky-400' : 'text-emerald-400'
                }`}
              >
                {currentMode === 'jee_main' ? 'Paper 1 (B.E./B.Tech)' : 'CBSE & State Boards'}
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 lg:hidden cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Prominent Dual Mode Switcher */}
        <div className="mx-3 mt-3 p-1 bg-slate-900 border border-slate-800 rounded-2xl flex items-center gap-1 shadow-inner">
          <button
            onClick={() => {
              onSelectMode('jee_main');
            }}
            className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-extrabold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              currentMode === 'jee_main'
                ? 'bg-gradient-to-r from-indigo-600 to-sky-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Target className="w-3.5 h-3.5" />
            <span>JEE Main</span>
          </button>
          <button
            onClick={() => {
              onSelectMode('board_12th');
            }}
            className={`flex-1 py-2 px-2.5 rounded-xl text-xs font-extrabold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              currentMode === 'board_12th'
                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <GraduationCap className="w-3.5 h-3.5" />
            <span>12th Boards</span>
          </button>
        </div>

        {/* Target Indicator Card */}
        <div className="p-2.5 mx-3 mt-2 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {currentMode === 'jee_main' ? (
              <Target className="w-4 h-4 text-emerald-400" />
            ) : (
              <Award className="w-4 h-4 text-emerald-400" />
            )}
            <div className="text-xs">
              <span className="text-slate-400 block text-[9px] uppercase font-bold">Exam Target</span>
              <strong className="text-white text-xs">
                {currentMode === 'jee_main' ? 'Session 1 (Jan 2027)' : 'Board Exams (Feb 2027)'}
              </strong>
            </div>
          </div>
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
            {currentMode === 'jee_main' ? 'NTA 2027' : 'CBSE 2027'}
          </span>
        </div>

        {/* Strict Rule Alert Badge */}
        <div
          className={`mx-3 mt-2 px-2.5 py-1.5 rounded-lg border text-[10px] flex items-center gap-2 font-medium ${
            currentMode === 'jee_main'
              ? 'bg-amber-500/10 border-amber-500/20 text-amber-300'
              : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-300'
          }`}
        >
          <span
            className={`w-1.5 h-1.5 rounded-full animate-ping shrink-0 ${
              currentMode === 'jee_main' ? 'bg-amber-400' : 'bg-emerald-400'
            }`}
          />
          <span className="truncate">
            {currentMode === 'jee_main'
              ? 'Exclusively JEE Main • Zero Advanced'
              : 'Step-Wise Marking • Topper Presentation'}
          </span>
        </div>

        {/* Navigation List */}
        <nav className="flex-1 overflow-y-auto px-3 py-2 space-y-1 mt-1">
          {currentMode === 'jee_main'
            ? jeeNavItems.map((item) => {
                const isActive = activeJeeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onSelectJeeTab(item.id);
                      onClose();
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs md:text-sm font-medium transition-all cursor-pointer ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className={isActive ? 'text-white' : 'text-slate-400'}>{item.icon}</span>
                      <span>{item.label}</span>
                    </div>
                    {item.badge && (
                      <span
                        className={`text-[9px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                          isActive
                            ? 'bg-white/20 text-white'
                            : 'bg-slate-800 text-indigo-400 border border-slate-700'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })
            : boardNavItems.map((item) => {
                const isActive = activeBoardTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onSelectBoardTab(item.id);
                      onClose();
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs md:text-sm font-medium transition-all cursor-pointer ${
                      isActive
                        ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className={isActive ? 'text-white' : 'text-slate-400'}>{item.icon}</span>
                      <span>{item.label}</span>
                    </div>
                    {item.badge && (
                      <span
                        className={`text-[9px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                          isActive
                            ? 'bg-white/20 text-white'
                            : 'bg-slate-800 text-emerald-400 border border-slate-700'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
        </nav>

        {/* Footer info */}
        <div className="p-3 border-t border-slate-800 text-xs text-slate-500 flex flex-col gap-1">
          <div className="flex items-center justify-between text-slate-400">
            <span>Syllabus Status:</span>
            <span className="text-emerald-400 font-semibold">
              {currentMode === 'jee_main' ? 'NTA Rationalized' : 'NCERT Class 12'}
            </span>
          </div>
          <span className="text-[10px] text-slate-600">
            Physics &bull; Chemistry &bull; Mathematics
          </span>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
