import { PYQQuestion, SubjectType, QuestionType, DifficultyLevel } from '@/types';
import physicsData from './pyqs/physics.json';
import chemistryData from './pyqs/chemistry.json';
import mathData from './pyqs/mathematics.json';

const ALL_PHYSICS: PYQQuestion[] = physicsData as unknown as PYQQuestion[];
const ALL_CHEMISTRY: PYQQuestion[] = chemistryData as unknown as PYQQuestion[];
const ALL_MATH: PYQQuestion[] = mathData as unknown as PYQQuestion[];

let cachedAllQuestions: PYQQuestion[] | null = null;

export const getAllPYQQuestions = (): PYQQuestion[] => {
  if (!cachedAllQuestions) {
    cachedAllQuestions = [...ALL_PHYSICS, ...ALL_CHEMISTRY, ...ALL_MATH];
  }
  return cachedAllQuestions;
};

export const getQuestionsBySubject = (subject: SubjectType): PYQQuestion[] => {
  if (subject === 'physics') return ALL_PHYSICS;
  if (subject === 'chemistry') return ALL_CHEMISTRY;
  return ALL_MATH;
};

export const getQuestionById = (id: string): PYQQuestion | undefined => {
  return getAllPYQQuestions().find((q) => q.id === id);
};

export interface PYQFilterOptions {
  subject?: SubjectType | 'all';
  chapterId?: string | 'all';
  year?: number | 'all';
  questionType?: QuestionType | 'all';
  difficulty?: DifficultyLevel | 'all';
  searchQuery?: string;
}

export const filterPYQQuestions = (options: PYQFilterOptions): PYQQuestion[] => {
  let list = getAllPYQQuestions();

  if (options.subject && options.subject !== 'all') {
    list = list.filter((q) => q.subject === options.subject);
  }

  if (options.chapterId && options.chapterId !== 'all') {
    list = list.filter((q) => q.chapterId === options.chapterId);
  }

  if (options.year && options.year !== 'all') {
    list = list.filter((q) => q.year === options.year);
  }

  if (options.questionType && options.questionType !== 'all') {
    list = list.filter((q) => q.questionType === options.questionType);
  }

  if (options.difficulty && options.difficulty !== 'all') {
    list = list.filter((q) => q.difficulty === options.difficulty);
  }

  if (options.searchQuery && options.searchQuery.trim().length > 0) {
    const q = options.searchQuery.toLowerCase();
    list = list.filter(
      (item) =>
        item.id.toLowerCase().includes(q) ||
        item.questionText.toLowerCase().includes(q) ||
        item.chapterName.toLowerCase().includes(q) ||
        item.topicName.toLowerCase().includes(q) ||
        item.officialSource.toLowerCase().includes(q)
    );
  }

  return list;
};

export interface MockTestMeta {
  id: string;
  testNumber: number;
  title: string;
  subtitle: string;
  difficulty: 'Easy-Moderate' | 'Moderate' | 'Hard' | 'NTA Standard';
  targetShift: string;
  durationMinutes: number;
  totalQuestions: number;
  totalMarks: number;
  description: string;
}

export const MOCK_TEST_CATALOG: MockTestMeta[] = [
  {
    id: 'mock-01',
    testNumber: 1,
    title: 'All India JEE Main Full Mock 01',
    subtitle: 'Session 1 Baseline & Rank Predictor',
    difficulty: 'Moderate',
    targetShift: 'January Shift 1 Standard',
    durationMinutes: 180,
    totalQuestions: 75,
    totalMarks: 300,
    description: 'Perfect diagnostic baseline mock test covering high-yield topics across Physics, Chemistry, and Mathematics.',
  },
  {
    id: 'mock-02',
    testNumber: 2,
    title: 'All India JEE Main Full Mock 02',
    subtitle: 'High-Scoring Speed Booster',
    difficulty: 'Easy-Moderate',
    targetShift: 'Speed & Accuracy Shift',
    durationMinutes: 180,
    totalQuestions: 75,
    totalMarks: 300,
    description: 'Designed to build question-selection confidence and fast 60-second formula execution in Section A.',
  },
  {
    id: 'mock-03',
    testNumber: 3,
    title: 'All India JEE Main Full Mock 03',
    subtitle: 'Tough Shift Simulation & Negative Control',
    difficulty: 'Hard',
    targetShift: 'Difficult Shift Simulation',
    durationMinutes: 180,
    totalQuestions: 75,
    totalMarks: 300,
    description: 'Rigorous calculative physical chemistry and multi-step mechanics designed to train negative marking discipline.',
  },
  {
    id: 'mock-04',
    testNumber: 4,
    title: 'All India JEE Main Full Mock 04',
    subtitle: 'Official January Shift Re-Creation',
    difficulty: 'Moderate',
    targetShift: 'Jan 27 Shift 1 Replica',
    durationMinutes: 180,
    totalQuestions: 75,
    totalMarks: 300,
    description: 'Direct replica of recent January examination shifts with authentic weightage distribution.',
  },
  {
    id: 'mock-05',
    testNumber: 5,
    title: 'All India JEE Main Full Mock 05',
    subtitle: 'Modern Physics & Physical Chemistry Special',
    difficulty: 'Moderate',
    targetShift: 'High-ROI Chapters Drill',
    durationMinutes: 180,
    totalQuestions: 75,
    totalMarks: 300,
    description: 'Elevated weightage for Modern Physics, Electrochemistry, Solutions, and Chemical Kinetics.',
  },
  {
    id: 'mock-06',
    testNumber: 6,
    title: 'All India JEE Main Full Mock 06',
    subtitle: 'Vector-3D & Organic Mastery Test',
    difficulty: 'Hard',
    targetShift: 'Geometry & GOC Emphasis',
    durationMinutes: 180,
    totalQuestions: 75,
    totalMarks: 300,
    description: 'Intensive practice on 3D lines, skew distances, reaction mechanisms, and coordination isomerism.',
  },
  {
    id: 'mock-07',
    testNumber: 7,
    title: 'All India JEE Main Full Mock 07',
    subtitle: '99+ Percentile Benchmark Test',
    difficulty: 'Hard',
    targetShift: 'Toppers Benchmark Shift',
    durationMinutes: 180,
    totalQuestions: 75,
    totalMarks: 300,
    description: 'Advanced difficulty Section B numerical value problems to distinguish top 1% percentiles.',
  },
  {
    id: 'mock-08',
    testNumber: 8,
    title: 'All India JEE Main Full Mock 08',
    subtitle: 'April Session High-Yield Rehearsal',
    difficulty: 'Moderate',
    targetShift: 'April Session Simulation',
    durationMinutes: 180,
    totalQuestions: 75,
    totalMarks: 300,
    description: 'Full syllabus test reflecting recent April session question nuances and conceptual variations.',
  },
  {
    id: 'mock-09',
    testNumber: 9,
    title: 'All India JEE Main Full Mock 09',
    subtitle: 'Pre-JEE Speed & Accuracy Drill',
    difficulty: 'NTA Standard',
    targetShift: 'Time Pressure Drill',
    durationMinutes: 180,
    totalQuestions: 75,
    totalMarks: 300,
    description: 'Balanced test to master 3-hour examination biological rhythm and question triage strategy.',
  },
  {
    id: 'mock-10',
    testNumber: 10,
    title: 'All India JEE Main Full Mock 10',
    subtitle: 'The Grand 2027 Final Simulation',
    difficulty: 'NTA Standard',
    targetShift: 'Final Examination Dress Rehearsal',
    durationMinutes: 180,
    totalQuestions: 75,
    totalMarks: 300,
    description: 'The ultimate final simulation test before the real examination. Full syllabus, verified answer keys, and national percentile curve.',
  },
];

export const generateNTAFullMockTestByIndex = (index: number = 0): {
  id: string;
  title: string;
  durationSeconds: number;
  questions: PYQQuestion[];
} => {
  const safeIndex = Math.max(0, Math.min(9, index));
  const meta = MOCK_TEST_CATALOG[safeIndex] || MOCK_TEST_CATALOG[0];

  const pickSectionForMock = (list: PYQQuestion[], mockIdx: number) => {
    const mcqs = list.filter((q) => q.questionType === 'MCQ');
    const nums = list.filter((q) => q.questionType === 'NUMERICAL');

    // Slice distinct non-overlapping questions for each of the 10 mocks
    const mcqStart = (mockIdx * 20) % Math.max(1, mcqs.length - 20);
    const numStart = (mockIdx * 5) % Math.max(1, nums.length - 5);

    const pickedMcqs = mcqs.slice(mcqStart, mcqStart + 20);
    const pickedNums = nums.slice(numStart, numStart + 5);

    return [...pickedMcqs, ...pickedNums];
  };

  const physicsQs = pickSectionForMock(ALL_PHYSICS, safeIndex);
  const chemQs = pickSectionForMock(ALL_CHEMISTRY, safeIndex);
  const mathQs = pickSectionForMock(ALL_MATH, safeIndex);

  return {
    id: meta.id,
    title: `${meta.title}: ${meta.subtitle}`,
    durationSeconds: 180 * 60, // 3 hours
    questions: [...physicsQs, ...chemQs, ...mathQs],
  };
};

export const generateNTAFullMockTest = (testId: string = 'mock-01'): {
  id: string;
  title: string;
  durationSeconds: number;
  questions: PYQQuestion[];
} => {
  const foundIndex = MOCK_TEST_CATALOG.findIndex((m) => m.id === testId);
  return generateNTAFullMockTestByIndex(foundIndex >= 0 ? foundIndex : 0);
};

export const generateSubjectMockTest = (
  subject: SubjectType,
  testId: string = `mock-${subject}-01`
): {
  id: string;
  title: string;
  durationSeconds: number;
  questions: PYQQuestion[];
} => {
  const list = getQuestionsBySubject(subject);
  const mcqs = list.filter((q) => q.questionType === 'MCQ').slice(0, 20);
  const nums = list.filter((q) => q.questionType === 'NUMERICAL').slice(0, 5);

  const subjectNames = {
    physics: 'Physics',
    chemistry: 'Chemistry',
    mathematics: 'Mathematics',
  };

  return {
    id: testId,
    title: `JEE Main ${subjectNames[subject]} Standard Shift Test (25 Qs - 100 Marks)`,
    durationSeconds: 60 * 60, // 60 minutes
    questions: [...mcqs, ...nums],
  };
};
