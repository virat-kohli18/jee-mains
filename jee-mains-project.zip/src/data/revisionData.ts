import { RevisionNotes } from '@/types';

export const REVISION_DATA: RevisionNotes[] = [
  // ===================== PHYSICS =====================
  {
    chapterId: 'phy-modern-physics',
    chapterName: 'Modern Physics (Dual Nature, Atoms, Nuclei)',
    subject: 'physics',
    fifteenMinSummary: [
      'Photoelectric Effect: Kmax = h*nu - phi = hc/lambda - phi. Saturation current is proportional to intensity; stopping potential depends ONLY on frequency.',
      'de Broglie Wavelength: lambda = h / p = h / sqrt(2 m K). For electron accelerated through V volts: lambda = 12.27 / sqrt(V) Angstroms.',
      'Bohr Hydrogen Atom: r_n = 0.529 * (n^2 / Z) A, v_n = 2.18e6 * (Z / n) m/s, E_n = -13.6 * (Z^2 / n^2) eV.',
      'Spectral Lines: 1/lambda = R Z^2 (1/n1^2 - 1/n2^2). Lyman (n1=1, UV), Balmer (n1=2, Visible), Paschen (n1=3, IR).',
      'Nuclear Radius: R = R_0 * A^(1/3) where R_0 = 1.2 fm. Nuclear mass density is constant (~2.3 x 10^17 kg/m^3) independent of mass number A.',
      'Mass Defect & Binding Energy: Delta m = [Z*m_p + (A - Z)*m_n] - M_nucleus. BE = Delta m * 931.5 MeV. Peak BE/nucleon is ~8.8 MeV for Fe-56.',
    ],
    thirtyMinHighYield: [
      {
        coreConcept: 'Einstein Photoelectric Equation & Stopping Potential Graph',
        keyFormulas: [
          'e V_0 = h \\nu - \\phi = \\frac{hc}{\\lambda} - \\phi',
          'V_0 = \\left(\\frac{h}{e}\\right)\\nu - \\frac{\\phi}{e} \\implies \\text{Slope is always } \\frac{h}{e}',
        ],
        criticalPitfalls: [
          'Confusing intensity with frequency: Increasing intensity doubles photocurrent but does NOT change stopping potential.',
          'Forgetting that work function phi is characteristic of the metal and cannot be altered by radiation.',
        ],
      },
      {
        coreConcept: 'Bohr Hydrogen Transition and Photon Emissions',
        keyFormulas: [
          '\\Delta E = E_{n2} - E_{n1} = 13.6 Z^2 \\left(\\frac{1}{n_1^2} - \\frac{1}{n_2^2}\\right) \\text{ eV}',
          '\\text{Max number of spectral lines emitted when de-exciting from level } n: N = \\frac{n(n-1)}{2}',
        ],
        criticalPitfalls: [
          'First excited state means n = 2, second excited state means n = 3 (DO NOT take n = 1 for first excited state).',
          'For a single isolated atom transitioning from level n, maximum lines emitted is (n - 1), whereas for a gas sample it is n(n-1)/2.',
        ],
      },
    ],
    masterConcepts: [
      {
        heading: 'Wave-Particle Duality and Matter Waves',
        content: 'Any moving particle possesses an associated de Broglie matter wave. The wavelength is universally related to linear momentum by lambda = h/p.',
        formulas: [
          '\\lambda = \\frac{h}{p} = \\frac{h}{\\sqrt{2mE_k}} = \\frac{h}{\\sqrt{2mqV}}',
          '\\text{For thermal neutron at temperature } T: \\lambda = \\frac{h}{\\sqrt{3mkT}}',
        ],
      },
      {
        heading: 'Nuclear Stability and Binding Energy Curve',
        content: 'Nuclear forces are short-range (~1-2 fm), charge-independent, and exhibit saturation. Nuclei with A < 20 fuse to release energy; nuclei with A > 200 undergo fission.',
        formulas: [
          'Q = (m_{\\text{reactants}} - m_{\\text{products}}) \\times 931.5 \\text{ MeV}',
          'R = R_0 A^{1/3} \\implies \\text{Nuclear Volume } V \\propto A \\implies \\rho = \\text{constant}',
        ],
      },
    ],
    shortcutsAndTricks: [
      'hc = 1240 eV·nm: To find photon energy in eV, simply compute 1240 / lambda(nm).',
      'For electron wavelength: lambda(Angstrom) = sqrt(150 / V) ~ 12.27 / sqrt(V).',
      'Balmer-alpha to Lyman-alpha wavelength ratio is ALWAYS 27/5 = 5.4.',
    ],
    frequentMistakes: [
      'Using classical kinetic energy 1/2 m v^2 when v approaches c (relativistic regime).',
      'Calculating mass defect in kg instead of using 1 amu = 931.5 MeV for speed.',
      'Treating Lyman series as visible light (Lyman is exclusively Ultraviolet).',
    ],
  },

  // ===================== CHEMISTRY =====================
  {
    chapterId: 'chem-coordination',
    chapterName: 'Coordination Compounds',
    subject: 'chemistry',
    fifteenMinSummary: [
      'Werner Theory: Primary valence is ionizable (equals oxidation state); secondary valence is non-ionizable and directional (equals coordination number).',
      'IUPAC Nomenclature: Cation named first; ligands named alphabetically (anionic end in -o, neutral like aqua, ammine, carbonyl); central metal ends in -ate if complex is an anion.',
      'Isomerism: Structural (Ionization, Hydrate, Linkage like NO2-/ONO-, Coordination) and Stereoisomerism (Geometrical: cis/trans, fac/mer in Ma3b3; Optical: non-superimposable mirror images).',
      'Valence Bond Theory: [Fe(CN)6]3- is d2sp3 (inner orbital, low spin), [Fe(H2O)6]3+ is sp3d2 (outer orbital, high spin).',
      'Crystal Field Theory: In octahedral field, d-orbitals split into lower t2g (dxy, dyz, dzx) and higher eg (dx2-y2, dz2) by Delta_o.',
      'Spectrochemical Series: I- < Br- < SCN- < Cl- < S2- < F- < OH- < C2O4(2-) < H2O < NCS- < EDTA(4-) < NH3 < en < CN- < CO.',
      'Spin-Only Magnetic Moment: mu = sqrt(n(n+2)) BM where n = number of unpaired electrons.',
    ],
    thirtyMinHighYield: [
      {
        coreConcept: 'Crystal Field Splitting and High Spin vs Low Spin Configurations',
        keyFormulas: [
          '\\Delta_t = \\frac{4}{9} \\Delta_o \\quad (\\text{Tetrahedral complexes are ALWAYS high-spin due to small splitting})',
          '\\text{CFSE(octahedral)} = \\left(-0.4 n_{t2g} + 0.6 n_{eg}\\right) \\Delta_o + m P',
        ],
        criticalPitfalls: [
          'Applying pairing when Delta_o < P: If ligand is weak field (Delta_o < P), electrons enter eg before pairing in t2g (High Spin).',
          'Assuming tetrahedral complexes show optical isomerism: Tetrahedral complexes rarely exhibit geometrical isomerism (all positions adjacent).',
        ],
      },
      {
        coreConcept: 'Facial (fac) and Meridional (mer) Isomerism in Octahedral Complexes',
        keyFormulas: [
          '[M a_3 b_3] \\implies \\text{fac-isomer (identical donors on one triangular face)}',
          '[M a_3 b_3] \\implies \\text{mer-isomer (identical donors around an equator)}',
        ],
        criticalPitfalls: [
          'Believing fac-isomer has a center of symmetry: fac-[Ma3b3] possesses C3 axis but NO inversion center.',
          '[M(AA)3] where AA is bidentate (e.g. [Co(en)3]3+) has NO plane of symmetry and is optically active (d and l enantiomers).',
        ],
      },
    ],
    masterConcepts: [
      {
        heading: 'Ligand Denticity and Chelate Effect',
        content: 'Chelating ligands form 5- or 6-membered rings with the central metal, conferring enhanced thermodynamic stability over monodentate ligands due to positive entropy change (Delta S > 0).',
        formulas: [
          '\\text{EDTA}^{4-} \\text{ is hexadentate (2 N and 4 O donors) with C.N. = 6}',
          '\\text{en (ethylenediamine) and } \\text{ox}^{2-} \\text{(oxalate) are symmetrical bidentate ligands}',
        ],
      },
      {
        heading: 'Color and Electronic Transitions',
        content: 'Color arises from d-d transitions when Delta_o falls in the visible range. Species with d0 (e.g. Sc3+, Ti4+) or d10 (e.g. Zn2+, Cu+) configurations are colorless due to absence of d-d transitions.',
        formulas: [
          '\\lambda_{\\text{absorbed}} = \\frac{hc}{\\Delta_o} \\implies \\text{Complementary color is observed}',
        ],
      },
    ],
    shortcutsAndTricks: [
      'CO and CN- are universally strong field ligands in JEE Main (cause electron pairing for 3d4 to 3d7).',
      'Spin-only magnetic moment shortcut: If n=1 => mu=1.73; n=2 => mu=2.83; n=3 => mu=3.87; n=4 => mu=4.90; n=5 => mu=5.92 BM.',
      'Tetrahedral splitting is always 4/9 of octahedral, so tetrahedral complexes are NEVER low spin.',
    ],
    frequentMistakes: [
      'Writing coordination sphere brackets [] incorrectly when precipitating with AgNO3.',
      'Counting coordination number as number of ligands instead of number of donor atoms (e.g. [Co(en)3]3+ has 3 ligands but C.N. = 6).',
    ],
  },

  // ===================== MATHEMATICS =====================
  {
    chapterId: 'math-vectors-3d',
    chapterName: 'Vector Algebra & 3D Geometry (Lines)',
    subject: 'mathematics',
    fifteenMinSummary: [
      'Dot Product: a . b = |a||b| cos(theta). Projection of a on b is (a . b) / |b|.',
      'Cross Product: a x b = |a||b| sin(theta) n_hat. Area of triangle with adjacent sides a, b is 1/2 |a x b|; area of parallelogram is |a x b|.',
      'Collinear Vectors: a x b = 0 <=> a = k b. Coplanar vectors: [a b c] = a . (b x c) = 0.',
      'Direction Cosines: l^2 + m^2 + n^2 = 1. If direction ratios are a, b, c, then l = a / sqrt(a^2 + b^2 + c^2).',
      'Equation of a Line: r = a + lambda b <=> (x - x1)/a = (y - y1)/b = (z - z1)/c.',
      'Angle between two lines: cos(theta) = |a1 a2 + b1 b2 + c1 c2| / [sqrt(a1^2+b1^2+c1^2) * sqrt(a2^2+b2^2+c2^2)]. Perpendicular when a1 a2 + b1 b2 + c1 c2 = 0.',
      'Shortest Distance between skew lines: d = |(a2 - a1) . (b1 x b2)| / |b1 x b2|.',
      'Shortest Distance between parallel lines: d = |(a2 - a1) x b| / |b|.',
    ],
    thirtyMinHighYield: [
      {
        coreConcept: 'Shortest Distance and Coplanarity of 3D Lines',
        keyFormulas: [
          'd = \\frac{\\left| \\begin{vmatrix} x_2-x_1 & y_2-y_1 & z_2-z_1 \\\\ a_1 & b_1 & c_1 \\\\ a_2 & b_2 & c_2 \\end{vmatrix} \\right|}{\\sqrt{(b_1c_2 - b_2c_1)^2 + (c_1a_2 - c_2a_1)^2 + (a_1b_2 - a_2b_1)^2}}',
          '\\text{Lines intersect } \\iff d = 0 \\iff \\begin{vmatrix} x_2-x_1 & y_2-y_1 & z_2-z_1 \\\\ a_1 & b_1 & c_1 \\\\ a_2 & b_2 & c_2 \\end{vmatrix} = 0',
        ],
        criticalPitfalls: [
          'Applying skew line formula to parallel lines where b1 x b2 = 0, causing division by zero!',
          'Forgetting to ensure the coefficients of x, y, z in the symmetric form are +1 before reading direction ratios (e.g. (2x - 3)/4 must be written as (x - 1.5)/2 so dr is 2, not 4).',
        ],
      },
      {
        coreConcept: 'Foot of Perpendicular and Image of a Point in a Line',
        keyFormulas: [
          '\\text{Any point on line: } P(\\lambda) = (x_1 + a\\lambda, y_1 + b\\lambda, z_1 + c\\lambda)',
          '\\vec{AP} \\cdot \\vec{b} = 0 \\implies a(x_P - x_A) + b(y_P - y_A) + c(z_P - z_A) = 0 \\implies \\text{Solve for } \\lambda',
          '\\text{Image point } Q: \\frac{A + Q}{2} = P \\implies Q = 2P - A',
        ],
        criticalPitfalls: [
          'Mistaking the foot of perpendicular for the image: Image is twice the foot minus the given point.',
        ],
      },
    ],
    masterConcepts: [
      {
        heading: 'Vector Triple Product and Lagrange Identity',
        content: 'While scalar and vector triple products were trimmed from general geometry, understanding cross product properties remains fundamental for vector mechanics.',
        formulas: [
          '|\\vec{a} \\times \\vec{b}|^2 + (\\vec{a} \\cdot \\vec{b})^2 = |\\vec{a}|^2 |\\vec{b}|^2',
        ],
      },
    ],
    shortcutsAndTricks: [
      'Standardize line equations first: Make coefficients of x, y, z equal to +1: (1-x)/2 -> -(x-1)/2 -> (x-1)/(-2).',
      'For distance between parallel lines, pick lambda = 0 on line 1 as point a1 and use standard point-to-line distance.',
      'If two lines intersect, equate general coordinates: x1 + a1 lambda = x2 + a2 mu, solve lambda and mu from first two equations and check consistency in third.',
    ],
    frequentMistakes: [
      'Using plane equations (which are DELETED from active JEE Main syllabus). Only line-based geometry applies.',
      'Sign error when expanding 3x3 determinant for shortest distance numerator.',
    ],
  },
];
