import json
import re

print("=== CHECKING JEE MAIN PYQS ===")
for sub in ['physics', 'chemistry', 'mathematics']:
    with open(f'src/data/pyqs/{sub}.json', 'r', encoding='utf-8') as f:
        data = json.load(f)
        qtexts = [q['questionText'] for q in data]
        mcqs = [q for q in data if q.get('questionType') == 'MCQ']
        from collections import Counter
        ans_dist = Counter([q.get('correctAnswer') for q in mcqs])
        print(f"Subject: {sub.upper()}")
        print(f"  Total questions: {len(data)}")
        print(f"  Unique question texts: {len(set(qtexts))}")
        print(f"  MCQ Answer distribution: {ans_dist}")

print("\n=== CHECKING CLASS 12TH BOARD QUESTIONS ===")
with open('src/data/boardQuestionsData.ts', 'r', encoding='utf-8') as f:
    text = f.read()

board_qtexts = re.findall(r'"questionText":\s*"([^"]+)"', text)
board_mcq_answers = re.findall(r'Correct Option:\s*\(([A-D])\)', text)
from collections import Counter
print(f"Board total questions: {len(board_qtexts)}")
print(f"Board unique question texts: {len(set(board_qtexts))}")
print(f"Board MCQ/AR Answer distribution: {Counter(board_mcq_answers)}")
