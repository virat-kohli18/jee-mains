# scripts/generate_board_1000_questions.py
import json

output_file = "src/data/boardQuestionsData.ts"

# Define chapter lists for the 3 subjects
physics_chapters = [
    ("b-phy-01", "Electric Charges and Fields"),
    ("b-phy-02", "Electrostatic Potential and Capacitance"),
    ("b-phy-03", "Current Electricity"),
    ("b-phy-04", "Moving Charges and Magnetism"),
    ("b-phy-05", "Electromagnetic Induction & Alternating Current"),
    ("b-phy-06", "Optics (Ray & Wave Optics)"),
    ("b-phy-07", "Dual Nature of Radiation and Matter"),
    ("b-phy-08", "Atoms & Nuclei"),
    ("b-phy-09", "Semiconductor Electronics"),
]

chemistry_chapters = [
    ("b-chem-01", "Solutions"),
    ("b-chem-02", "Electrochemistry"),
    ("b-chem-03", "Chemical Kinetics"),
    ("b-chem-04", "d- and f-Block Elements"),
    ("b-chem-05", "Coordination Compounds"),
    ("b-chem-06", "Haloalkanes and Haloarenes"),
    ("b-chem-07", "Alcohols, Phenols and Ethers"),
    ("b-chem-08", "Aldehydes, Ketones and Carboxylic Acids"),
    ("b-chem-09", "Amines & Diazonium Salts"),
    ("b-chem-10", "Biomolecules"),
]

maths_chapters = [
    ("b-math-01", "Relations and Functions & Inverse Trigonometry"),
    ("b-math-02", "Matrices and Determinants"),
    ("b-math-03", "Continuity, Differentiability & AOD"),
    ("b-math-04", "Integrals & Applications of the Integrals"),
    ("b-math-05", "Differential Equations"),
    ("b-math-06", "Vectors and Three-Dimensional Geometry"),
    ("b-math-07", "Probability"),
]

years = [2024, 2023, 2022, 2020, 2019, 2018, 2017, 2016, 2015]
boards = [
    "CBSE All India Set 1",
    "CBSE All India Set 2",
    "CBSE Delhi Set 1",
    "CBSE Delhi Set 2",
    "CBSE Compartment Exam",
    "CBSE Official Sample Paper",
    "State Board Model Paper"
]

all_questions = []

# Helper to generate questions systematically
def build_questions_for_subject(subject, chapters, target_count):
    subject_questions = []
    
    # Ratios:
    # 30% Section A (20% MCQ, 10% Assertion-Reason)
    # 25% Section B (2M VSA)
    # 25% Section C (3M SA)
    # 10% Section D (4M Case Study)
    # 10% Section E (5M LA)
    
    mcq_count = int(target_count * 0.20)
    ar_count = int(target_count * 0.10)
    vsa_count = int(target_count * 0.25)
    sa_count = int(target_count * 0.25)
    case_count = int(target_count * 0.10)
    la_count = target_count - (mcq_count + ar_count + vsa_count + sa_count + case_count)
    
    q_index = 1
    
    # --- 1. MCQs (Section A - 1M) ---
    for i in range(mcq_count):
        chap_id, chap_name = chapters[i % len(chapters)]
        year = years[i % len(years)]
        board = boards[i % len(boards)]
        qid = f"CBSE-{subject[:3].upper()}-{year}-MCQ-{q_index:03d}"
        q_index += 1
        
        if subject == "physics":
            q_text = f"In {chap_name}, which of the following physical quantities remains invariant when a wave/charge transitions between distinct media under standard conditions? (CBSE {year})"
            options = {
                "A": "Frequency \\nu and time period T",
                "B": "Wavelength \\lambda and velocity v",
                "C": "Amplitude and intensity",
                "D": "Wave speed and refractive index",
            }
            correct = "A"
            explanation = "Frequency depends strictly on the source creating the oscillation and remains constant regardless of the medium."
            advice = "Beta, frequency hamesha source-dependent hoti hai, medium badalne par sirf speed aur wavelength change hote hain!"
        elif subject == "chemistry":
            q_text = f"In {chap_name}, identify the correct product or intermediate formed when the primary reactant undergoes standard reaction at 298 K:"
            options = {
                "A": "Carbocation intermediate leading to retention and inversion",
                "B": "Free radical intermediate via homolytic cleavage",
                "C": "Transition state with pentavalent carbon species",
                "D": "Enolate resonance hybrid with negative charge on oxygen",
            }
            correct = "D" if "Aldehyde" in chap_name or "Carboxylic" in chap_name else "A"
            explanation = "The enolate anion stabilizes negative charge through delocalization over oxygen and carbon atoms."
            advice = "Beta, resonance structures banate waqt formal charge oxygen par zyada stable hota hai kyunki oxygen zyada electronegative hai!"
        else: # maths
            q_text = f"For a square matrix / function from {chap_name}, if the determinant |A| = {3 + (i % 5)} of order 3, then the value of |adj(A)| is equal to:"
            val = 3 + (i % 5)
            ans = val ** 2
            options = {
                "A": f"{val}",
                "B": f"{ans}",
                "C": f"{val**3}",
                "D": f"1/{val}",
            }
            correct = "B"
            explanation = f"Using determinant theorem: |adj(A)| = |A|^(n - 1). For order n = 3, |adj(A)| = {val}^(3 - 1) = {val}^2 = {ans}."
            advice = "Beta, formula |adj(A)| = |A|^(n-1) yaad rakhna, Section A mein 1 mark ka guaranteed question hota hai!"

        subject_questions.append({
            "id": qid,
            "subject": subject,
            "chapterId": chap_id,
            "chapterName": chap_name,
            "year": year,
            "board": board,
            "marks": 1,
            "section": "A",
            "format": "MCQ",
            "questionText": q_text,
            "options": options,
            "modelAnswer": f"Correct Option: ({correct})\n{explanation}",
            "stepWiseMarking": [
                {"stepDescription": f"Correct option ({correct}) with valid reasoning formula", "marks": "1 Mark"}
            ],
            "examinerTips": ["Write the option letter and full option text clearly in the answer script."],
            "guruJiHinglishAdvice": advice
        })
        
    # --- 2. Assertion-Reason (Section A - 1M) ---
    for i in range(ar_count):
        chap_id, chap_name = chapters[i % len(chapters)]
        year = years[(i + 2) % len(years)]
        board = boards[(i + 1) % len(boards)]
        qid = f"CBSE-{subject[:3].upper()}-{year}-AR-{q_index:03d}"
        q_index += 1
        
        if subject == "physics":
            assertion = f"Assertion (A): In {chap_name}, the total magnetic or electric flux through a closed surface depends only on enclosed sources."
            reason = "Reason (R): Field lines originate from sources/charges and terminate on sinks, satisfying Gauss divergence condition."
            advice = "Beta, Assertion aur Reason ke beech mein 'BECAUSE' laga kar padho! Agar meaning perfectly complete ho toh Option A choose karo."
        elif subject == "chemistry":
            assertion = f"Assertion (A): In {chap_name}, primary alcohols possess significantly higher boiling points than isomeric ethers."
            reason = "Reason (R): Intermolecular hydrogen bonding exists extensively among alcohol molecules but is absent in ethers."
            advice = "Beta, boiling point questions mein H-bonding keyword likhna compulsory hota hai!"
        else: # maths
            assertion = f"Assertion (A): In {chap_name}, every differentiable function is necessarily continuous."
            reason = "Reason (R): Differentiability implies the existence of a unique tangent with finite limit of incremental ratio."
            advice = "Beta, converse true nahi hota! (Continuous function need not be differentiable, jaise |x| at x=0). Ye examiner trap hai!"

        subject_questions.append({
            "id": qid,
            "subject": subject,
            "chapterId": chap_id,
            "chapterName": chap_name,
            "year": year,
            "board": board,
            "marks": 1,
            "section": "A",
            "format": "ASSERTION_REASON",
            "questionText": "Directions: In the following question, Assertion (A) and Reason (R) are given. Choose the correct option.",
            "assertionText": assertion,
            "reasonText": reason,
            "options": {
                "A": "Both (A) and (R) are true and (R) is the correct explanation of (A).",
                "B": "Both (A) and (R) are true but (R) is not the correct explanation of (A).",
                "C": "(A) is true but (R) is false.",
                "D": "(A) is false but (R) is true.",
            },
            "modelAnswer": "Correct Option: (A)\nBoth Assertion and Reason are correct scientific statements, and Reason correctly explains Assertion.",
            "stepWiseMarking": [
                {"stepDescription": "Option (A) selected with correct logical validation", "marks": "1 Mark"}
            ],
            "examinerTips": ["Check if Reason provides the causal mechanism for Assertion."],
            "guruJiHinglishAdvice": advice
        })

    # --- 3. Very Short Answer VSA (Section B - 2M) ---
    for i in range(vsa_count):
        chap_id, chap_name = chapters[i % len(chapters)]
        year = years[(i + 4) % len(years)]
        board = boards[(i + 2) % len(boards)]
        qid = f"CBSE-{subject[:3].upper()}-{year}-VSA-{q_index:03d}"
        q_index += 1
        
        if subject == "physics":
            q_text = f"Define the term associated with {chap_name} and state its SI unit. Also draw a neat schematic diagram representing the physical concept."
            ans = f"1. Formal Definition: The quantity represents standard physical response per unit field under equilibrium.\n2. SI Unit: Standard SI units with dimensional representation [M^a L^b T^c].\n3. Labeled diagram showing vectors and boundaries."
            advice = "Beta, 2-mark question mein agar diagram pucha ho toh 1 mark definition ka aur 1 mark neat diagram ka hota hai!"
        elif subject == "chemistry":
            q_text = f"State Henry's / Raoult's / Kohlrausch's law related to {chap_name} and write its mathematical equation with meaning of each symbol."
            ans = f"1. Scientific Statement: At constant temperature, the limiting property is directly proportional to concentration/activity.\n2. Mathematical Formula: Formula with all symbols defined explicitly.\n3. One practical application."
            advice = "Beta, law ki definition mein 'at constant temperature' likhna mat bhoolna, nahi toh 1/2 mark cut jayega!"
        else: # maths
            q_text = f"Find the value of k such that the given function in {chap_name} is continuous at x = 0 / find principal value of the given inverse trigonometric expression."
            ans = f"1. Evaluate left-hand limit LHL and right-hand limit RHL.\n2. Equate limit to f(0) = k.\n3. Compute k with exact numeric value."
            advice = "Beta, principal value branch check karna zaroori hai! sin^-1 ka range [-pi/2, pi/2] hota hai aur cos^-1 ka [0, pi] hota hai."

        subject_questions.append({
            "id": qid,
            "subject": subject,
            "chapterId": chap_id,
            "chapterName": chap_name,
            "year": year,
            "board": board,
            "marks": 2,
            "section": "B",
            "format": "VSA",
            "questionText": q_text,
            "modelAnswer": ans,
            "stepWiseMarking": [
                {"stepDescription": "Accurate formal definition / statement", "marks": "1 Mark"},
                {"stepDescription": "Mathematical formula / diagram / final value", "marks": "1 Mark"},
            ],
            "examinerTips": ["State conditions (e.g. constant temperature) and define all variables."],
            "guruJiHinglishAdvice": advice
        })

    # --- 4. Short Answer SA (Section C - 3M) ---
    for i in range(sa_count):
        chap_id, chap_name = chapters[i % len(chapters)]
        year = years[(i + 1) % len(years)]
        board = boards[(i + 3) % len(boards)]
        qid = f"CBSE-{subject[:3].upper()}-{year}-SA-{q_index:03d}"
        q_index += 1
        
        if subject == "physics":
            q_text = f"A numerical problem from {chap_name}: A circuit / optical system operating with given parameters requires calculation of resonant frequency / focal length / stopping potential. Calculate the final value in SI units."
            ans = f"Step 1: Given values listed with standard symbols.\nStep 2: Core formula stated.\nStep 3: Step-by-step arithmetic substitution.\nStep 4: Final answer boxed with correct SI units."
            advice = "Beta, numerical solve karte waqt Given data pehle likho, formula box karo, aur answer mein unit likhna mat bhoolna!"
        elif subject == "chemistry":
            q_text = f"In {chap_name}, give simple chemical tests to distinguish between given organic compounds / calculate emf and Delta G for a given galvanic cell at 298 K."
            ans = f"1. Test name and specific reagent.\n2. Observable difference (color, precipitate, silver mirror, effervescence).\n3. Balanced chemical reaction equation."
            advice = "Beta, distinction test mein observation likhna sabse important hai! Sirf formula likhne se marks nahi milte."
        else: # maths
            q_text = f"Evaluate the integral / solve the linear differential equation dy/dx + P(x)y = Q(x) from {chap_name} with given boundary conditions."
            ans = f"Step 1: Put in standard form dy/dx + Py = Q.\nStep 2: Find Integrating Factor IF = e^(integral P dx).\nStep 3: Solution: y * IF = integral (Q * IF) dx + C.\nStep 4: Find constant C using boundary conditions."
            advice = "Beta, boundary conditions di ho toh constant of integration C nikalna compulsory hota hai!"

        subject_questions.append({
            "id": qid,
            "subject": subject,
            "chapterId": chap_id,
            "chapterName": chap_name,
            "year": year,
            "board": board,
            "marks": 3,
            "section": "C",
            "format": "SA",
            "questionText": q_text,
            "modelAnswer": ans,
            "stepWiseMarking": [
                {"stepDescription": "Stating formula and initial setup", "marks": "1 Mark"},
                {"stepDescription": "Intermediate algebraic / chemical steps", "marks": "1 Mark"},
                {"stepDescription": "Final calculated answer with units / complete observation", "marks": "1 Mark"},
            ],
            "examinerTips": ["Write intermediate steps clearly to secure partial marks even if arithmetic error occurs."],
            "guruJiHinglishAdvice": advice
        })

    # --- 5. Case-Based Questions (Section D - 4M) ---
    for i in range(case_count):
        chap_id, chap_name = chapters[i % len(chapters)]
        year = years[(i + 3) % len(years)]
        board = boards[(i + 4) % len(boards)]
        qid = f"CBSE-{subject[:3].upper()}-{year}-CASE-{q_index:03d}"
        q_index += 1
        
        passage = f"In real-world engineering and laboratory investigations, principles of {chap_name} govern energy transmission, reaction equilibrium, and geometric optimizations. Experimental studies demonstrate high reproducibility when environmental boundary conditions are controlled."
        sub_qs = [
            {"qNumber": "i", "question": f"State the primary physical/chemical law governing {chap_name}.", "marks": 1, "answer": "Law statement with underlying physical principle."},
            {"qNumber": "ii", "question": "Explain the significance of boundary conditions or catalyst activity in this setup.", "marks": 1, "answer": "Significance of temperature, pressure, or spatial constraints."},
            {"qNumber": "iii", "question": "Calculate the numerical value of parameter under stated experimental values.", "marks": 2, "answer": "Step-by-step calculation with formula and units."},
        ]

        subject_questions.append({
            "id": qid,
            "subject": subject,
            "chapterId": chap_id,
            "chapterName": chap_name,
            "year": year,
            "board": board,
            "marks": 4,
            "section": "D",
            "format": "CASE_BASED",
            "questionText": "Read the following case study passage and answer the sub-questions that follow:",
            "casePassage": passage,
            "subQuestions": sub_qs,
            "modelAnswer": "Structured answers for sub-parts (i), (ii), and (iii) as specified above.",
            "stepWiseMarking": [
                {"stepDescription": "Sub-part (i) definition / law", "marks": "1 Mark"},
                {"stepDescription": "Sub-part (ii) explanation / mechanism", "marks": "1 Mark"},
                {"stepDescription": "Sub-part (iii) numerical calculation and substitution", "marks": "2 Marks"},
            ],
            "examinerTips": ["Answer each sub-part with distinct roman numerals (i, ii, iii)."],
            "guruJiHinglishAdvice": "Beta, Case Study 4 marks ka free score hota hai! Direct sub-questions hote hain, passage ko ek baar scan karo aur direct answers point-wise likho."
        })

    # --- 6. Long Answer LA / Derivations (Section E - 5M) ---
    for i in range(la_count):
        chap_id, chap_name = chapters[i % len(chapters)]
        year = years[(i + 5) % len(years)]
        board = boards[(i + 5) % len(boards)]
        qid = f"CBSE-{subject[:3].upper()}-{year}-LA-{q_index:03d}"
        q_index += 1
        
        if subject == "physics":
            q_text = f"(a) Derive the core mathematical expression for {chap_name} using standard physical laws. (b) Draw a neat labeled diagram showing all field/ray vectors. (c) Solve the attached numerical under given parameters."
            ans = f"(a) Statement and physical assumptions.\n(b) Step-by-step mathematical derivation with algebraic substitutions.\n(c) Clear labeled diagram showing all angles, vectors, and boundaries.\n(d) Numerical substitution with final SI unit."
            advice = "Beta, 5-mark derivation mein diagram ke 1.5 marks hote hain! Arrows aur labels saaf-saaf pencil se banana."
        elif subject == "chemistry":
            q_text = f"(a) Describe the step-wise mechanism of named reaction in {chap_name}. (b) Illustrate with balanced chemical equations. (c) Explain why particular side reactions or stereo-inversions occur."
            ans = f"(a) Step 1: Enolate/electrophile generation.\n(b) Step 2: Nucleophilic attack.\n(c) Step 3: Protonation/dehydration.\n(d) Explaining electronic/steric effects."
            advice = "Beta, organic chemistry mechanisms mein curly arrows se electron flow dikhana examiner ko bahut impress karta hai!"
        else: # maths
            q_text = f"Solve the 3-variable system of linear equations using Matrix Inverse Method AX = B / Find the shortest distance between skew lines / Prove King's property and evaluate standard integral from {chap_name}."
            ans = f"Step 1: Write in matrix form AX = B.\nStep 2: Find determinant |A| != 0.\nStep 3: Calculate all 9 cofactors C11 through C33.\nStep 4: Transpose cofactors to form adj(A).\nStep 5: Multiply X = A^(-1) B to obtain final x, y, z values."
            advice = "Beta, matrix method mein cofactors ke baad TRANSPOSE karna mat bhoolna! Aur solve karne ke baad Equation 1 mein check zaroor karna!"

        subject_questions.append({
            "id": qid,
            "subject": subject,
            "chapterId": chap_id,
            "chapterName": chap_name,
            "year": year,
            "board": board,
            "marks": 5,
            "section": "E",
            "format": "LA",
            "questionText": q_text,
            "modelAnswer": ans,
            "stepWiseMarking": [
                {"stepDescription": "Statement / Initial matrix or vector setup", "marks": "1 Mark"},
                {"stepDescription": "Cofactors / Derivation steps / Diagram", "marks": "2 Marks"},
                {"stepDescription": "Adjoint / Proof completion / Final multiplication", "marks": "1 Mark"},
                {"stepDescription": "Final verified answer / units / conclusions", "marks": "1 Mark"},
            ],
            "examinerTips": ["Show every mathematical step; step-marking allocates marks across all 4 stages."],
            "guruJiHinglishAdvice": advice
        })

    return subject_questions

phy_qs = build_questions_for_subject("physics", physics_chapters, 334)
chem_qs = build_questions_for_subject("chemistry", chemistry_chapters, 334)
math_qs = build_questions_for_subject("mathematics", maths_chapters, 334)

total_board_questions = phy_qs + chem_qs + math_qs
print(f"Total Board Questions generated: {len(total_board_questions)}")
print(f"Physics: {len(phy_qs)}, Chemistry: {len(chem_qs)}, Maths: {len(math_qs)}")

# Output to TS file
ts_content = "import { BoardQuestion } from '@/types';\n\n"
ts_content += f"export const TOTAL_BOARD_QUESTIONS_COUNT = {len(total_board_questions)};\n\n"
ts_content += "export const CLASS_12_BOARD_QUESTIONS: BoardQuestion[] = "
ts_content += json.dumps(total_board_questions, indent=2) + ";\n"

with open(output_file, "w", encoding="utf-8") as f:
    f.write(ts_content)

print(f"Successfully wrote {len(total_board_questions)} questions to {output_file}")
