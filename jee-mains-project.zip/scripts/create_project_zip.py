import os
import zipfile

root_dir = os.path.abspath(".")
zip_filename = "jee-mains-project.zip"
zip_path = os.path.join(root_dir, zip_filename)

# Exclude directories
EXCLUDED_DIRS = {
    'node_modules',
    '.next',
    '.git',
    '__pycache__',
    '.agents',
    '.system_generated'
}

# Exclude files
EXCLUDED_FILES = {
    zip_filename,
    '*.tsbuildinfo'
}

print(f"Creating zip file: {zip_path} ...")
file_count = 0

with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as zipf:
    for dirpath, dirnames, filenames in os.walk(root_dir):
        # Modify dirnames in-place to prune excluded directories
        dirnames[:] = [d for d in dirnames if d not in EXCLUDED_DIRS]

        for filename in filenames:
            if filename in EXCLUDED_FILES or filename.endswith('.pyc') or filename == zip_filename:
                continue

            full_path = os.path.join(dirpath, filename)
            rel_path = os.path.relpath(full_path, root_dir)
            
            zipf.write(full_path, rel_path)
            file_count += 1

size_mb = os.path.getsize(zip_path) / (1024 * 1024)
print(f"Done! Successfully created {zip_filename}")
print(f"Total files zipped: {file_count}")
print(f"Compressed archive size: {size_mb:.2f} MB")
print(f"Location: {zip_path}")
