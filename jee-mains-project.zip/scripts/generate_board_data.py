# scripts/generate_board_data.py
import json

output_file = "src/data/boardData.ts"

content = """import { 
  BoardQuestion, 
  BoardDerivationItem, 
  BoardSamplePaper, 
  BoardRevisionNote,
  SubjectType 
} from '@/types';

// Re-export full 1,002 non-repeating authentic board question bank
export { CLASS_12_BOARD_QUESTIONS, TOTAL_BOARD_QUESTIONS_COUNT } from './boardQuestionsData';

// Re-export Chemistry Named Reactions & Reagent Master Guide
export { BOARD_NAMED_REACTIONS, BOARD_REAGENTS_GUIDE } from './boardChemistryData';

// Re-export Maths Tricks & Formulas
export { BOARD_MATH_TRICKS, BOARD_MATH_FORMULAS } from './boardMathsTricksData';

// Re-export Physics Formulas
export { BOARD_PHYSICS_FORMULAS } from './boardPhysicsData';

import { CLASS_12_BOARD_QUESTIONS } from './boardQuestionsData';

export interface BoardChapterInfo {
  id: string;
  subject: SubjectType;
  name: string;
  ncertPart: string;
  boardMarksWeightage: number; // typical marks out of 70/80
  priority: 'HIGH' | 'MEDIUM' | 'LOWER';
  frequentQuestionTypes: string[];
  keyDerivationsOrMechanisms: string[];
  boardExamTips: string;
}

export const CLASS_12_BOARD_CHAPTERS: BoardChapterInfo[] = [
  // ===================== PHYSICS (Total 70 Marks) =====================
  {
    id: 'b-phy-01',
    subject: 'physics',
    name: 'Electric Charges and Fields',
    ncertPart: 'Class 12 Part 1',
    boardMarksWeightage: 6,
    priority: 'HIGH',
    frequentQuestionTypes: ['Gauss Law Derivation (5M)', 'Dipole Field Calculation (3M)', 'Flux MCQ/A-R (1M)'],
    keyDerivationsOrMechanisms: [
      'Field due to infinite wire: E = lambda / (2 pi eps_0 r)',
      'Field due to uniformly charged infinite thin plane sheet: E = sigma / (2 eps_0)',
      'Electric field on axial and equatorial points of dipole',
    ],
    boardExamTips: 'Always draw clear Gaussian surface diagrams with area vectors and charge labels; 1 mark is reserved strictly for diagram correctness.',
  },
  {
    id: 'b-phy-02',
    subject: 'physics',
    name: 'Electrostatic Potential and Capacitance',
    ncertPart: 'Class 12 Part 1',
    boardMarksWeightage: 6,
    priority: 'HIGH',
    frequentQuestionTypes: ['Capacitance with Dielectric Slab (3M)', 'Equipotential Surface properties (2M)', 'Energy loss in sharing charges (3M)'],
    keyDerivationsOrMechanisms: [
      'Capacitance of parallel plate capacitor with dielectric: C = eps_0 A / (d - t + t/K)',
      'Potential energy of system of two charges in external field',
    ],
    boardExamTips: 'Mention boundary conditions when dielectric is inserted. State why equipotential surfaces never intersect.',
  },
  {
    id: 'b-phy-03',
    subject: 'physics',
    name: 'Current Electricity',
    ncertPart: 'Class 12 Part 1',
    boardMarksWeightage: 7,
    priority: 'HIGH',
    frequentQuestionTypes: ['Kirchhoff Laws Circuit Numerical (3M/5M)', 'Drift Velocity Derivation (3M)', 'Wheatstone Bridge Condition (3M)'],
    keyDerivationsOrMechanisms: [
      'Drift speed expression: v_d = e E tau / m and deduction of Ohm law: j = sigma E',
      'Wheatstone bridge balanced condition using Kirchhoff rules: P/Q = R/S',
    ],
    boardExamTips: 'Draw circuit diagrams with clear loop arrows and current directions before applying Kirchhoff voltage loop rule.',
  },
  {
    id: 'b-phy-04',
    subject: 'physics',
    name: 'Moving Charges and Magnetism',
    ncertPart: 'Class 12 Part 1',
    boardMarksWeightage: 6,
    priority: 'HIGH',
    frequentQuestionTypes: ['Biot-Savart Law on Circular Loop Axis (5M)', 'Galvanometer to Ammeter/Voltmeter conversion (3M)'],
    keyDerivationsOrMechanisms: [
      'Magnetic field on axis of circular current loop using Biot-Savart law',
      'Ampere circuital law applied to long solenoid',
      'Force between two parallel current-carrying wires (definition of 1 Ampere)',
    ],
    boardExamTips: 'Remember the formal definition of 1 Ampere (F/l = 2 x 10^-7 N/m); this 1-mark definition frequently appears in Section A/B.',
  },
  {
    id: 'b-phy-05',
    subject: 'physics',
    name: 'Electromagnetic Induction & Alternating Current',
    ncertPart: 'Class 12 Part 1',
    boardMarksWeightage: 9,
    priority: 'HIGH',
    frequentQuestionTypes: ['Series LCR Phasor & Resonance (5M)', 'Transformer Principle & Losses (3M)', 'Motional EMF (3M)'],
    keyDerivationsOrMechanisms: [
      'Impedance of series LCR circuit using phasor diagrams: Z = sqrt(R^2 + (X_L - X_C)^2)',
      'Mutual inductance between two coaxial long solenoids',
      'Transformer formula and power efficiency',
    ],
    boardExamTips: 'Phasor diagrams MUST show correct phase leads/lags: current leads voltage in pure capacitor by pi/2, lags in inductor by pi/2.',
  },
  {
    id: 'b-phy-06',
    subject: 'physics',
    name: 'Optics (Ray & Wave Optics)',
    ncertPart: 'Class 12 Part 2',
    boardMarksWeightage: 14,
    priority: 'HIGH',
    frequentQuestionTypes: ['Lens Maker Formula (5M)', 'Huygens Principle Wavefront Proofs (5M)', 'Astronomical Telescope Diagram (3M)', 'YDSE Fringe Width (3M)'],
    keyDerivationsOrMechanisms: [
      'Refraction at spherical surface and Lens Maker Formula: 1/f = (mu - 1)(1/R1 - 1/R2)',
      'Huygens construction: Proof of laws of reflection and refraction',
      'Prism formula: mu = sin((A + Dm)/2) / sin(A/2)',
      'Ray diagram and magnifying power of astronomical telescope in normal adjustment',
    ],
    boardExamTips: 'Optics is the single largest marks contribution (14 marks) in Board exams. Ray diagrams with arrows indicating light direction are compulsory.',
  },
  {
    id: 'b-phy-07',
    subject: 'physics',
    name: 'Dual Nature of Radiation and Matter',
    ncertPart: 'Class 12 Part 2',
    boardMarksWeightage: 6,
    priority: 'MEDIUM',
    frequentQuestionTypes: ['Einstein Photoelectric Equation (3M)', 'de Broglie Wavelength Graphs (2M)', 'Stopping Potential Characteristics (2M)'],
    keyDerivationsOrMechanisms: [
      'Einstein photoelectric equation: h nu = phi + K_max and explanation of photoelectric laws',
      'de Broglie wavelength: lambda = h / sqrt(2 m q V)',
    ],
    boardExamTips: 'Quote all 4 experimental laws of photoelectric effect when deriving Einstein equation. Graphs of V0 vs nu are heavily tested.',
  },
  {
    id: 'b-phy-08',
    subject: 'physics',
    name: 'Atoms & Nuclei',
    ncertPart: 'Class 12 Part 2',
    boardMarksWeightage: 8,
    priority: 'MEDIUM',
    frequentQuestionTypes: ['Bohr Postulates & Radius/Energy (3M)', 'Nuclear Density & Mass Defect (2M)', 'Binding Energy Curve Features (3M)'],
    keyDerivationsOrMechanisms: [
      'Bohr orbital radius and velocity expressions in hydrogen atom',
      'Proof that nuclear density is independent of mass number A',
    ],
    boardExamTips: 'Draw the Binding Energy per nucleon curve accurately, showing peak at Fe-56 and explaining fission/fusion regions.',
  },
  {
    id: 'b-phy-09',
    subject: 'physics',
    name: 'Semiconductor Electronics',
    ncertPart: 'Class 12 Part 2',
    boardMarksWeightage: 8,
    priority: 'MEDIUM',
    frequentQuestionTypes: ['Full Wave Rectifier Circuit & Waveforms (5M)', 'p-n Junction formation & I-V curves (3M)', 'Energy band diagrams (2M)'],
    keyDerivationsOrMechanisms: [
      'Working of p-n junction diode as full-wave rectifier with input/output waveform diagrams',
      'Depletion layer and potential barrier formation mechanism',
    ],
    boardExamTips: 'Include both circuit diagram and input/output voltage waveforms. Missing waveforms costs 1.5 marks out of 5.',
  },

  // ===================== CHEMISTRY (Total 70 Marks) =====================
  {
    id: 'b-chem-01',
    subject: 'chemistry',
    name: 'Solutions',
    ncertPart: 'Class 12 Part 1',
    boardMarksWeightage: 7,
    priority: 'HIGH',
    frequentQuestionTypes: ['Colligative Numerical (3M)', 'Henry Law & Raoult Law Definition (2M)', 'Van t Hoff Factor (2M)'],
    keyDerivationsOrMechanisms: [
      'Derivation of depression in freezing point and molar mass calculation',
      'Relation between van t Hoff factor i and degree of dissociation alpha',
    ],
    boardExamTips: 'State Henry law and its biological application (scuba divers / bends). Always write final numerical answers with unit (e.g. g/mol).',
  },
  {
    id: 'b-chem-02',
    subject: 'chemistry',
    name: 'Electrochemistry',
    ncertPart: 'Class 12 Part 1',
    boardMarksWeightage: 9,
    priority: 'HIGH',
    frequentQuestionTypes: ['Nernst Equation Numerical (3M/5M)', 'Kohlrausch Law & Applications (3M)', 'Faraday Laws (2M)'],
    keyDerivationsOrMechanisms: [
      'Application of Kohlrausch law to find molar conductance of weak electrolytes at infinite dilution',
      'Relation between E_cell, Gibbs free energy Delta G, and equilibrium constant K',
    ],
    boardExamTips: 'Write half-cell anode (oxidation) and cathode (reduction) equations explicitly before writing overall balanced cell reaction.',
  },
  {
    id: 'b-chem-03',
    subject: 'chemistry',
    name: 'Chemical Kinetics',
    ncertPart: 'Class 12 Part 1',
    boardMarksWeightage: 7,
    priority: 'HIGH',
    frequentQuestionTypes: ['Integrated First Order Rate Equation (3M)', 'Arrhenius Activation Energy Numerical (3M)', 'Order vs Molecularity (2M)'],
    keyDerivationsOrMechanisms: [
      'Integration of first order rate equation: k = (2.303/t) log([A]0/[A]t) and half-life',
      'Arrhenius equation and determination of activation energy',
    ],
    boardExamTips: 'Tabulate differences between Order (experimental, can be fractional/zero) and Molecularity (theoretical, whole number only).',
  },
  {
    id: 'b-chem-04',
    subject: 'chemistry',
    name: 'd- and f-Block Elements',
    ncertPart: 'Class 12 Part 1',
    boardMarksWeightage: 7,
    priority: 'HIGH',
    frequentQuestionTypes: ['Reasoning Questions (Colored ions, catalytic behavior) (3M)', 'KMnO4/K2Cr2O7 Equations (3M)', 'Lanthanoid Contraction (2M)'],
    keyDerivationsOrMechanisms: [
      'Consequences of Lanthanoid Contraction (Zr/Hf similarity, basicity of hydroxides)',
      'Balancing redox reactions of acidic KMnO4 and K2Cr2O7 with oxalate, Fe2+, I-',
    ],
    boardExamTips: 'Chemical reasoning answers should contain explicit keywords: e.g. "due to d-d transition", "unpaired electrons", "poor shielding of 4f electrons".',
  },
  {
    id: 'b-chem-05',
    subject: 'chemistry',
    name: 'Coordination Compounds',
    ncertPart: 'Class 12 Part 1',
    boardMarksWeightage: 7,
    priority: 'HIGH',
    frequentQuestionTypes: ['IUPAC Nomenclature (2M)', 'CFT Splitting Diagram & Magnetic Moment (3M)', 'Isomerism Types (2M)'],
    keyDerivationsOrMechanisms: [
      'Crystal field splitting in octahedral and tetrahedral complexes',
      'Valence bond theory hybridization and geometry prediction',
    ],
    boardExamTips: 'Draw the d-orbital splitting diagram with t2g and eg labels and Delta_o energy spacing.',
  },
  {
    id: 'b-chem-06',
    subject: 'chemistry',
    name: 'Haloalkanes and Haloarenes',
    ncertPart: 'Class 12 Part 2',
    boardMarksWeightage: 6,
    priority: 'MEDIUM',
    frequentQuestionTypes: ['SN1 vs SN2 Mechanism & Stereochemistry (3M)', 'Reasoning: Why haloarenes are less reactive (2M)', 'Chemical Conversions (3M)'],
    keyDerivationsOrMechanisms: [
      'Step-wise mechanism of SN1 (carbocation intermediate) and SN2 (Walden inversion)',
      'Reasoning for low reactivity of chlorobenzene towards nucleophilic substitution',
    ],
    boardExamTips: 'Draw transition state with dotted partial bonds in SN2 mechanism; show planar carbocation intermediate in SN1.',
  },
  {
    id: 'b-chem-07',
    subject: 'chemistry',
    name: 'Alcohols, Phenols and Ethers',
    ncertPart: 'Class 12 Part 2',
    boardMarksWeightage: 6,
    priority: 'HIGH',
    frequentQuestionTypes: ['Reimer-Tiemann & Kolbe Reactions (3M)', 'Acid catalyzed dehydration mechanism (3M)', 'Williamson Synthesis (2M)'],
    keyDerivationsOrMechanisms: [
      'Mechanism of acid catalyzed hydration of ethene to ethanol and reverse dehydration',
      'Preparation of salicylic acid via Kolbe reaction and salicylaldehyde via Reimer-Tiemann',
    ],
    boardExamTips: 'Give reagents and temperatures clearly: Kolbe reaction uses CO2 + NaOH at 4-7 atm, 400 K.',
  },
  {
    id: 'b-chem-08',
    subject: 'chemistry',
    name: 'Aldehydes, Ketones and Carboxylic Acids',
    ncertPart: 'Class 12 Part 2',
    boardMarksWeightage: 8,
    priority: 'HIGH',
    frequentQuestionTypes: ['Aldol & Cannizzaro Reactions (3M/5M)', 'Chemical tests to distinguish pairs (2M)', 'Nucleophilic addition mechanism (3M)'],
    keyDerivationsOrMechanisms: [
      'Mechanism of nucleophilic addition to carbonyl group (HCN or NaHSO3)',
      'Cross-aldol condensation and self-aldol products',
    ],
    boardExamTips: 'Distinction tests must state reagent, observation, and balanced reaction (e.g. Tollens test produces silver mirror).',
  },
  {
    id: 'b-chem-09',
    subject: 'chemistry',
    name: 'Amines & Diazonium Salts',
    ncertPart: 'Class 12 Part 2',
    boardMarksWeightage: 6,
    priority: 'MEDIUM',
    frequentQuestionTypes: ['Basicity Order Comparison in Aqueous Solution (3M)', 'Hofmann Bromamide & Carbylamine Reactions (3M)', 'Hinsberg Test (2M)'],
    keyDerivationsOrMechanisms: [
      'Explanation of basicity order: (CH3)2NH > CH3NH2 > (CH3)3N > NH3 (steric + solvation + inductive)',
      'Synthesis of primary amines via Gabriel Phthalimide and Hofmann Bromamide degradation',
    ],
    boardExamTips: 'State why aromatic primary amines cannot be prepared by Gabriel Phthalimide synthesis (aryl halides do not undergo nucleophilic substitution).',
  },
  {
    id: 'b-chem-10',
    subject: 'chemistry',
    name: 'Biomolecules',
    ncertPart: 'Class 12 Part 2',
    boardMarksWeightage: 7,
    priority: 'MEDIUM',
    frequentQuestionTypes: ['Structures of Glucose & Fructose (3M)', 'Denaturation of Proteins (2M)', 'Peptide linkage & Zwitterion (2M)', 'DNA vs RNA differences (2M)'],
    keyDerivationsOrMechanisms: [
      'Haworth projection of alpha-D-glucopyranose and beta-D-glucopyranose',
      'Structural levels of proteins (primary, secondary alpha-helix/beta-pleated, tertiary, quaternary)',
    ],
    boardExamTips: 'Define Denaturation: Loss of biological activity when secondary and tertiary structures are disrupted by heat/pH change, leaving primary structure intact.',
  },

  // ===================== MATHEMATICS (Total 80 Marks) =====================
  {
    id: 'b-math-01',
    subject: 'mathematics',
    name: 'Relations and Functions & Inverse Trigonometry',
    ncertPart: 'Class 12 Part 1',
    boardMarksWeightage: 8,
    priority: 'MEDIUM',
    frequentQuestionTypes: ['Equivalence Relation Proof (3M/5M)', 'Bijective Function Proof (3M)', 'Principal Value of ITF (2M)'],
    keyDerivationsOrMechanisms: [
      'Proving Reflexive, Symmetric, and Transitive conditions for equivalence',
      'Showing f(x1) = f(x2) => x1 = x2 (one-one) and finding pre-image for all y (onto)',
    ],
    boardExamTips: 'Always check if the principal value branch is respected when simplifying inverse trigonometric expressions.',
  },
  {
    id: 'b-math-02',
    subject: 'mathematics',
    name: 'Matrices and Determinants',
    ncertPart: 'Class 12 Part 1',
    boardMarksWeightage: 10,
    priority: 'HIGH',
    frequentQuestionTypes: ['Matrix Method AX = B System of 3 Equations (5M Guaranteed)', 'Inverse by Adjoint Method (3M)', 'Properties proof (3M)'],
    keyDerivationsOrMechanisms: [
      'Solving 3-variable linear system using X = A^(-1) B where A^(-1) = adj(A) / |A|',
      'Adjoint matrix derivation and verification that A adj(A) = |A| I',
    ],
    boardExamTips: 'The 5-mark matrix method question appears in 95% of board exams. Double check determinant calculation to prevent carrying errors.',
  },
  {
    id: 'b-math-03',
    subject: 'mathematics',
    name: 'Continuity, Differentiability & Applications of Derivatives',
    ncertPart: 'Class 12 Part 1',
    boardMarksWeightage: 14,
    priority: 'HIGH',
    frequentQuestionTypes: ['Continuity k-value problem (3M)', 'Second order derivative d2y/dx2 proof (5M)', 'Maximas/Minimas Word Problem (5M)', 'Increasing/Decreasing Intervals (3M)'],
    keyDerivationsOrMechanisms: [
      'Proving second order derivative differential equations like (1 - x^2) y2 - x y1 + m^2 y = 0',
      'Optimization word problem (surface area of cylinder, box with minimum cost)',
    ],
    boardExamTips: 'In maxima/minima word problems, 1 mark is dedicated to showing d2y/dx2 < 0 (for maximum) or > 0 (for minimum). Never skip the second derivative test!',
  },
  {
    id: 'b-math-04',
    subject: 'mathematics',
    name: 'Integrals & Applications of the Integrals',
    ncertPart: 'Class 12 Part 2',
    boardMarksWeightage: 15,
    priority: 'HIGH',
    frequentQuestionTypes: ['Definite Integral King Property Proof (5M)', 'Area under simple curves (5M)', 'Integration by partial fractions / by parts (3M)'],
    keyDerivationsOrMechanisms: [
      'Evaluation of standard integral: integral 0 to pi/2 of log(sin x) dx = -pi/2 log 2',
      'Area bounded by parabola and straight line with sketches',
    ],
    boardExamTips: 'Draw a neat labeled sketch of the region with points of intersection. The diagram carries 1 mark out of 5.',
  },
  {
    id: 'b-math-05',
    subject: 'mathematics',
    name: 'Differential Equations',
    ncertPart: 'Class 12 Part 2',
    boardMarksWeightage: 8,
    priority: 'HIGH',
    frequentQuestionTypes: ['Linear Differential Equation dy/dx + Py = Q (5M)', 'Homogeneous equation y = vx (3M)', 'Separation of variables (2M)'],
    keyDerivationsOrMechanisms: [
      'Integrating factor method for linear differential equation: IF = e^(integral P dx)',
      'Particular solution calculation with given initial values x = x0, y = y0',
    ],
    boardExamTips: 'Always determine the constant of integration C when initial boundary values are given.',
  },
  {
    id: 'b-math-06',
    subject: 'mathematics',
    name: 'Vectors and Three-Dimensional Geometry (Lines)',
    ncertPart: 'Class 12 Part 2',
    boardMarksWeightage: 14,
    priority: 'HIGH',
    frequentQuestionTypes: ['Shortest Distance between Skew Lines (5M)', 'Foot of Perpendicular & Image in a Line (5M)', 'Vector dot & cross properties (3M)'],
    keyDerivationsOrMechanisms: [
      'Derivation and vector formula for shortest distance between two skew lines',
      'Equation of line passing through two given points or one point and parallel to vector',
    ],
    boardExamTips: 'Write vector and Cartesian forms clearly. Remember planes are excluded from the current syllabus.',
  },
  {
    id: 'b-math-07',
    subject: 'mathematics',
    name: 'Probability',
    ncertPart: 'Class 12 Part 2',
    boardMarksWeightage: 8,
    priority: 'HIGH',
    frequentQuestionTypes: ['Bayes Theorem Word Problem (5M)', 'Conditional Probability (3M)', 'Independent events multiplication theorem (2M)'],
    keyDerivationsOrMechanisms: [
      'Proof and application of Bayes theorem: P(E_i | A) = P(E_i)P(A|E_i) / Sigma P(E_k)P(A|E_k)',
    ],
    boardExamTips: 'Clearly define the events: E1, E2, E3 (hypotheses) and A (observed event) before writing Bayes formula.',
  },
];

// ===================== CORE 12TH BOARD DERIVATIONS & MECHANISMS DIRECTORY =====================
export const BOARD_DERIVATIONS_DIRECTORY: BoardDerivationItem[] = [
  {
    id: 'der-phy-01',
    subject: 'physics',
    chapterName: 'Ray Optics and Optical Instruments',
    title: "Lens Maker's Formula Derivation",
    expectedMarks: 5,
    recurrenceFrequency: 'Asked in CBSE 2024, 2023, 2020, 2019, 2018 (All India & Delhi)',
    statement: 'Derive the Lens Maker formula 1/f = (mu - 1)(1/R1 - 1/R2) for a thin convex lens having radii of curvature R1 and R2 made of refractive index mu placed in air.',
    diagramDescription: 'Double convex lens with centers of curvature C1, C2, point object O on principal axis, intermediate image I1 formed by first surface, final image I formed by second surface.',
    stepByStepProof: [
      'Refraction at first surface (radius R1): Applying spherical refraction formula mu2/v - mu1/u = (mu2 - mu1)/R, with light going from air (1) to glass (mu): mu/v1 - 1/u = (mu - 1)/R1  ... (Equation 1).',
      'Refraction at second surface (radius R2): Virtual object I1 forms real image I. Light goes from glass (mu) to air (1): 1/v - mu/v1 = (1 - mu)/R2 = -(mu - 1)/R2 ... (Equation 2).',
      'Adding Equation (1) and Equation (2): (mu/v1 - 1/u) + (1/v - mu/v1) = (mu - 1)[1/R1 - 1/R2].',
      'Cancelling intermediate term mu/v1 gives: 1/v - 1/u = (mu - 1)[1/R1 - 1/R2].',
      'When object is at infinity (u = -infinity), image is formed at focus (v = f). Hence 1/v - 1/u = 1/f.',
      'Therefore, 1/f = (mu - 1)(1/R1 - 1/R2). Hence proved.',
    ],
    finalFormula: '\\\\frac{1}{f} = (\\\\mu - 1)\\\\left(\\\\frac{1}{R_1} - \\\\frac{1}{R_2}\\\\right)',
    boardPresentationTips: 'Examiner checks for: (1) Labeled ray diagram with arrows [1 Mark], (2) Surface 1 refraction equation [1 Mark], (3) Surface 2 refraction equation [1 Mark], (4) Algebraic addition and substitution of 1/f [2 Marks].',
    guruMantraHinglish: 'Beta, board examiner ke paas standard marking scheme hoti hai! Agar ray diagram mein arrows bhool gaye toh seedha 1 mark cut ho jayega. Surface 2 par light glass se air mein jaa rahi hai, isliye 1/v - mu/v1 likhna mat bhoolna!',
  },
  {
    id: 'der-phy-02',
    subject: 'physics',
    chapterName: 'Wave Optics',
    title: "Proof of Laws of Refraction Using Huygens' Principle",
    expectedMarks: 5,
    recurrenceFrequency: 'Asked in CBSE 2024, 2022, 2020, 2017, 2015',
    statement: "Using Huygens principle and secondary wavelets construction, verify Snell's law of refraction sin(i)/sin(r) = v1/v2 = mu2/mu1 for a plane wavefront incident on a plane refracting boundary.",
    diagramDescription: 'Plane wavefront AB incident at angle i on interface XY separating media 1 (speed v1) and 2 (speed v2). Secondary wavelet from B reaches C in time tau; wavelet from A expands into sphere of radius v2*tau.',
    stepByStepProof: [
      'Let a plane wavefront AB be incident at angle i on a plane refracting surface XY separating rarer medium 1 and denser medium 2.',
      'Let v1 and v2 be speeds of light in medium 1 and 2 respectively. In time tau taken by point B to reach C, distance BC = v1 tau.',
      'During this time tau, secondary wavelet from point A spreads in medium 2 over a hemisphere of radius AD = v2 tau.',
      'Tangential plane CD drawn from point C represents the refracted wavefront. Angle of refraction is r, where angle ACD = r.',
      'In right triangle ABC: sin(i) = BC / AC = (v1 tau) / AC.',
      'In right triangle ADC: sin(r) = AD / AC = (v2 tau) / AC.',
      'Dividing sin(i) by sin(r): sin(i)/sin(r) = [(v1 tau)/AC] / [(v2 tau)/AC] = v1 / v2.',
      'Since refractive index mu1 = c/v1 and mu2 = c/v2, v1/v2 = mu2/mu1 = 1_mu_2. Hence sin(i)/sin(r) = mu2/mu1 = constant (Snells Law).',
    ],
    finalFormula: '\\\\frac{\\\\sin i}{\\\\sin r} = \\\\frac{v_1}{v_2} = \\\\frac{\\\\mu_2}{\\\\mu_1}',
    boardPresentationTips: 'Define secondary wavelets in 1 line. Draw triangles ABC and ADC neatly showing common hypotenuse AC. Box Snell law at the end.',
    guruMantraHinglish: 'Beta, is derivation mein sabse ahem point hai right triangles ABC aur ADC ko identify karna. Dono ka common hypotenuse AC hota hai jo divide karte hi cancel ho jaata hai!',
  },
  {
    id: 'der-phy-03',
    subject: 'physics',
    chapterName: 'Electromagnetic Induction & Alternating Current',
    title: 'Series LCR Circuit: Phasor Diagram & Impedance Derivation',
    expectedMarks: 5,
    recurrenceFrequency: 'Asked in CBSE 2024, 2023, 2021, 2019, 2016',
    statement: 'Derive an expression for the impedance Z and phase angle phi of a series LCR circuit connected to an AC source V = V0 sin(omega t) using phasor diagram method. What is the resonance condition?',
    diagramDescription: 'Phasor diagram showing current phasor I0 along x-axis, resistor voltage VR in phase, inductor voltage VL leading by 90 degrees, capacitor voltage VC lagging by 90 degrees.',
    stepByStepProof: [
      'Let alternating current in series LCR circuit be I = I0 sin(omega t). Since elements are in series, current is identical in all components.',
      'Voltage amplitudes: V_R = I0 R (in phase with I), V_L = I0 X_L (leads I by pi/2), V_C = I0 X_C (lags I by pi/2).',
      'Net reactive voltage along y-axis is (V_L - V_C) assuming V_L > V_C.',
      'Resultant source voltage V0 is hypotenuse of right triangle with base V_R and altitude (V_L - V_C): V0^2 = V_R^2 + (V_L - V_C)^2.',
      'Substitute V_R = I0 R, V_L = I0 X_L, V_C = I0 X_C: V0^2 = I0^2 [ R^2 + (X_L - X_C)^2 ].',
      'Hence, V0 = I0 * sqrt[ R^2 + (X_L - X_C)^2 ]. The impedance Z is defined as V0 / I0 = sqrt[ R^2 + (omega L - 1/(omega C))^2 ].',
      'Phase angle phi: tan(phi) = (V_L - V_C) / V_R = (X_L - X_C) / R.',
      'Resonance occurs when X_L = X_C => omega L = 1 / (omega C) => omega_r = 1 / sqrt(LC). At resonance, Z = R (minimum), current is maximum and in phase with voltage.',
    ],
    finalFormula: 'Z = \\\\sqrt{R^2 + (X_L - X_C)^2},\\\\quad \\\\omega_r = \\\\frac{1}{\\\\sqrt{LC}}',
    boardPresentationTips: 'Phasor diagram is mandatory [1.5 Marks]. Show vector sum of VR and (VL - VC). Explicitly state the condition for resonance and graph of I vs omega.',
    guruMantraHinglish: 'Beta, LCR derivation mein 80% bacche phasor diagram mein arrow direction galat bana dete hain! VL ko hamesha upar (+y axis), VC ko neeche (-y axis), aur VR ko horizontal (+x axis) banana. Resultant hypotenuse banega!',
  },
  {
    id: 'der-phy-04',
    subject: 'physics',
    chapterName: 'Current Electricity',
    title: "Drift Velocity Expression and Deduction of Ohm's Law",
    expectedMarks: 3,
    recurrenceFrequency: 'Asked in CBSE 2024, 2023, 2022, 2018',
    statement: "Define drift velocity. Derive an expression for drift velocity of free electrons in a conductor and hence deduce Ohm's law in microscopic form j = sigma E.",
    stepByStepProof: [
      'Definition: Drift velocity is defined as the average velocity with which free electrons in a conductor get drifted towards the positive terminal under the influence of an external electric field.',
      'Under electric field E, force on each electron is F = -e E. Acceleration a = -e E / m.',
      'Let tau be the average relaxation time between successive collisions. Average drift velocity: v_d = 0 + a tau = -(e E / m) tau. In magnitude: v_d = (e E tau) / m.',
      'Electric current I = n A e v_d. Substituting v_d: I = n A e * [(e E tau) / m] = (n e^2 A tau / m) E.',
      'Current density j = I / A = (n e^2 tau / m) E. Since sigma = n e^2 tau / m (conductivity), j = sigma E, which is the microscopic form of Ohm law.',
    ],
    finalFormula: 'v_d = \\\\frac{e E \\\\tau}{m},\\\\quad \\\\sigma = \\\\frac{n e^2 \\\\tau}{m}',
    boardPresentationTips: 'Clearly state what each symbol represents: n is electron number density, tau is relaxation time, m is mass of electron.',
    guruMantraHinglish: 'Beta, "relaxation time" ki definition hamesha 1 mark mein puchte hain: average time elapsed between two successive collisions of an electron. Isko bilkul rat lo!',
  },
  {
    id: 'der-chem-01',
    subject: 'chemistry',
    chapterName: 'Aldehydes, Ketones and Carboxylic Acids',
    title: 'Aldol Condensation & Cross-Aldol Mechanism',
    expectedMarks: 5,
    recurrenceFrequency: 'Asked in CBSE 2024, 2023, 2020, 2019 (All India & Delhi)',
    statement: 'Describe the complete step-wise mechanism of Aldol condensation of acetaldehyde in dilute NaOH followed by dehydration to produce but-2-enal. What are the 4 products formed in Cross-Aldol between ethanal and propanal?',
    stepByStepProof: [
      'Step 1 (Deprotonation): The base OH- abstracts an acidic alpha-hydrogen from CH3CHO to form resonance-stabilized enolate ion [:CH2-CHO <-> CH2=CH-O-].',
      'Step 2 (Nucleophilic Attack): The enolate ion attacks the electrophilic carbonyl carbon of a second acetaldehyde molecule to form an alkoxide intermediate.',
      'Step 3 (Protonation): The alkoxide abstracts a proton from H2O to regenerate OH- catalyst and yield 3-hydroxybutanal (aldol).',
      'Step 4 (Dehydration): On heating in presence of trace acid or base, loss of water yields alpha,beta-unsaturated aldehyde: but-2-enal (crotonaldehyde: CH3-CH=CH-CHO).',
      'Cross-Aldol of ethanal + propanal yields 4 products: (1) But-2-enal (self), (2) 2-Methylpent-2-enal (self), (3) 2-Methylbut-2-enal (cross), (4) Pent-2-enal (cross).',
    ],
    finalFormula: '2\\\\,\\\\text{CH}_3\\\\text{CHO} \\\\xrightarrow{\\\\text{dil. NaOH}} \\\\text{CH}_3\\\\text{CH(OH)CH}_2\\\\text{CHO} \\\\xrightarrow{\\\\Delta, -\\\\text{H}_2\\\\text{O}} \\\\text{CH}_3\\\\text{CH}=\\\\text{CHCHO}',
    boardPresentationTips: 'Write all 4 cross-aldol products clearly with IUPAC names. Mention why presence of alpha-hydrogen is strictly required.',
    guruMantraHinglish: 'Beta, agar cross-aldol ka question aaye toh formula yaad rakhna: Dono molecule pehle khud se react karenge (2 self-aldol products), phir ek dusre par attack karenge (2 cross-aldol products). Total 4 products bante hain!',
  },
  {
    id: 'der-chem-02',
    subject: 'chemistry',
    chapterName: 'Chemical Kinetics',
    title: 'Integrated Rate Equation for First Order Reactions & Half-Life',
    expectedMarks: 3,
    recurrenceFrequency: 'Asked in CBSE 2024, 2023, 2022, 2019, 2017',
    statement: 'Derive the integrated rate equation for a first order chemical reaction R -> P. Show that the half-life period t1/2 is independent of initial concentration [R]0.',
    stepByStepProof: [
      'For a first order reaction R -> P, differential rate law is: Rate = -d[R]/dt = k [R].',
      'Separating variables: d[R] / [R] = -k dt.',
      'Integrating both sides: ln [R] = -k t + I, where I is integration constant.',
      'At t = 0, [R] = [R]0 => ln [R]0 = 0 + I => I = ln [R]0.',
      'Substitute I back: ln [R] = -k t + ln [R]0 => ln([R] / [R]0) = -k t => k = (1/t) ln([R]0 / [R]).',
      'Converting to common logarithm (base 10): k = (2.303 / t) * log10([R]0 / [R]).',
      'Half-life condition: At t = t1/2, [R] = [R]0 / 2. Substitute: t1/2 = (2.303 / k) * log10(2) = (2.303 * 0.3010) / k = 0.693 / k.',
      'Since [R]0 does not appear in t1/2 = 0.693 / k, half-life of a first order reaction is completely independent of initial reactant concentration.',
    ],
    finalFormula: 'k = \\\\frac{2.303}{t} \\\\log\\\\left(\\\\frac{[R]_0}{[R]}\\\\right),\\\\quad t_{1/2} = \\\\frac{0.693}{k}',
    boardPresentationTips: 'Show boundary condition at t = 0 explicitly. Do not skip log conversion factor 2.303.',
    guruMantraHinglish: 'Beta, numerical solve karte waqt agar question bole "Show that time taken for 99.9% completion is 10 times t1/2", toh isi equation mein [R] = 0.001 [R]0 rakhna, seedha ratio 10 aa jayega!',
  },
  {
    id: 'der-chem-03',
    subject: 'chemistry',
    chapterName: 'Alcohols, Phenols and Ethers',
    title: 'Acid-Catalysed Dehydration of Ethanol to Ethene Mechanism',
    expectedMarks: 3,
    recurrenceFrequency: 'Asked in CBSE 2024, 2020, 2018, 2016',
    statement: 'Write the step-by-step mechanism of the acid-catalysed dehydration of ethanol to ethene at 443 K. Explain what happens at 413 K.',
    stepByStepProof: [
      'At 443 K in concentrated H2SO4, dehydration yields ethene via the following 3 steps:',
      'Step 1 (Protonation of Alcohol): CH3CH2OH + H+ <-> CH3CH2-O+H2 (ethyl oxonium ion). This fast step creates a good leaving group (H2O).',
      'Step 2 (Formation of Carbocation): CH3CH2-O+H2 -> CH3-CH2+ + H2O. This is the slow and rate-determining step (RDS).',
      'Step 3 (Elimination of Proton): CH3-CH2+ -> CH2=CH2 + H+ (ethene). Base (:OH2 or HSO4-) abstracts a beta-proton to regenerate the acid catalyst.',
      'Temperature sensitivity: At lower temperature (413 K), protonated ethanol undergoes nucleophilic attack by unprotonated ethanol to yield Diethyl Ether (CH3CH2-O-CH2CH3) via SN2 mechanism instead of alkene elimination.',
    ],
    finalFormula: '\\\\text{CH}_3\\\\text{CH}_2\\\\text{OH} \\\\xrightarrow{443\\\\text{ K, }\\\\text{H}_2\\\\text{SO}_4} \\\\text{CH}_2=\\\\text{CH}_2 + \\\\text{H}_2\\\\text{O}',
    boardPresentationTips: 'Mention temperature prominently: 443 K gives ethene, 413 K gives ethoxyethane (ether). Indicate RDS in Step 2.',
    guruMantraHinglish: 'Beta, CBSE board exam mein temperature trap 100% poochte hain! Agar 443 K likha ho toh alkene banana, agar 413 K likha ho toh ether banana. Temperature dhyan se padhna!',
  },
  {
    id: 'der-math-01',
    subject: 'mathematics',
    chapterName: 'Matrices and Determinants',
    title: 'Solving System of 3 Linear Equations by Matrix Method (AX = B)',
    expectedMarks: 5,
    recurrenceFrequency: '100% Guaranteed 5-Marker in CBSE Board Examination',
    statement: 'Explain the complete step-by-step method to solve a system of 3 linear equations a1 x + b1 y + c1 z = d1, a2 x + b2 y + c2 z = d2, a3 x + b3 y + c3 z = d3 using Matrix Inverse Method.',
    stepByStepProof: [
      'Step 1: Express the given system in matrix form AX = B, where A = [[a1, b1, c1], [a2, b2, c2], [a3, b3, c3]], X = [x, y, z]^T, and B = [d1, d2, d3]^T.',
      'Step 2: Calculate the determinant |A|. Verify that |A| != 0 (Matrix A is non-singular, ensuring unique solution exists).',
      'Step 3: Calculate the 9 cofactors C_ij = (-1)^(i+j) M_ij for each element of matrix A.',
      'Step 4: Form the matrix of cofactors and take its transpose to obtain adjoint: adj(A) = [C_ij]^T.',
      'Step 5: Compute inverse: A^(-1) = (1 / |A|) adj(A).',
      'Step 6: Pre-multiply AX = B by A^(-1): X = A^(-1) B. Multiply matrix A^(-1) by column vector B to obtain x, y, z values.',
      'Step 7: Verification check: Substitute x, y, z back into Equation 1 to ensure 100% correctness.',
    ],
    finalFormula: 'X = A^{-1} B = \\\\frac{1}{|A|} \\\\text{adj}(A) \\\\cdot B',
    boardPresentationTips: 'Write all 9 cofactors explicitly step-by-step; board marking scheme awards 1.5 marks solely for cofactors, 0.5 for |A|, 1 for adj(A), and 2 for final matrix multiplication.',
    guruMantraHinglish: 'Beta, ye 5 marks aapke pocket mein hain! Bas ek baat ka dhyan rakhna: cofactors likhne ke baad jab adj(A) banao, toh TRANSPOSE karna mat bhoolna. 70% bacche transpose bhool jaate hain aur 2 marks loose karte hain!',
  },
  {
    id: 'der-math-02',
    subject: 'mathematics',
    chapterName: 'Vectors and Three-Dimensional Geometry',
    title: 'Shortest Distance Between Two Skew Lines Derivation & Vector Formula',
    expectedMarks: 5,
    recurrenceFrequency: 'Guaranteed 5-Marker in CBSE 2024, 2023, 2020, 2019',
    statement: 'Derive the formula for shortest distance between two skew lines r = a1 + lambda b1 and r = a2 + mu b2 in vector form.',
    stepByStepProof: [
      'Let L1 be line passing through A with position vector a1 and parallel to b1.',
      'Let L2 be line passing through B with position vector a2 and parallel to b2.',
      'The shortest distance vector d is perpendicular to both line L1 and line L2.',
      'A vector perpendicular to both b1 and b2 is given by their cross product: n_cap = (b1 x b2) / |b1 x b2|.',
      'The shortest distance d is the scalar projection of vector AB = (a2 - a1) onto this common unit perpendicular vector n_cap.',
      'Projection formula: d = | AB . n_cap | = | (a2 - a1) . (b1 x b2) | / | b1 x b2 |.',
      'Condition for coplanarity / intersecting lines: If shortest distance d = 0, lines intersect: (a2 - a1) . (b1 x b2) = 0.',
    ],
    finalFormula: 'd = \\\\frac{|(\\\\vec{a}_2 - \\\\vec{a}_1) \\\\cdot (\\\\vec{b}_1 \\\\times \\\\vec{b}_2)|}{|\\\\vec{b}_1 \\\\times \\\\vec{b}_2|}',
    boardPresentationTips: 'State lines are skew (neither parallel nor intersecting). Write vector (a2 - a1) and cross product determinant explicitly.',
    guruMantraHinglish: 'Beta, cross product b1 x b2 nikaalne ke baad uska magnitude |b1 x b2| denominator mein likhna hota hai. Dot product ka numerator agar negative aaye toh modulus laga ke positive likhna, distance hamesha positive hoti hai!',
  },
  {
    id: 'der-math-03',
    subject: 'mathematics',
    chapterName: 'Integrals & Applications of the Integrals',
    title: 'Definite Integral King Property & Proof of Integral log(sin x) dx',
    expectedMarks: 5,
    recurrenceFrequency: 'Asked in CBSE 2024, 2023, 2019, 2018, 2015',
    statement: 'Prove the property integral_a^b f(x) dx = integral_a^b f(a + b - x) dx. Hence evaluate integral_0^(pi/2) log(sin x) dx.',
    stepByStepProof: [
      'Part 1: Proof of Property: In integral_a^b f(x) dx, substitute t = a + b - x => dt = -dx => dx = -dt.',
      'When x = a, t = b; when x = b, t = a.',
      'Integral becomes: integral_b^a f(a + b - t) (-dt) = integral_a^b f(a + b - t) dt.',
      'By dummy variable property, replacing t with x gives integral_a^b f(a + b - x) dx. Hence proved.',
      'Part 2: Let I = integral_0^(pi/2) log(sin x) dx ... (1).',
      'Using property with a=0, b=pi/2: I = integral_0^(pi/2) log(sin(pi/2 - x)) dx = integral_0^(pi/2) log(cos x) dx ... (2).',
      'Adding (1) and (2): 2I = integral_0^(pi/2) [log(sin x) + log(cos x)] dx = integral_0^(pi/2) log(sin x cos x) dx.',
      '2I = integral_0^(pi/2) log((sin 2x) / 2) dx = integral_0^(pi/2) log(sin 2x) dx - integral_0^(pi/2) log 2 dx.',
      'In first integral, put 2x = theta => dx = d theta / 2. Limits become 0 to pi. Integral = (1/2) * 2 * integral_0^(pi/2) log(sin theta) d theta = I.',
      'Thus: 2I = I - (pi/2) log 2 => I = -(pi/2) log 2 = (pi/2) log(1/2).',
    ],
    finalFormula: '\\\\int_0^{\\\\pi/2} \\\\log(\\\\sin x)\\\\,dx = -\\\\frac{\\\\pi}{2}\\\\log 2',
    boardPresentationTips: 'Part 1 (Property proof) carries 2 marks; Part 2 (Evaluation) carries 3 marks. Show substitution 2x = theta carefully.',
    guruMantraHinglish: 'Beta, ye integral calculus ka sabse prestigious 5-marker hai! Adding equation 1 and 2 ke baad log(sin 2x) mein limits 0 to pi se 0 to pi/2 convert karte waqt property integral_0^(2a) f(x)dx = 2 integral_0^a f(x)dx lagti hai, isko mention karna compulsory hai!',
  },
];

// ===================== CLASS 12 BOARD REVISION NOTES =====================
export const CLASS_12_BOARD_NOTES: BoardRevisionNote[] = [
  {
    chapterId: 'b-phy-01',
    chapterName: 'Electric Charges and Fields',
    subject: 'physics',
    marksWeightage: 6,
    ncertKeyDefinitions: [
      {
        term: 'Quantization of Charge',
        definition: 'Electric charge is always an integral multiple of elementary charge e: q = n e, where n is an integer.',
        formulaOrLaw: 'q = \\\\pm n e',
      },
      {
        term: "Coulomb's Law",
        definition: 'The electrostatic force between two stationary point charges is directly proportional to product of charges and inversely proportional to square of distance between them.',
        formulaOrLaw: 'F = \\\\frac{1}{4\\\\pi \\\\varepsilon_0} \\\\frac{|q_1 q_2|}{r^2}',
      },
      {
        term: "Gauss's Law",
        definition: 'Total electric flux through any closed surface is equal to 1/epsilon_0 times the net charge enclosed by the surface.',
        formulaOrLaw: '\\\\oint \\\\vec{E} \\\\cdot d\\\\vec{A} = \\\\frac{q_{\\\\text{enclosed}}}{\\\\varepsilon_0}',
      },
    ],
    guaranteedQuestions: [
      'State Gauss law and derive field due to an infinite straight wire of charge density lambda (5M)',
      'Derive electric field on the axial or equatorial line of an electric dipole (3M)',
      'Calculate flux through cube faces when charge is at center / corner (1M/2M)',
    ],
    stepMarkingChecklist: [
      'Draw neat Gaussian surface cylinder/sphere with area vectors d A and field vectors E shown with arrows.',
      'State why flux through end-caps is zero (cos 90 = 0).',
      'Box final formula: E = lambda / (2 pi eps_0 r).',
    ],
    examinerTrapAlerts: [
      'Flux is independent of shape and size of Gaussian surface, but depends only on enclosed charge.',
      'If charge is outside Gaussian surface, net flux is strictly zero.',
    ],
    guruJiBoardSecretHinglish: 'Beta, Gauss law derivation mein agar cylinder ke do circular caps par flux zero hone ka reason [E . dA = E dA cos 90° = 0] nahi likha, toh examiner 1 mark deduct kar leta hai. Is step ko kabhi mat chhodna!',
  },
  {
    chapterId: 'b-phy-06',
    chapterName: 'Optics (Ray & Wave Optics)',
    subject: 'physics',
    marksWeightage: 14,
    ncertKeyDefinitions: [
      {
        term: "Snell's Law",
        definition: 'The ratio of sine of angle of incidence to sine of angle of refraction is a constant equal to relative refractive index.',
        formulaOrLaw: '\\\\frac{\\\\sin i}{\\\\sin r} = \\\\frac{\\\\mu_2}{\\\\mu_1}',
      },
      {
        term: "Lens Maker's Formula",
        definition: 'Relates focal length of a lens to refractive index of its material and radii of curvature of its two surfaces.',
        formulaOrLaw: '\\\\frac{1}{f} = (\\\\mu - 1)\\\\left(\\\\frac{1}{R_1} - \\\\frac{1}{R_2}\\\\right)',
      },
      {
        term: "Huygens' Principle",
        definition: 'Every point on a wavefront acts as a source of secondary spherical wavelets which spread out in all directions with speed of wave.',
      },
    ],
    guaranteedQuestions: [
      "Lens Maker formula derivation for double convex lens (5M Guaranteed)",
      "Proof of Snell's law of refraction using Huygens wavefront construction (5M Guaranteed)",
      "Astronomical telescope ray diagram in normal adjustment with magnifying power (3M)",
      "Young's double slit fringe width beta = lambda D / d derivation (3M)",
    ],
    stepMarkingChecklist: [
      'Ray diagrams MUST have arrowheads indicating light propagation direction. Unarrowed rays lose 1 full mark.',
      'Label intermediate image I1 and final image I clearly in Lens Maker derivation.',
      'In astronomical telescope, clearly state normal adjustment means image is formed at infinity.',
    ],
    examinerTrapAlerts: [
      'In Lens Maker formula, remember sign convention for R1 (+ve) and R2 (-ve) for convex lens.',
      'Refractive index of medium changes wavelength: lambda_med = lambda / mu, but frequency remains constant!',
    ],
    guruJiBoardSecretHinglish: 'Beta, Optics 14 marks deta hai board exam mein — single largest weightage! Isme ray diagrams mein arrow banana compulsory hai. Agar arrow nahi banaya toh board examiner bina sochey 1 mark kaat deta hai!',
  },
  {
    chapterId: 'b-chem-02',
    chapterName: 'Electrochemistry',
    subject: 'chemistry',
    marksWeightage: 9,
    ncertKeyDefinitions: [
      {
        term: 'Kohlrausch Law of Independent Migration of Ions',
        definition: 'Limiting molar conductivity of an electrolyte can be represented as the sum of the individual contributions of the anion and cation of the electrolyte.',
        formulaOrLaw: '\\\\Lambda_m^\\\\circ = \\\\nu_+ \\\\lambda_+^\\\\circ + \\\\nu_- \\\\lambda_-^\\\\circ',
      },
      {
        term: 'Nernst Equation',
        definition: 'Relates electrode potential or cell potential to standard electrode potential, temperature, and activities/concentrations of reacting species.',
        formulaOrLaw: 'E_{\\\\text{cell}} = E^\\\\circ_{\\\\text{cell}} - \\\\frac{0.059}{n} \\\\log Q',
      },
    ],
    guaranteedQuestions: [
      'Nernst equation cell potential and Delta G numerical (3M/5M)',
      'Calculate molar conductivity at infinite dilution of CH3COOH using Kohlrausch law (3M)',
      'Molar conductivity variation with concentration for strong vs weak electrolytes with graph (3M)',
    ],
    stepMarkingChecklist: [
      'Write balanced cell reaction first to identify n (number of electrons).',
      'Raise concentrations to their stoichiometric powers in reaction quotient Q.',
      'Report final cell potential in Volts (V) and Delta G in kJ/mol.',
    ],
    examinerTrapAlerts: [
      'Never forget negative sign in Delta G = -n F E_cell.',
      'Standard hydrogen electrode SHE potential is 0.00 V by convention.',
    ],
    guruJiBoardSecretHinglish: 'Beta, Nernst equation mein [Ag+]^2 ya [Al3+]^2 powers lagana mat bhoolna. Balanced reaction ke coefficients reaction quotient Q ke exponent bante hain!',
  },
  {
    chapterId: 'b-math-02',
    chapterName: 'Matrices and Determinants',
    subject: 'mathematics',
    marksWeightage: 10,
    ncertKeyDefinitions: [
      {
        term: 'Non-Singular Matrix',
        definition: 'A square matrix A is said to be non-singular if its determinant is non-zero (|A| != 0). Only non-singular matrices possess an inverse.',
      },
      {
        term: 'Adjoint of a Matrix',
        definition: 'The transpose of the cofactor matrix of a given square matrix A is called its adjoint adj(A).',
        formulaOrLaw: 'A \\\\cdot \\\\text{adj}(A) = |A| I',
      },
    ],
    guaranteedQuestions: [
      'Solving 3-variable system of linear equations by Matrix Inverse Method AX = B (5M Guaranteed)',
      'Properties of determinants / adjoint: |adj(A)| = |A|^(n-1) (1M/2M)',
      'Find matrix inverse using adjoint method (3M)',
    ],
    stepMarkingChecklist: [
      'Step 1: Write AX = B and find |A| (1 Mark).',
      'Step 2: Show all 9 cofactors C11 through C33 step-by-step (1.5 Marks).',
      'Step 3: Transpose cofactors to form adj(A) (1 Mark).',
      'Step 4: Matrix multiply A^(-1) by B and state final values x, y, z (1.5 Marks).',
    ],
    examinerTrapAlerts: [
      'Transpose error: 60% of students write cofactor matrix directly as adj(A) without transposing rows to columns!',
      'Sign mistake in cofactor formula C_ij = (-1)^(i+j) M_ij for C12, C21, C23, C32.',
    ],
    guruJiBoardSecretHinglish: 'Beta, Matrix Method 5 marks ka pakka jackpot hai! Bus cofactors nikaalne ke baad Transpose lena mat bhoolna. Aur answer aane ke baad equation 1 mein values daal kar 30 second mein check kar lena!',
  },
];

// ===================== FULL-LENGTH BOARD SAMPLE PAPERS =====================
export const BOARD_SAMPLE_PAPERS: BoardSamplePaper[] = [
  {
    id: 'b-sp-phy-01',
    paperNumber: 1,
    subject: 'physics',
    title: 'CBSE Class 12 Physics Official Model Sample Paper',
    totalMarks: 70,
    timeAllowedHours: 3,
    generalInstructions: [
      'There are 33 questions in all. All questions are compulsory.',
      'Section A contains 16 questions: 12 MCQs and 4 Assertion-Reasoning questions of 1 mark each.',
      'Section B contains 5 Very Short Answer (VSA) questions of 2 marks each.',
      'Section C contains 7 Short Answer (SA) questions of 3 marks each.',
      'Section D contains 2 Case-Based questions of 4 marks each.',
      'Section E contains 3 Long Answer (LA) questions of 5 marks each.',
      'There is no overall choice. However, internal choices have been provided in some questions.',
      'Use of log tables is permitted if necessary. Use of calculators is strictly prohibited.',
    ],
    questions: CLASS_12_BOARD_QUESTIONS.filter((q) => q.subject === 'physics').slice(0, 33),
  },
  {
    id: 'b-sp-chm-01',
    paperNumber: 1,
    subject: 'chemistry',
    title: 'CBSE Class 12 Chemistry Official Model Sample Paper',
    totalMarks: 70,
    timeAllowedHours: 3,
    generalInstructions: [
      'There are 33 questions in all. All questions are compulsory.',
      'Section A: 16 questions (12 MCQs + 4 A-R) of 1 mark each.',
      'Section B: 5 questions of 2 marks each.',
      'Section C: 7 questions of 3 marks each.',
      'Section D: 2 case-based questions of 4 marks each.',
      'Section E: 3 long answer questions of 5 marks each.',
      'Calculators not allowed. Use log tables if necessary.',
    ],
    questions: CLASS_12_BOARD_QUESTIONS.filter((q) => q.subject === 'chemistry').slice(0, 33),
  },
  {
    id: 'b-sp-mth-01',
    paperNumber: 1,
    subject: 'mathematics',
    title: 'CBSE Class 12 Mathematics Official Model Sample Paper',
    totalMarks: 80,
    timeAllowedHours: 3,
    generalInstructions: [
      'This question paper contains 38 questions across Sections A, B, C, D, and E.',
      'Section A comprises 20 MCQs / A-R of 1 mark each.',
      'Section B comprises 5 VSA questions of 2 marks each.',
      'Section C comprises 6 SA questions of 3 marks each.',
      'Section D comprises 4 LA questions of 5 marks each.',
      'Section E comprises 3 Case-Based questions of 4 marks each.',
      'All questions are compulsory with internal choice provided in selected questions.',
    ],
    questions: CLASS_12_BOARD_QUESTIONS.filter((q) => q.subject === 'mathematics').slice(0, 38),
  },
];
"""

with open(output_file, "w", encoding="utf-8") as f:
    f.write(content)

print("Generated", output_file, "successfully!")
