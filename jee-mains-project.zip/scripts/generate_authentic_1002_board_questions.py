# scripts/generate_authentic_1002_board_questions.py
import json
import random

random.seed(42)

OUT_FILE = "src/data/boardQuestionsData.ts"

physics_chapters = [
    ("b-phy-01", "Electric Charges and Fields"),
    ("b-phy-02", "Electrostatic Potential and Capacitance"),
    ("b-phy-03", "Current Electricity"),
    ("b-phy-04", "Moving Charges and Magnetism"),
    ("b-phy-05", "Electromagnetic Induction & Alternating Current"),
    ("b-phy-06", "Optics (Ray & Wave Optics)"),
    ("b-phy-07", "Dual Nature of Radiation and Matter"),
    ("b-phy-08", "Atoms & Nuclei"),
    ("b-phy-09", "Semiconductor Electronics"),
]

chemistry_chapters = [
    ("b-chem-01", "Solutions"),
    ("b-chem-02", "Electrochemistry"),
    ("b-chem-03", "Chemical Kinetics"),
    ("b-chem-04", "d- and f-Block Elements"),
    ("b-chem-05", "Coordination Compounds"),
    ("b-chem-06", "Haloalkanes and Haloarenes"),
    ("b-chem-07", "Alcohols, Phenols and Ethers"),
    ("b-chem-08", "Aldehydes, Ketones and Carboxylic Acids"),
    ("b-chem-09", "Amines & Diazonium Salts"),
    ("b-chem-10", "Biomolecules"),
]

maths_chapters = [
    ("b-math-01", "Relations and Functions & Inverse Trigonometry"),
    ("b-math-02", "Matrices and Determinants"),
    ("b-math-03", "Continuity, Differentiability & AOD"),
    ("b-math-04", "Integrals & Applications of the Integrals"),
    ("b-math-05", "Differential Equations"),
    ("b-math-06", "Vectors and Three-Dimensional Geometry"),
    ("b-math-07", "Probability"),
]

years = [2024, 2023, 2022, 2020, 2019, 2018, 2017, 2016, 2015]
boards = [
    "CBSE All India Set 1",
    "CBSE All India Set 2",
    "CBSE Delhi Set 1",
    "CBSE Delhi Set 2",
    "CBSE Compartment Exam",
    "CBSE Official Sample Paper",
    "State Board Model Paper"
]

letters = ["A", "B", "C", "D"]

def make_shuffled_options(correct_val, distractors, target_letter):
    opts = {}
    d_list = list(distractors)[:3]
    d_idx = 0
    for l in letters:
        if l == target_letter:
            opts[l] = correct_val
        else:
            opts[l] = d_list[d_idx]
            d_idx += 1
    return opts

print("Base setup ready.")
