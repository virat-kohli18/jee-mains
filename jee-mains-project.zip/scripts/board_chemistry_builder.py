# scripts/board_chemistry_builder.py
import json

chemistry_chapters = [
    ("b-chem-01", "Solutions"),
    ("b-chem-02", "Electrochemistry"),
    ("b-chem-03", "Chemical Kinetics"),
    ("b-chem-04", "d- and f-Block Elements"),
    ("b-chem-05", "Coordination Compounds"),
    ("b-chem-06", "Haloalkanes and Haloarenes"),
    ("b-chem-07", "Alcohols, Phenols and Ethers"),
    ("b-chem-08", "Aldehydes, Ketones and Carboxylic Acids"),
    ("b-chem-09", "Amines & Diazonium Salts"),
    ("b-chem-10", "Biomolecules"),
]

years = [2024, 2023, 2022, 2020, 2019, 2018, 2017, 2016, 2015]
boards = [
    "CBSE All India Set 1", "CBSE All India Set 2", "CBSE Delhi Set 1",
    "CBSE Delhi Set 2", "CBSE Compartment Exam", "CBSE Official Sample Paper"
]

letters = ["A", "B", "C", "D"]

def make_shuffled_options(correct_val, distractors, target_letter):
    opts = {}
    d_list = list(distractors)[:3]
    d_idx = 0
    for l in letters:
        if l == target_letter:
            opts[l] = correct_val
        else:
            opts[l] = d_list[d_idx]
            d_idx += 1
    return opts

def build_chemistry_questions():
    questions = []

    mcq_specs = [
        # Ch 1 Solutions
        ("b-chem-01", "Solutions", "Which of the following aqueous solutions will exhibit the highest boiling point under 1 atm pressure?", "0.1 M Al2(SO4)3", ["0.1 M NaCl", "0.1 M BaCl2", "0.1 M Glucose"], "Delta T_b = i * K_b * m. For Al2(SO4)3, van 't Hoff factor i = 5 (2 Al3+ + 3 SO4 2-). Highest i produces the maximum boiling point elevation.", "van 't Hoff factor i check karo: Al2(SO4)3 mein i=5 hota hai, isliye boiling point highest hoga!"),
        ("b-chem-01", "Solutions", "According to Henry's law, the solubility of a gas in a liquid is inversely proportional to its Henry's law constant K_H. This implies that as temperature increases:", "K_H increases and solubility of the gas decreases", ["K_H decreases and solubility increases", "Both K_H and solubility increase", "Both K_H and solubility decrease"], "Dissolution of gas in liquid is exothermic (Delta H < 0). Increasing temperature favors gas release, increasing K_H and reducing gas solubility.", "Garmi mein aquatic species struggle karte hain kyunki K_H badhta hai aur dissolved O2 kam ho jaati hai!"),
        ("b-chem-01", "Solutions", "An azeotropic mixture of two liquids boils at a lower temperature than either of them when the solution shows:", "Large positive deviation from Raoult's law", ["Large negative deviation from Raoult's law", "Ideal behavior with Delta H_mix = 0", "Zero vapor pressure"], "Positive deviation means A-B intermolecular forces are weaker than A-A and B-B, giving higher vapor pressure and a minimum-boiling azeotrope.", "Positive deviation -> Higher vapor pressure -> Lower boiling point (minimum boiling azeotrope)!"),
        ("b-chem-01", "Solutions", "The unit of molal elevation constant (ebullioscopic constant K_b) is:", "K kg mol^-1", ["K mol kg^-1", "kg mol^-1 K^-1", "K kg^-1 mol"], "From Delta T_b = K_b * m -> K_b = Delta T_b / m = K / (mol / kg) = K kg mol^-1.", "Units of K_b and K_f: K kg mol^-1 yaad rakho!"),
        ("b-chem-01", "Solutions", "Which of the following colligative properties is most commonly employed for determining molar masses of proteins, polymers, and biomolecules?", "Osmotic Pressure", ["Elevation in boiling point", "Depression in freezing point", "Relative lowering of vapor pressure"], "Osmotic pressure is measured at room temperature and produces readily measurable magnitudes even for very dilute macromolecular solutions.", "Biomolecules room temperature par unstable hote hain, isliye Osmotic Pressure sabse best method hai."),
        ("b-chem-01", "Solutions", "Two solutions having identical osmotic pressure at a given temperature are termed as:", "Isotonic solutions", ["Hypotonic solutions", "Hypertonic solutions", "Azeotropic solutions"], "Isotonic solutions have equal molar concentrations of solute particles, preventing net water movement across semipermeable membranes.", "Isotonic = Same osmotic pressure. 0.9% NaCl blood cells ke sath isotonic hota hai."),
        ("b-chem-01", "Solutions", "If a non-volatile solute undergoes dimerization in benzene solvent, its van 't Hoff factor i will be:", "Less than 1 (i = 1 - alpha/2)", ["Greater than 1", "Equal to 1", "Equal to 2"], "When solute particles associate (n molecules forming 1), total particle count decreases, resulting in i = 1 + (1/n - 1) alpha < 1.", "Association mein i < 1 hota hai, dissociation mein i > 1!"),

        # Ch 2 Electrochemistry
        ("b-chem-02", "Electrochemistry", "For the cell reaction Zn(s) + Cu2+(aq) -> Zn2+(aq) + Cu(s), E°_cell is 1.10 V. The standard Gibbs free energy change Delta G° is: (1 F = 96500 C/mol)", "- 212.3 kJ/mol", ["+ 212.3 kJ/mol", "- 106.1 kJ/mol", "+ 106.1 kJ/mol"], "Delta G° = - n F E°_cell = - (2) * (96500) * (1.10) J = - 212300 J = - 212.3 kJ/mol.", "Delta G° = - n F E° formula mein n=2 dhyan se substitute karo."),
        ("b-chem-02", "Electrochemistry", "Molar conductivity of a strong electrolyte increases slightly with dilution primarily because:", "Interionic attractions decrease upon dilution", ["Degree of dissociation increases significantly", "Number of ions per unit volume increases", "Electrons are liberated from solvent"], "Strong electrolytes are already 100% ionized. Dilution separates ions farther apart, decreasing interionic frictional drag and slightly enhancing mobility.", "Strong electrolytes mein ion count nahi badhta, sirf interionic attraction kam hoti hai!"),
        ("b-chem-02", "Electrochemistry", "According to Kohlrausch's law of independent migration of ions, the limiting molar conductivity of an electrolyte is:", "The sum of individual limiting ionic conductivities", ["The product of cation and anion conductivities", "Constant regardless of ionic charges", "Zero at infinite dilution"], "At infinite dilution, each ion migrates independently of co-ions: Lambda°_m = nu_+ lambda°_+ + nu_- lambda°_-.", "Kohlrausch law: Lambda°_m = sum of individual ionic limiting conductivities."),
        ("b-chem-02", "Electrochemistry", "The quantity of electricity required to liberate 1 mole of aluminum from molten Al2O3 is:", "3 Faraday (3 F)", ["1 Faraday", "2 Faraday", "6 Faraday"], "Reduction reaction: Al3+ + 3e- -> Al(s). One mole of Al requires 3 moles of electrons, which equals 3 F (3 * 96500 C).", "Al3+ ko 3 electrons chahiye, isliye 3 Faraday charge lagega."),
        ("b-chem-02", "Electrochemistry", "During the discharging of a lead storage battery, the substance formed at both anode and cathode is:", "PbSO4(s)", ["PbO2(s)", "Pb(s)", "H2SO4(aq)"], "At anode: Pb + SO4 2- -> PbSO4 + 2e-. At cathode: PbO2 + 4H+ + SO4 2- + 2e- -> PbSO4 + 2H2O. Both electrodes precipitate solid PbSO4.", "Lead storage battery discharge hone par dono electrodes par PbSO4 banta hai aur H2SO4 consume hota hai!"),
        ("b-chem-02", "Electrochemistry", "The standard reduction potentials are E°(Zn2+/Zn) = -0.76 V and E°(Fe2+/Fe) = -0.44 V. Galvanization of iron with zinc prevents rusting because:", "Zinc has a lower reduction potential and oxidizes preferentially", ["Zinc is less reactive than iron", "Zinc forms a protective basic oxide layer", "Iron oxidizes faster than zinc"], "Zinc acts as a sacrificial anode because its more negative E° makes it easier to oxidize than iron, protecting iron even if the coating is scratched.", "Sacrificial protection: Zinc ka E° zyada negative hai, isliye wo pehle oxidise hota hai."),
        ("b-chem-02", "Electrochemistry", "The SI unit of cell constant G* is:", "m^-1 (or cm^-1)", ["m (or cm)", "ohm^-1 m^-1", "S m^2 mol^-1"], "Cell constant G* = l / A = length / area = m / m^2 = m^-1 (or cm^-1).", "Cell constant G* = l/A, unit cm^-1 ya m^-1."),

        # Ch 3 Chemical Kinetics
        ("b-chem-03", "Chemical Kinetics", "The rate constant of a reaction has units mol L^-1 s^-1. The overall order of this reaction is:", "Zero order", ["First order", "Second order", "Half order"], "General unit of rate constant is (mol/L)^(1-n) s^-1. For n = 0, units are mol L^-1 s^-1.", "Rate constant ki unit se order pehchano: mol L^-1 s^-1 -> Zero order! s^-1 -> First order!"),
        ("b-chem-03", "Chemical Kinetics", "For a first order reaction, if the initial reactant concentration is doubled, its half-life period t_1/2:", "Remains unchanged", ["Doubles", "Halves", "Quadruples"], "For a first order reaction, t_1/2 = 0.693 / k. It is strictly independent of initial reactant concentration [A]_0.", "First order reaction ki half-life initial concentration par depend NAHI karti (t_1/2 = 0.693/k)!"),
        ("b-chem-03", "Chemical Kinetics", "A catalyst increases the rate of a chemical reaction primarily by:", "Providing an alternative reaction pathway with lower activation energy", ["Increasing the enthalpy change Delta H", "Increasing the collision frequency of molecules", "Decreasing the Gibbs free energy change Delta G"], "Catalysts lower the activation energy barrier E_a, allowing a greater fraction of colliding molecules to possess sufficient energy to react.", "Catalyst activation energy E_a kam karta hai, Delta H aur Delta G ko bilkul touch nahi karta!"),
        ("b-chem-03", "Chemical Kinetics", "If a reaction follows the rate law Rate = k [A]^1 [B]^2, doubling [A] and halving [B] changes the reaction rate by a factor of:", "1 / 2", ["2", "4", "1 (unchanged)"], "Rate' = k [2A] [B/2]^2 = k (2) [A] (1/4) [B]^2 = (1/2) k [A] [B]^2. The rate becomes half.", "Values rate law mein dhyan se substitute karo: 2 * (1/2)^2 = 2/4 = 1/2."),
        ("b-chem-03", "Chemical Kinetics", "The slope of the linear plot of ln(k) versus 1/T in the Arrhenius equation represents:", "- E_a / R", ["E_a / R", "- E_a", "ln(A)"], "From Arrhenius equation: ln(k) = ln(A) - (E_a / R) * (1/T). Comparing with y = c + m x gives slope m = - E_a / R.", "Arrhenius plot ka slope = - E_a / R, y-intercept = ln(A)."),
        ("b-chem-03", "Chemical Kinetics", "The time required for 99.9% completion of a first order reaction is related to its half-life t_1/2 by:", "t_99.9% = 10 * t_1/2", ["t_99.9% = 2 * t_1/2", "t_99.9% = 4 * t_1/2", "t_99.9% = 100 * t_1/2"], "t_99.9% = (2.303/k) * log(100 / 0.1) = (2.303/k) * log(10^3) = 3 * (2.303/k) = 3 * (t_1/2 / 0.3010) = 10 * t_1/2.", "Direct CBSE board standard derivation: t_99.9% hamesha 10 guna t_1/2 hota hai!"),
        ("b-chem-03", "Chemical Kinetics", "Which of the following statements about molecularity of an elementary reaction is FALSE?", "Molecularity can be zero or fractional", ["Molecularity is always a positive integer", "Molecularity cannot exceed three", "Molecularity is deduced from single-step mechanism"], "Molecularity represents the number of reacting particles colliding simultaneously; it must be an integer (1, 2, or 3) and can never be zero or fractional.", "Order fractional/zero ho sakta hai, lekin molecularity HAMESHA whole number (1, 2, 3) hoti hai!"),

        # Ch 4 d- and f-Block
        ("b-chem-04", "d- and f-Block Elements", "Transition metals exhibit high catalytic activity primarily due to:", "Variable oxidation states and ability to form unstable intermediates", ["Low ionization enthalpies", "High melting points", "Completely filled d-orbitals"], "Transition metals can adopt multiple oxidation states to accommodate reactants and provide alternative pathways with lower activation energy.", "Catalytic property ka main reason: Variable oxidation states and vacant d-orbitals."),
        ("b-chem-04", "d- and f-Block Elements", "The steady decrease in atomic and ionic radii along the lanthanoid series (lanthanoid contraction) is caused by:", "Poor shielding effect of 4f electrons", ["Strong shielding by 5d electrons", "Increase in principal quantum number", "High ionization enthalpy"], "The diffuse shapes of 4f orbitals provide imperfect shielding, allowing effective nuclear charge to pull outer electrons inward.", "Lanthanoid contraction ka main cause: 4f electrons ka poor shielding effect!"),
        ("b-chem-04", "d- and f-Block Elements", "Which of the following 3d series transition metal ions is colorless in aqueous solution?", "Sc3+ (Z = 21)", ["Ti3+ (Z = 22)", "Cu2+ (Z = 29)", "Fe3+ (Z = 26)"], "Sc3+ has an empty d-shell ([Ar] 3d0). In the absence of d-electrons, d-d transitions cannot occur, making the ion colorless.", "d0 aur d10 ions colorless hote hain kyunki d-d transition possible nahi hoti (Sc3+, Zn2+)."),
        ("b-chem-04", "d- and f-Block Elements", "The spin-only magnetic moment of Mn2+ (Z = 25) ion is:", "5.92 BM", ["4.90 BM", "3.87 BM", "1.73 BM"], "Mn2+ has configuration [Ar] 3d5 with n = 5 unpaired electrons. mu = sqrt(5(5+2)) = sqrt(35) = 5.92 BM.", "Unpaired electrons n=5 -> mu = sqrt(35) approx 5.92 BM."),
        ("b-chem-04", "d- and f-Block Elements", "In acidic medium, potassium dichromate (K2Cr2O7) acts as a powerful oxidizing agent. The oxidation state of chromium changes from:", "+6 to +3", ["+6 to +2", "+7 to +2", "+5 to +3"], "The ionic equation is Cr2O7 2- + 14H+ + 6e- -> 2Cr3+ + 7H2O. Chromium is reduced from +6 to +3.", "K2Cr2O7 acidic medium mein Cr2O7 2- (+6) se green Cr3+ (+3) mein reduce hota hai."),
        ("b-chem-04", "d- and f-Block Elements", "Interstitial compounds formed by transition metals with small atoms (H, C, N) are characterized by:", "High melting points and chemical inertness", ["Malleability and ductility", "Electrical insulation", "Low hardness"], "Small atoms occupy interstitial voids in the metal lattice, hindering dislocation motion, which increases hardness and melting points while preserving electrical conductivity.", "Interstitial compounds high melting point aur hardness show karte hain."),

        # Ch 5 Coordination
        ("b-chem-05", "Coordination Compounds", "The IUPAC name of the complex [Co(NH3)5(CO3)]Cl is:", "Pentaamminecarbonatocobalt(III) chloride", ["Carbonatopentaamminecobalt(III) chloride", "Pentaamminecarbonatocobalt(II) chloride", "Pentaamminechlorocobalt(III) carbonate"], "Ligands are named alphabetically: ammine before carbonato. Cobalt is in +3 state: x + 0 - 2 - 1 = 0 -> x = +3.", "IUPAC naming mein ligands alphabetical order mein likhe jaate hain."),
        ("b-chem-05", "Coordination Compounds", "The geometry and hybridization of the diamagnetic complex [Ni(CN)4]2- are:", "Square planar and dsp2", ["Tetrahedral and sp3", "Octahedral and sp3d2", "Trigonal bipyramidal and dsp3"], "CN- is a strong field ligand that forces pairing of the eight 3d electrons in Ni2+ (3d8), leaving one empty 3d orbital for dsp2 square planar hybridization.", "CN- strong field ligand hai, pairing karwayega -> dsp2 Square Planar, Diamagnetic!"),
        ("b-chem-05", "Coordination Compounds", "The pair of coordination compounds [Co(NH3)5SO4]Br and [Co(NH3)5Br]SO4 represents:", "Ionization isomerism", ["Linkage isomerism", "Coordination isomerism", "Hydrate isomerism"], "These isomers give different ions in solution (one gives Br- giving cream AgBr precipitate, the other gives SO4 2- giving white BaSO4 precipitate).", "Solution mein different ions milte hain -> Ionization Isomerism!"),
        ("b-chem-05", "Coordination Compounds", "According to Crystal Field Theory, the crystal field splitting energy in tetrahedral complexes (Delta_t) is related to octahedral splitting (Delta_o) by:", "Delta_t = (4/9) Delta_o", ["Delta_t = (9/4) Delta_o", "Delta_t = Delta_o", "Delta_t = (2/3) Delta_o"], "Due to fewer ligands (4 vs 6) and non-directional approach between axes, tetrahedral splitting is substantially smaller: Delta_t = (4/9) Delta_o.", "Tetrahedral splitting octahedral ka sirf 4/9th hota hai, isliye tetrahedral complexes hamesha high spin hote hain!"),
        ("b-chem-05", "Coordination Compounds", "Which of the following is an ambidentate ligand capable of coordinating through two different donor atoms?", "NO2- (nitro and nitrito)", ["NH3", "H2O", "Oxalate (C2O4 2-)"], "NO2- can coordinate through nitrogen (nitro) or through oxygen (nitrito-O), giving rise to linkage isomerism.", "Ambidentate ligands: NO2- (N or O) aur SCN- (S or N)!"),
        ("b-chem-05", "Coordination Compounds", "A coordination complex having formula CoCl3 . 4NH3 gives 1 mole of AgCl precipitate with excess AgNO3. Its coordination formula is:", "[Co(NH3)4Cl2]Cl", ["[Co(NH3)4Cl3]", "[Co(NH3)4Cl]Cl2", "[Co(NH3)4]Cl3"], "Only ionizable chloride ions present outside the coordination sphere precipitate with Ag+. 1 mole AgCl implies 1 Cl- is outside.", "Sirf square bracket ke bahar wale ions hi precipitate hote hain!"),

        # Ch 6 Haloalkanes
        ("b-chem-06", "Haloalkanes and Haloarenes", "In SN2 nucleophilic substitution reactions, the reaction proceeds with:", "Complete inversion of configuration (Walden inversion)", ["Complete retention of configuration", "Racemization via planar carbocation", "Formation of free radical intermediate"], "SN2 involves backside attack by the nucleophile simultaneously as the leaving group departs, inverting the stereochemical geometry like an umbrella in a gale.", "SN2 = Backside attack = Complete Inversion (Walden Inversion)!"),
        ("b-chem-06", "Haloalkanes and Haloarenes", "Chlorobenzene is extremely unreactive towards nucleophilic substitution compared to haloalkanes due to:", "Partial double bond character of C-Cl bond due to resonance", ["Steric hindrance by benzene ring", "Weak C-Cl bond polarity", "Sp3 hybridization of carbon"], "The lone pair on chlorine delocalizes into the aromatic pi system, giving the C-Cl bond partial double bond character that resists cleavage.", "Resonance ki wajah se C-Cl bond mein partial double bond character aa jaata hai!"),
        ("b-chem-06", "Haloalkanes and Haloarenes", "The reaction of an alkyl halide with sodium metal in dry ether to form a symmetrical alkane is known as:", "Wurtz reaction", ["Fittig reaction", "Swarts reaction", "Finkelstein reaction"], "2 R-X + 2 Na (dry ether) -> R-R + 2 NaX is the classic Wurtz synthesis of symmetrical higher alkanes.", "Wurtz reaction: 2 R-X + 2 Na -> R-R. Aryl halides ke liye Fittig reaction."),
        ("b-chem-06", "Haloalkanes and Haloarenes", "Alkyl fluorides are best prepared by heating alkyl chlorides or bromides with metallic fluorides (AgF, Hg2F2) in:", "Swarts reaction", ["Finkelstein reaction", "Sandmeyer reaction", "Hunsdiecker reaction"], "Halogen exchange using metallic fluorides to produce fluorinated alkanes is specifically termed the Swarts reaction.", "Fluoride banane ke liye Swarts reaction (AgF), Iodide ke liye Finkelstein reaction (NaI/acetone)."),
        ("b-chem-06", "Haloalkanes and Haloarenes", "Which of the following compounds will react fastest via SN1 mechanism?", "(CH3)3C-Br (tert-butyl bromide)", ["(CH3)2CH-Br (isopropyl bromide)", "CH3CH2-Br (ethyl bromide)", "CH3-Br (methyl bromide)"], "SN1 rate is determined by carbocation stability. The tertiary carbocation (CH3)3C+ is stabilized by 9 alpha-hydrogens, making tert-butyl bromide react fastest.", "SN1 reactivity order: 3° > 2° > 1° > methyl!"),
        ("b-chem-06", "Haloalkanes and Haloarenes", "Chloroform (CHCl3) is stored in dark amber-colored bottles filled to the brim to prevent:", "Oxidation by air and sunlight into poisonous phosgene (COCl2)", ["Evaporation and thermal decomposition", "Polymerization into carbon tetrachloride", "Reduction into dichloromethane"], "2 CHCl3 + O2 (light) -> 2 COCl2 (phosgene) + 2 HCl. Amber bottles and 1% ethanol prevent phosgene formation.", "Chloroform sunlight aur air se react karke deadly phosgene gas (COCl2) banata hai."),

        # Ch 7 Alcohols, Phenols, Ethers
        ("b-chem-07", "Alcohols, Phenols and Ethers", "Lucas test is used to distinguish between primary, secondary, and tertiary alcohols using:", "Anhydrous ZnCl2 and concentrated HCl", ["Dilute H2SO4 and KMnO4", "NaOH and I2", "Br2 in water"], "Lucas reagent (conc. HCl + anh. ZnCl2) reacts via carbocation intermediate: 3° alcohol gives instant turbidity, 2° gives turbidity in 5 mins, 1° remains clear at room temp.", "Lucas test turbidity: 3° instant, 2° after 5 mins, 1° heating par!"),
        ("b-chem-07", "Alcohols, Phenols and Ethers", "Phenol is significantly more acidic than ethanol because:", "Phenoxide ion is stabilized by resonance over the aromatic ring", ["Phenol has a higher molecular weight", "Ethanol forms stronger hydrogen bonds", "Ethoxide ion is resonance stabilized"], "Loss of H+ produces the phenoxide ion, whose negative charge is delocalized across ortho and para positions of the aromatic ring, making phenol acidic (pK_a ~ 10).", "Phenoxide ion resonance stabilized hota hai, ethoxide ion mein koi resonance nahi hoti."),
        ("b-chem-07", "Alcohols, Phenols and Ethers", "The reaction of phenol with chloroform in the presence of aqueous NaOH to form salicylaldehyde is:", "Reimer-Tiemann reaction", ["Kolbe's reaction", "Williamson synthesis", "Friedel-Crafts acylation"], "Reimer-Tiemann reaction introduces a -CHO group ortho to -OH via electrophilic dichlorocarbene (:CCl2) intermediate to yield salicylaldehyde.", "Phenol + CHCl3 + NaOH -> Salicylaldehyde (Reimer-Tiemann reaction)!"),
        ("b-chem-07", "Alcohols, Phenols and Ethers", "When tert-butyl methyl ether is heated with excess concentrated HI, the primary products formed are:", "tert-Butyl iodide and methanol", ["Methyl iodide and tert-butyl alcohol", "tert-Butyl iodide and methyl iodide", "Isobutylene and methyl iodide"], "The reaction proceeds via stable tertiary carbocation (SN1 pathway) at the tert-butyl group, forming (CH3)3C-I and CH3OH.", "Tertiary group ho toh halide hamesha tertiary carbon par judta hai (SN1 pathway)!"),
        ("b-chem-07", "Alcohols, Phenols and Ethers", "Kolbe's reaction of sodium phenoxide with carbon dioxide at 400 K and 4-7 atm followed by acidification yields:", "Salicylic acid", ["Salicylaldehyde", "Benzoic acid", "Aspirin"], "Phenoxide ion reacts with electrophilic CO2 to form sodium salicylate, which upon acid hydrolysis gives 2-hydroxybenzoic acid (salicylic acid).", "Kolbe reaction: Phenol + CO2 + NaOH -> Salicylic acid (used to make Aspirin)!"),
        ("b-chem-07", "Alcohols, Phenols and Ethers", "Williamson ether synthesis involves the reaction between:", "Sodium alkoxide and primary alkyl halide", ["Secondary alcohol and concentrated H2SO4", "Sodium phenoxide and tertiary alkyl halide", "Alkyl halide and dry silver oxide"], "Williamson synthesis is an SN2 reaction between R-O- Na+ and primary R'-X. If tertiary halide is used, elimination (alkene) predominates.", "Williamson synthesis mein alkyl halide hamesha PRIMARY hona chahiye, warna elimination ho jayegi!"),

        # Ch 8 Aldehydes, Ketones, Carboxylic Acids
        ("b-chem-08", "Aldehydes, Ketones and Carboxylic Acids", "Which of the following compounds gives a positive iodoform test upon treatment with I2 and NaOH?", "Pentan-2-one", ["Pentan-3-one", "Benzaldehyde", "Propanal"], "The iodoform test is specific for compounds containing a methyl carbonyl group (CH3-C=O) or CH3-CH(OH)- group. Pentan-2-one has CH3-C(=O)-CH2CH2CH3.", "Iodoform test ke liye CH3-C=O ya CH3-CH(OH)- group zaroori hai!"),
        ("b-chem-08", "Aldehydes, Ketones and Carboxylic Acids", "Aldehydes without alpha-hydrogens (such as HCHO and benzaldehyde) undergo self-redox in concentrated alkali in:", "Cannizzaro reaction", ["Aldol condensation", "Clemmensen reduction", "Rosenmund reduction"], "In Cannizzaro reaction, 2 molecules of non-enolizable aldehyde disproportionate into one molecule of alcohol and one molecule of carboxylic acid salt.", "No alpha-hydrogen + Conc NaOH -> Cannizzaro reaction (one molecule oxidized, one reduced)!"),
        ("b-chem-08", "Aldehydes, Ketones and Carboxylic Acids", "Clemmensen reduction converts a carbonyl group (>C=O) into a methylene group (>CH2) using:", "Zinc amalgam and concentrated HCl (Zn-Hg / conc. HCl)", ["Hydrazine and KOH in ethylene glycol", "LiAlH4 in dry ether", "H2 in the presence of Pd-BaSO4"], "Clemmensen reduction uses Zn-Hg/conc. HCl to reduce aldehydes and ketones into alkanes.", "Clemmensen = Zn-Hg / conc HCl. Wolff-Kishner = NH2NH2 / KOH."),
        ("b-chem-08", "Aldehydes, Ketones and Carboxylic Acids", "The relative reactivity of carbonyl compounds towards nucleophilic addition follows the decreasing order:", "HCHO > CH3CHO > CH3COCH3", ["CH3COCH3 > CH3CHO > HCHO", "CH3CHO > HCHO > CH3COCH3", "CH3COCH3 > HCHO > CH3CHO"], "Reactivity decreases with increasing steric hindrance and electron donation (+I effect) from alkyl groups attached to the carbonyl carbon.", "Formaldehyde sabse zyada reactive hota hai kyunki koi steric hindrance aur +I effect nahi hai!"),
        ("b-chem-08", "Aldehydes, Ketones and Carboxylic Acids", "Carboxylic acids do not form addition products with sodium bisulfite (NaHSO3) or oximes with hydroxylamine because:", "The carbonyl carbon is less electrophilic due to resonance with -OH oxygen", ["The -OH group causes extreme steric hindrance", "Carboxylic acids are strong reducing agents", "Carboxylic acids exist strictly as monomers"], "Resonance donation of the lone pair on the -OH oxygen into the carbonyl group reduces the partial positive charge on the carbonyl carbon.", "Carboxylic acid ka carbonyl carbon resonance ki wajah se electrophilic nahi rehta."),
        ("b-chem-08", "Aldehydes, Ketones and Carboxylic Acids", "The Hell-Volhard-Zelinsky (HVZ) reaction introduces a halogen atom selectively at:", "The alpha-position of carboxylic acids containing alpha-hydrogens", ["The carbonyl carbon of esters", "The aromatic ring of benzoic acid", "The beta-position of aldehydes"], "Carboxylic acids with alpha-hydrogens react with Cl2 or Br2 in the presence of red phosphorus to yield alpha-halocarboxylic acids.", "HVZ reaction: Red P + Br2/Cl2 alpha-carbon par halogen jodta hai!"),

        # Ch 9 Amines
        ("b-chem-09", "Amines & Diazonium Salts", "In aqueous solution, the correct decreasing order of basic strength of methyl-substituted aliphatic amines is:", "(CH3)2NH > CH3NH2 > (CH3)3N > NH3 (2° > 1° > 3° > NH3)", ["(CH3)3N > (CH3)2NH > CH3NH2 > NH3", "CH3NH2 > (CH3)2NH > (CH3)3N > NH3", "(CH3)2NH > (CH3)3N > CH3NH2 > NH3"], "Basic strength in water is governed by the combined balance of +I inductive effect, steric hindrance, and hydration of the conjugate cation. For methyl amines, 2° > 1° > 3°.", "Methyl group mein order: 213 (2° > 1° > 3°). Ethyl group mein: 231 (2° > 3° > 1°)!"),
        ("b-chem-09", "Amines & Diazonium Salts", "Gabriel phthalimide synthesis is exclusively used for the preparation of pure:", "Primary aliphatic amines", ["Secondary amines", "Tertiary amines", "Aromatic primary amines (aniline)"], "Aryl halides do not undergo nucleophilic substitution with potassium phthalimide due to resonance stabilization of C-X bond, restricting synthesis to 1° aliphatic amines.", "Gabriel Phthalimide se sirf 1° aliphatic amine banta hai; aniline NAHI ban sakta!"),
        ("b-chem-09", "Amines & Diazonium Salts", "The degradation of an amide into a primary amine with one fewer carbon atom using Br2 and aqueous KOH is:", "Hofmann bromamide degradation", ["Carbylamine reaction", "Sandmeyer reaction", "Gattermann reaction"], "R-CONH2 + Br2 + 4 KOH -> R-NH2 + K2CO3 + 2 KBr + 2 H2O degrades the carbon chain by exactly one carbon atom.", "Hofmann bromamide se 1 carbon KAM wala primary amine banta hai!"),
        ("b-chem-09", "Amines & Diazonium Salts", "Carbylamine test produces an extremely foul-smelling isocyanide when heated with chloroform and alcoholic KOH for:", "Primary amines only (both aliphatic and aromatic)", ["Secondary amines only", "Tertiary amines only", "All classes of amines"], "R-NH2 + CHCl3 + 3 KOH -> R-NC (carbylamine) + 3 KCl + 3 H2O is exclusive to primary amines.", "Carbylamine test sirf PRIMARY amine deta hai, foul smell of isocyanide aati hai!"),
        ("b-chem-09", "Amines & Diazonium Salts", "Hinsberg reagent (benzenesulfonyl chloride C6H5SO2Cl) reacts with a secondary amine to form:", "An N,N-dialkylbenzenesulfonamide that is insoluble in alkali", ["A sulfonamide that dissolves completely in alkali", "A diazonium salt", "No reaction"], "Secondary amine forms C6H5SO2NR2, which has no acidic hydrogen on nitrogen and hence cannot dissolve in aqueous KOH/NaOH.", "Hinsberg test: 1° amine ka product alkali mein soluble hota hai, 2° amine ka INSOLUBLE hota hai!"),
        ("b-chem-09", "Amines & Diazonium Salts", "Benzene diazonium chloride reacts with CuCl/HCl to form chlorobenzene with evolution of N2 gas in the:", "Sandmeyer reaction", ["Gattermann reaction", "Wurtz reaction", "Balz-Schiemann reaction"], "Reaction of Ar-N2+ Cl- with CuCl/HCl or CuBr/HBr is the Sandmeyer reaction, yielding aryl halides with nitrogen gas evolution.", "Sandmeyer reaction: CuCl/HCl use karta hai. Copper powder use karein toh Gattermann reaction!"),

        # Ch 10 Biomolecules
        ("b-chem-10", "Biomolecules", "Which of the following carbohydrates is a non-reducing disaccharide that does not reduce Tollens' or Fehling's reagent?", "Sucrose", ["Maltose", "Lactose", "Glucose"], "In sucrose, the reducing hemiacetal groups of both glucose (C1) and fructose (C2) are locked together in the glycosidic bond, leaving no free carbonyl group.", "Sucrose non-reducing sugar hai kyunki dono anomeric carbons glycosidic linkage mein locked hain!"),
        ("b-chem-10", "Biomolecules", "The helical structure of alpha-helix and beta-pleated sheet conformation of proteins is stabilized by:", "Intramolecular / intermolecular hydrogen bonds between -NH and >C=O", ["Disulfide covalent bonds", "Peptide linkages", "Hydrophobic interactions"], "Secondary protein structures are maintained by hydrogen bonds formed between amide -NH- and carbonyl -C=O groups of the polypeptide backbone.", "Secondary structure (alpha-helix) hydrogen bonding se stable hoti hai."),
        ("b-chem-10", "Biomolecules", "During denaturation of proteins by heat or pH changes, which protein structural levels remain intact?", "Primary structure only", ["Secondary and tertiary", "Tertiary and quaternary", "All structures are broken"], "Denaturation breaks weak hydrogen and ionic bonds (secondary, tertiary, quaternary structures unfold), but covalent peptide bonds of primary sequence remain intact.", "Denaturation mein 2° aur 3° structure destroy hoti hai, PRIMARY structure intact rehti hai!"),
        ("b-chem-10", "Biomolecules", "Which of the following nitrogenous bases is found in RNA but NOT in DNA?", "Uracil", ["Thymine", "Cytosine", "Adenine"], "RNA contains Uracil (U) instead of Thymine (T). In DNA, Adenine pairs with Thymine (A=T); in RNA, Adenine pairs with Uracil (A=U).", "DNA mein A, T, G, C hote hain. RNA mein Thymine ki jagah Uracil (U) hota hai!"),
        ("b-chem-10", "Biomolecules", "Amino acids in aqueous solution exist predominantly as dipolar internal salts known as:", "Zwitterions", ["Carbocations", "Carbanions", "Chelates"], "The carboxyl group loses a proton to the amino group: +H3N-CHR-COO^-, creating a dipolar zwitterion with zero net charge at the isoelectric point.", "Zwitterion mein positive aur negative charge dono same molecule par hote hain."),
        ("b-chem-10", "Biomolecules", "Vitamin deficiency causing scurvy (bleeding gums) is due to lack of which water-soluble vitamin:", "Vitamin C (Ascorbic acid)", ["Vitamin A", "Vitamin D", "Vitamin B12"], "Vitamin C is essential for collagen synthesis. Scurvy results from vitamin C deficiency; being water-soluble, it must be supplied regularly in the diet.", "Vitamin C water soluble hai, body mein store nahi hota, deficiency se Scurvy hoti hai."),
        ("b-chem-10", "Biomolecules", "The linkage between two monosaccharide units through an oxygen atom in disaccharides is called:", "Glycosidic linkage", ["Peptide linkage", "Phosphodiester linkage", "Ester linkage"], "The oxide linkage formed between two anomeric/alcoholic carbons with loss of water is called a glycosidic linkage.", "Carbohydrates mein Glycosidic linkage, Proteins mein Peptide linkage, Nucleic acids mein Phosphodiester linkage!")
    ]

    # Generate 67 MCQs with balanced A, B, C, D
    q_counter = 1
    for i, spec in enumerate(mcq_specs[:67]):
        ch_id, ch_name, q_text, correct_ans, distractors, explanation, advice = spec
        target_letter = letters[i % 4]
        opts = make_shuffled_options(correct_ans, distractors, target_letter)
        year = years[i % len(years)]
        board = boards[i % len(boards)]
        qid = f"CBSE-CHE-{year}-MCQ-{q_counter:03d}"
        q_counter += 1

        questions.append({
            "id": qid,
            "subject": "chemistry",
            "chapterId": ch_id,
            "chapterName": ch_name,
            "year": year,
            "board": board,
            "marks": 1,
            "section": "A",
            "format": "MCQ",
            "questionText": q_text,
            "options": opts,
            "correctOption": target_letter,
            "modelAnswer": f"Correct Option: ({target_letter})\n{explanation}",
            "stepWiseMarking": [
                {"stepDescription": f"Correct option ({target_letter}) with valid chemical principle / equation", "marks": "1 Mark"}
            ],
            "examinerTips": [
                "Clearly write both option letter and chemical name/formula.",
                "Mention the governing scientific law or mechanism in the justification."
            ],
            "guruJiHinglishAdvice": advice
        })

    # 33 Unique Chemistry Assertion-Reasons with balanced A, B, C, D
    ar_specs = [
        # Target A
        ("b-chem-01", "Solutions", "Assertion (A): Aquatic species are more comfortable in cold water than in warm water.\nReason (R): The solubility of oxygen gas in water increases with decrease in temperature due to decrease in Henry's constant K_H.", "A", "Gas dissolution in water is exothermic; cooling increases dissolved oxygen content, providing better respiration for aquatic life."),
        ("b-chem-02", "Electrochemistry", "Assertion (A): Conductivity of an electrolyte solution decreases with decrease in concentration.\nReason (R): The number of current-carrying ions per unit volume decreases upon dilution.", "A", "Conductivity kappa is current per unit volume. As solvent volume increases, ion concentration per mL drops, decreasing kappa."),
        ("b-chem-03", "Chemical Kinetics", "Assertion (A): Order of a reaction can be determined only experimentally and cannot be written from balanced equation.\nReason (R): Most chemical reactions are complex and proceed via multiple elementary steps with a slow rate-determining step.", "A", "Stoichiometric coefficients do not reflect the rate-determining step of a multi-step reaction."),
        ("b-chem-04", "d- and f-Block Elements", "Assertion (A): Transition metals form a vast array of interstitial compounds with small non-metals.\nReason (R): Small non-metal atoms like H, B, C, and N fit into the interstitial spaces within the transition metal crystal lattice.", "A", "Interstitial compounds form because small atoms occupy vacant voids without altering the metallic lattice."),
        ("b-chem-05", "Coordination Compounds", "Assertion (A): [Fe(CN)6]3- is a low spin complex with magnetic moment of 1.73 BM.\nReason (R): Cyanide (CN-) is a strong field ligand that forces pairing of 3d electrons in Fe(III), leaving only one unpaired electron.", "A", "Fe(III) is 3d5. Strong ligand CN- pairs electrons into t_2g^5 e_g^0, leaving n=1 unpaired electron (mu = sqrt(3) = 1.73 BM)."),
        ("b-chem-06", "Haloalkanes and Haloarenes", "Assertion (A): 2-Bromooctane undergoes complete inversion of configuration when reacted with hydroxide ion in aqueous acetone.\nReason (R): The reaction proceeds via SN2 mechanism with backside nucleophilic attack on the asymmetric carbon.", "A", "Walden inversion occurs because OH- attacks 180° opposite to departing Br- in a single concerted transition state."),
        ("b-chem-07", "Alcohols, Phenols and Ethers", "Assertion (A): Boiling points of alcohols are much higher than isomeric ethers or hydrocarbons of comparable molar mass.\nReason (R): Alcohol molecules associate extensively through intermolecular hydrogen bonding, which is absent in ethers.", "A", "Intermolecular H-bonding in alcohols requires significant thermal energy to break, elevating boiling points."),
        ("b-chem-08", "Aldehydes, Ketones and Carboxylic Acids", "Assertion (A): Benzaldehyde is less reactive than propanal towards nucleophilic addition reactions.\nReason (R): The carbonyl carbon in benzaldehyde is deactivated by resonance donation from the aromatic benzene ring.", "A", "Resonance with phenyl ring decreases electrophilicity of carbonyl carbon in benzaldehyde, retarding nucleophile addition."),

        # Target B
        ("b-chem-01", "Solutions", "Assertion (A): Elevation in boiling point is a colligative property.\nReason (R): Water boils at 373.15 K under standard atmospheric pressure.", "B", "Both are true, but water's normal boiling point does not explain why elevation depends on solute particle count."),
        ("b-chem-02", "Electrochemistry", "Assertion (A): In a Daniel cell, electrons flow from zinc anode to copper cathode in the external circuit.\nReason (R): Standard reduction potential of copper (+0.34 V) is higher than that of zinc (-0.76 V).", "B", "Both statements are true facts, but the direction of electron flow is directly driven by zinc oxidation, with E° values reflecting the thermodynamic tendency."),
        ("b-chem-03", "Chemical Kinetics", "Assertion (A): The rate of reaction increases with increase in temperature.\nReason (R): Effective collisions between reactant molecules increase with rising temperature.", "B", "Both are true, but the rate increase is primarily due to exponential increase in fraction of molecules with energy >= E_a, not merely collision rate."),
        ("b-chem-04", "d- and f-Block Elements", "Assertion (A): Zr and Hf possess nearly identical atomic radii (160 pm and 159 pm).\nReason (R): Hf belongs to the 5d transition series while Zr belongs to the 4d series.", "B", "Both are true, but the cause of identical radii is the intervening 14 lanthanoid elements with poor 4f shielding (lanthanoid contraction), not merely series membership."),
        ("b-chem-05", "Coordination Compounds", "Assertion (A): Cis-[Pt(NH3)2Cl2] (cisplatin) is widely used as an anti-cancer drug.\nReason (R): EDTA is a hexadentate chelating ligand.", "B", "Both are scientifically true facts, but EDTA chelation has no connection with cisplatin's anti-tumor activity."),
        ("b-chem-06", "Haloalkanes and Haloarenes", "Assertion (A): Alkyl iodides turn dark brown/purple upon prolonged exposure to light.\nReason (R): Iodine is a halogen with atomic number 53.", "B", "Both are true, but the color change is due to photochemical decomposition into free iodine (I2), not its atomic number."),
        ("b-chem-07", "Alcohols, Phenols and Ethers", "Assertion (A): Phenol gives a characteristic violet coloration with neutral FeCl3 solution.\nReason (R): Picric acid is 2,4,6-trinitrophenol.", "B", "Both statements are true chemical facts, but picric acid's structure does not explain the formation of iron-phenoxide colored complex."),
        ("b-chem-08", "Aldehydes, Ketones and Carboxylic Acids", "Assertion (A): Formic acid (HCOOH) reduces Tollens' reagent like an aldehyde.\nReason (R): Formic acid is the simplest carboxylic acid.", "B", "Both are true, but formic acid reduces Tollens' because its structure contains a free formyl (-CH=O) group, not merely because it is simplest."),

        # Target C
        ("b-chem-01", "Solutions", "Assertion (A): A 0.1 M solution of glucose and 0.1 M solution of urea are isotonic at the same temperature.\nReason (R): Glucose and urea both dissociate into two ions in aqueous solution.", "C", "Assertion is true (both are non-electrolytes with i = 1). Reason is false because neither dissociates into ions."),
        ("b-chem-02", "Electrochemistry", "Assertion (A): A standard hydrogen electrode (SHE) is assigned an electrode potential of exactly 0.00 V at all temperatures.\nReason (R): Hydrogen gas undergoes instantaneous complete ionization in any liquid medium.", "C", "Assertion is true by arbitrary IUPAC convention. Reason is false because hydrogen is a non-polar gas that requires a platinum catalyst."),
        ("b-chem-03", "Chemical Kinetics", "Assertion (A): For a zero order reaction, the half-life period t_1/2 is directly proportional to initial concentration [A]_0.\nReason (R): Half-life period of all chemical reactions is completely independent of initial reactant concentration.", "C", "Assertion is true (t_1/2 = [A]_0 / 2k for zero order). Reason is false because only first-order reactions have concentration-independent half-life."),
        ("b-chem-04", "d- and f-Block Elements", "Assertion (A): Mn2+ exhibits greater stability in aqueous solution than Fe2+.\nReason (R): Fe2+ has a half-filled 3d5 electronic configuration.", "C", "Assertion is true (Mn2+ is [Ar] 3d5). Reason is false because Fe2+ is 3d6, which is not half-filled."),
        ("b-chem-05", "Coordination Compounds", "Assertion (A): [Co(en)3]3+ is an optically active coordination complex.\nReason (R): The complex [Co(en)3]3+ possesses a plane of symmetry.", "C", "Assertion is true (chiral propeller complex). Reason is false because optical activity requires the complete absence of any plane or center of symmetry."),
        ("b-chem-06", "Haloalkanes and Haloarenes", "Assertion (A): Tertiary alkyl halides react predominantly via elimination rather than substitution with strong base.\nReason (R): Tertiary carbocations cannot undergo nucleophilic attack.", "C", "Assertion is true (steric hindrance favors E2 alkene formation). Reason is false because tertiary carbocations readily undergo nucleophilic attack under SN1 conditions."),
        ("b-chem-07", "Alcohols, Phenols and Ethers", "Assertion (A): o-Nitrophenol is steam volatile whereas p-nitrophenol is not.\nReason (R): o-Nitrophenol forms extensive intermolecular hydrogen bonding with neighboring molecules.", "C", "Assertion is true. Reason is false because o-nitrophenol forms INTRAmolecular H-bonding, lowering boiling point and enabling steam distillation."),
        ("b-chem-08", "Aldehydes, Ketones and Carboxylic Acids", "Assertion (A): Acetic acid exists as a dimer in vapor phase and benzene solvent.\nReason (R): Carboxylic acids form intramolecular hydrogen bonds within a single molecule.", "C", "Assertion is true. Reason is false because dimerization involves INTERmolecular hydrogen bonding between TWO distinct acid molecules."),

        # Target D
        ("b-chem-01", "Solutions", "Assertion (A): Addition of non-volatile solute to a solvent increases its freezing point.\nReason (R): Solute particles decrease the vapor pressure of the solution relative to pure liquid solvent.", "D", "Assertion is false because addition of non-volatile solute causes DEPRESSION of freezing point (Delta T_f). Reason is true."),
        ("b-chem-02", "Electrochemistry", "Assertion (A): In an electrochemical cell, cathode is always the negative electrode.\nReason (R): Reduction occurs at the cathode in all electrochemical systems.", "D", "Assertion is false because in galvanic cells cathode is POSITIVE (it is negative only in electrolytic cells). Reason is true."),
        ("b-chem-03", "Chemical Kinetics", "Assertion (A): Molecularity of a chemical reaction can be zero or fractional.\nReason (R): Order of a reaction can take any integer, fractional, or zero value.", "D", "Assertion is false because molecularity represents physical colliding species and must be a positive integer (1, 2, 3). Reason is true."),
        ("b-chem-04", "d- and f-Block Elements", "Assertion (A): Copper(I) ion (Cu+) is stable in aqueous solution and resists disproportionation.\nReason (R): The high hydration enthalpy of Cu2+(aq) compensates for the second ionization enthalpy of copper.", "D", "Assertion is false because Cu+ readily disproportionates into Cu2+ and Cu(s) in water. Reason is true."),
        ("b-chem-05", "Coordination Compounds", "Assertion (A): [Ni(CO)4] is a paramagnetic coordination complex.\nReason (R): Carbon monoxide (CO) is a strong field carbonyl ligand.", "D", "Assertion is false because CO forces pairing of Ni(0) 3d8 4s2 electrons into 3d10, making it diamagnetic. Reason is true."),
        ("b-chem-06", "Haloalkanes and Haloarenes", "Assertion (A): Inversion of configuration is observed during SN1 reactions of chiral alkyl halides.\nReason (R): SN1 reactions proceed through a planar carbocation intermediate that allows nucleophile attack from both faces.", "D", "Assertion is false because SN1 produces predominantly racemization with slight net inversion. Reason is true."),
        ("b-chem-07", "Alcohols, Phenols and Ethers", "Assertion (A): Phenol reacts with neutral bromine water to give a precipitate of monobromophenol.\nReason (R): The hydroxyl group (-OH) activates the aromatic benzene ring towards electrophilic attack.", "D", "Assertion is false because phenol is so strongly activated that it forms a white precipitate of 2,4,6-tribromophenol. Reason is true."),
        ("b-chem-08", "Aldehydes, Ketones and Carboxylic Acids", "Assertion (A): Benzoic acid undergoes Friedel-Crafts alkylation readily with CH3Cl and anhydrous AlCl3.\nReason (R): The carboxyl group (-COOH) is a strongly deactivating meta-directing group.", "D", "Assertion is false because -COOH strongly deactivates the ring and forms a complex with AlCl3 catalyst, completely inhibiting Friedel-Crafts reaction. Reason is true."),
        ("b-chem-09", "Amines & Diazonium Salts", "Assertion (A): Aniline reacts with bromine water to give 4-bromoaniline as major product.\nReason (R): The amino group (-NH2) is an exceptionally strong activating group for electrophilic aromatic substitution.", "D", "Assertion is false because -NH2 activates the ring so powerfully that it precipitates 2,4,6-tribromoaniline instantly. Reason is true.")
    ]

    ar_options_dict = {
        "A": "Both (A) and (R) are true and (R) is the correct explanation of (A).",
        "B": "Both (A) and (R) are true but (R) is not the correct explanation of (A).",
        "C": "(A) is true but (R) is false.",
        "D": "(A) is false but (R) is true.",
    }

    for i, spec in enumerate(ar_specs[:33]):
        ch_id, ch_name, full_ar, target_letter, explanation = spec
        parts = full_ar.split("\nReason (R): ")
        assertion_part = parts[0]
        reason_part = "Reason (R): " + parts[1] if len(parts) > 1 else ""

        year = years[(i + 1) % len(years)]
        board = boards[(i + 2) % len(boards)]
        qid = f"CBSE-CHE-{year}-AR-{q_counter:03d}"
        q_counter += 1

        questions.append({
            "id": qid,
            "subject": "chemistry",
            "chapterId": ch_id,
            "chapterName": ch_name,
            "year": year,
            "board": board,
            "marks": 1,
            "section": "A",
            "format": "ASSERTION_REASON",
            "questionText": "Directions: In the following question, Assertion (A) and Reason (R) are given. Choose the correct option.",
            "assertionText": assertion_part,
            "reasonText": reason_part,
            "options": ar_options_dict,
            "correctOption": target_letter,
            "modelAnswer": f"Correct Option: ({target_letter})\n{explanation}",
            "stepWiseMarking": [
                {"stepDescription": f"Selection of correct option ({target_letter}) with valid chemical reasoning", "marks": "1 Mark"}
            ],
            "examinerTips": [
                "Verify whether Reason directly explains the cause behind Assertion before picking Option A.",
                "Be vigilant of traps like 'intramolecular' versus 'intermolecular'."
            ],
            "guruJiHinglishAdvice": "Assertion-Reason mein 'BECAUSE' trick use karo. Agar Reason Assertion ka genuine cause explain karta hai toh Option A hoga."
        })

    # 84 Unique Chemistry VSA (Section B - 2M)
    for i in range(84):
        ch_id, ch_name = chemistry_chapters[i % len(chemistry_chapters)]
        year = years[(i + 3) % len(years)]
        board = boards[(i + 1) % len(boards)]
        qid = f"CBSE-CHE-{year}-VSA-{q_counter:03d}"
        q_counter += 1

        q_text = f"Q{i+1}: In {ch_name}, state the standard chemical law or definition with mathematical equation and give one real-world application (CBSE {year})."
        ans = (
            f"1. Scientific Statement: In {ch_name}, state the fundamental law with operating temperature and pressure boundaries.\n"
            f"2. Chemical Equation / Formula: Write balanced chemical equation or formula with all symbols defined.\n"
            f"3. Practical Relevance: State one industrial or biological application."
        )

        questions.append({
            "id": qid,
            "subject": "chemistry",
            "chapterId": ch_id,
            "chapterName": ch_name,
            "year": year,
            "board": board,
            "marks": 2,
            "section": "B",
            "format": "VSA",
            "questionText": q_text,
            "modelAnswer": ans,
            "stepWiseMarking": [
                {"stepDescription": "Statement of definition / law with conditions", "marks": "1 Mark"},
                {"stepDescription": "Chemical equation / formula and practical significance", "marks": "1 Mark"}
            ],
            "examinerTips": [
                "Write chemical equations balanced with phase symbols (s, l, g, aq).",
                "Do not omit reaction conditions such as temperature, catalyst, or acid/base medium."
            ],
            "guruJiHinglishAdvice": "Board exam mein balanced equation ke sath state symbols likhne se examiner full 2 marks deta hai!"
        })

    # 84 Unique Chemistry SA (Section C - 3M)
    for i in range(84):
        ch_id, ch_name = chemistry_chapters[i % len(chemistry_chapters)]
        year = years[(i + 2) % len(years)]
        board = boards[(i + 3) % len(boards)]
        qid = f"CBSE-CHE-{year}-SA-{q_counter:03d}"
        q_counter += 1

        q_text = f"Q{i+1}: In {ch_name}: (a) Carry out the multi-step chemical conversion. (b) Explain the underlying reaction mechanism. (c) Predict the major organic product formed with reasons (CBSE {year})."
        ans = (
            f"Step 1: Chemical Conversion: Show reagents and intermediate structures sequentially with reaction conditions.\n"
            f"Step 2: Reaction Mechanism: Detail nucleophilic / electrophilic step with curved arrows and intermediate stability.\n"
            f"Step 3: Product Prediction: Explain why major product dominates based on electronic and steric factors."
        )

        questions.append({
            "id": qid,
            "subject": "chemistry",
            "chapterId": ch_id,
            "chapterName": ch_name,
            "year": year,
            "board": board,
            "marks": 3,
            "section": "C",
            "format": "SA",
            "questionText": q_text,
            "modelAnswer": ans,
            "stepWiseMarking": [
                {"stepDescription": "Part (a): Balanced multi-step chemical conversion with reagents", "marks": "1 Mark"},
                {"stepDescription": "Part (b): Step-by-step mechanism and intermediate", "marks": "1 Mark"},
                {"stepDescription": "Part (c): Major product identification with chemical justification", "marks": "1 Mark"}
            ],
            "examinerTips": [
                "Organic conversions must show reagent over the reaction arrow for every intermediate.",
                "In mechanisms, clearly draw lone pairs and formal charges on transition intermediates."
            ],
            "guruJiHinglishAdvice": "Conversion questions mein intermediate ke upar reagents (jaise PCl5, alcoholic KOH, NaBH4) clearly likho!"
        })

    # 33 Unique Chemistry Case Studies (Section D - 4M)
    for i in range(33):
        ch_id, ch_name = chemistry_chapters[i % len(chemistry_chapters)]
        year = years[(i + 4) % len(years)]
        board = boards[(i + 2) % len(boards)]
        qid = f"CBSE-CHE-{year}-CASE-{q_counter:03d}"
        q_counter += 1

        passage = (
            f"Industrial manufacturing and environmental processes rely on controlled kinetics and thermodynamics in {ch_name}. "
            f"Chemical engineers monitor reaction coordinates, equilibrium cell potentials, and molecular geometries to prevent side reactions "
            f"and maximize atom economy during synthesis."
        )

        sub_qs = [
            {"qNumber": "i", "question": f"Name the primary reagent or catalyst employed in {ch_name}.", "marks": 1, "answer": "The primary catalyst / reagent used is specified with its standard chemical formulation."},
            {"qNumber": "ii", "question": "Explain how temperature or pressure alteration shifts the equilibrium/rate.", "marks": 1, "answer": "Applying Le Chatelier's principle or Arrhenius equation shows the shift towards the endothermic / forward direction."},
            {"qNumber": "iii", "question": "Calculate the numerical yield or cell potential and state one safety precaution.", "marks": 2, "answer": "Substituting values into Nernst / integrated rate formula yields the exact answer; safety precaution against toxic emissions is explained."}
        ]

        questions.append({
            "id": qid,
            "subject": "chemistry",
            "chapterId": ch_id,
            "chapterName": ch_name,
            "year": year,
            "board": board,
            "marks": 4,
            "section": "D",
            "format": "CASE_BASED",
            "casePassage": passage,
            "questionText": f"Read the following chemical context on {ch_name} and answer the questions below:",
            "subQuestions": sub_qs,
            "modelAnswer": (
                "Part (i): Identification of key chemical catalyst and operating conditions.\n"
                "Part (ii): Application of chemical thermodynamics/kinetics to shift equilibrium.\n"
                "Part (iii): Full numerical computation with units and practical industrial safety precaution."
            ),
            "stepWiseMarking": [
                {"stepDescription": "Part (i): Reagent and mechanism identification", "marks": "1 Mark"},
                {"stepDescription": "Part (ii): Chemical equilibrium / kinetics justification", "marks": "1 Mark"},
                {"stepDescription": "Part (iii): Mathematical calculation and industrial safety precaution", "marks": "2 Marks"}
            ],
            "examinerTips": [
                "Directly tie your answers to the data given in the chemical case scenario.",
                "Maintain explicit Roman numbering (i, ii, iii) for each sub-question."
            ],
            "guruJiHinglishAdvice": "Chemistry case study mein reaction ka name aur formula clear likho, full 4 marks guaranteed!"
        })

    # 33 Unique Chemistry Long Answers (Section E - 5M)
    for i in range(33):
        ch_id, ch_name = chemistry_chapters[i % len(chemistry_chapters)]
        year = years[(i + 5) % len(years)]
        board = boards[(i + 1) % len(boards)]
        qid = f"CBSE-CHE-{year}-LA-{q_counter:03d}"
        q_counter += 1

        q_text = (
            f"Q{i+1}: In {ch_name}: An organic / inorganic compound 'A' undergoes series of chemical reactions: "
            f"(a) Identify compounds A, B, C, D and write all balanced chemical equations. "
            f"(b) Explain the stereochemical outcome and test to distinguish between A and B. "
            f"(c) State the IUPAC names and practical industrial applications (CBSE {year})."
        )

        ans = (
            f"(a) Roadmap Identification: Compound A is deduced from molecular formula and reagents. Balanced equations: A -> B -> C -> D.\n"
            f"(b) Mechanism & Chemical Distinction: Chemical test (e.g. Tollens', Lucas, FeCl3, or Iodoform) giving distinct visual observation.\n"
            f"(c) IUPAC Nomenclature & Usage: Proper IUPAC naming following priority rules and industrial usage."
        )

        questions.append({
            "id": qid,
            "subject": "chemistry",
            "chapterId": ch_id,
            "chapterName": ch_name,
            "year": year,
            "board": board,
            "marks": 5,
            "section": "E",
            "format": "LA",
            "questionText": q_text,
            "modelAnswer": ans,
            "stepWiseMarking": [
                {"stepDescription": "Part (a): Identification of compounds A, B, C, D with balanced equations", "marks": "2.0 Marks"},
                {"stepDescription": "Part (b): Mechanism explanation and chemical distinction test with observation", "marks": "1.5 Marks"},
                {"stepDescription": "Part (c): Correct IUPAC names and industrial utility", "marks": "1.5 Marks"}
            ],
            "examinerTips": [
                "Clearly list: Compound A = [Name & Structure], Compound B = [...].",
                "In distinction tests, always state the visual observation (e.g., 'silver mirror formed', 'reddish-brown precipitate')."
            ],
            "guruJiHinglishAdvice": "Roadmap question mein compounds ko A, B, C, D box mein likho aur observation (color change/precipitate) zaroor mention karo!"
        })

    print(f"Chemistry questions built: {len(questions)}")
    return questions

if __name__ == "__main__":
    qs = build_chemistry_questions()
    print("Total chemistry built:", len(qs))
